﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace ra2Launcher
{
    internal class DefaultSettings
    {
        public static void VideoConfiguration(string IniPath, int screenWidth, int screenHeight)
        {
            string section = "Video";
            Ini ra2Ini = new Ini(IniPath);
            ra2Ini.INIWrite(section,"VideoBackBuffer", "no");
            ra2Ini.INIWrite(section, "AllowHiResModes", "yes");
            ra2Ini.INIWrite(section, "AllowVRAMSidebar", "no");
            ra2Ini.INIWrite(section, "ScreenWidth", screenWidth.ToString());
            ra2Ini.INIWrite(section, "ScreenHeight", screenHeight.ToString());
            ra2Ini.INIWrite(section, "StretchMovies", "no");
        }
        public static void EnableLagacyMode(string exeName)
        {
            RegistryKey key = Registry.CurrentUser.OpenSubKey("SoftWare\\Microsoft\\Windows NT\\CurrentVersion\\AppCompatFlags\\Layers", true);//打开注册表子项

            if (key == null)//如果该项不存在的话，则创建该子项
                key = Registry.LocalMachine.CreateSubKey("SoftWare\\Microsoft\\Windows NT\\CurrentVersion\\AppCompatFlags\\Layers");

            //如果不存在该值，则设置该值，重启程序应用设置
            if (key.GetValue(exeName) == null)
            {
                //更改成兼容win95后安装路径则不能有中文，所以兼容xpsp2
                key.SetValue(exeName, "~ DISABLEDXMAXIMIZEDWINDOWEDMODE 256COLOR WINXPSP2 DWM8And16BitMitigation");
            }
        }
        public static void DirectX_3DAcceleration(DX3dAccOptions option) 
        {
            RegistryKey key1 = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\DirectDraw", true);
            if (key1 == null) key1 = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Microsoft\\DirectDraw");

            RegistryKey key2 = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Direct3D\\Drivers", true);
            if (key2 == null) key2 = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Microsoft\\Direct3D\\Drivers");

            RegistryKey key3 = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Wow6432Node\\Microsoft\\DirectDraw", true);
            if (key3 == null) key3 = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Wow6432Node\\Microsoft\\DirectDraw");

            RegistryKey key4 = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Wow6432Node\\Microsoft\\Direct3D\\Drivers", true);
            if (key4 == null) key4 = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Wow6432Node\\Microsoft\\Direct3D\\Drivers");

            switch(option.ToString().ToUpper()) 
            {
                case "ON":
                    key1.SetValue("EmulationOnly", "00000000", RegistryValueKind.DWord);
                    key2.SetValue("SoftwareOnly", "00000000", RegistryValueKind.DWord);
                    key3.SetValue("EmulationOnly", "00000000", RegistryValueKind.DWord);
                    key4.SetValue("SoftwareOnly", "00000000", RegistryValueKind.DWord);
                    break;
                case "OFF":
                    key1.SetValue("EmulationOnly", "00000001", RegistryValueKind.DWord);
                    key2.SetValue("SoftwareOnly", "00000001", RegistryValueKind.DWord);
                    key3.SetValue("EmulationOnly", "00000001", RegistryValueKind.DWord);
                    key4.SetValue("SoftwareOnly", "00000001", RegistryValueKind.DWord);
                    break;

            }
        }
    }
    public enum DX3dAccOptions
    {
        On,
        Off,
    }
}
