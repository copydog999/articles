﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace ra2Launcher
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>

        static bool ra2Running;
        static bool quit = false;
        static string hostDir = AppDomain.CurrentDomain.BaseDirectory;
        static string iniPath = hostDir + "ra2.ini";
        static void Main()
        {
            try
            {
                //1. 将分辨率改为1366*768
                //2. 关闭videobuffer，开启高分辨模式等
                DefaultSettings.VideoConfiguration(iniPath, 1366, 768);

                //3. 将ra2.exe和game.exe设定兼容模式
                DefaultSettings.EnableLagacyMode(hostDir + "ra2.exe");
                DefaultSettings.EnableLagacyMode(hostDir + "game.exe");

                //4. 默认导入一次游戏注册表
                Process ra2Reg = new Process();
                ProcessStartInfo psInfo = new ProcessStartInfo("reg.exe", "import " + hostDir + "ra2.reg");

                //4.1 必须创建具有管理员权限的reg进程；
                {
                    psInfo.Verb = "runas";
                    psInfo.UseShellExecute = false;
                    psInfo.CreateNoWindow = true;
                }
                ra2Reg.StartInfo = psInfo;
                ra2Reg.Start();

                //5. 读取cfg文件并启动其中的应用程序
                Config cfg = new Config(hostDir + "ra2Launcher.cfg");
                retry:
                try
                {
                    cfg.RunExecutables();

                }catch(Exception e)
                {
                    DialogResult option = MessageBox.Show("启动进程时出现未知错误，请确保cfg中存储了正确的程序名称。",
                        e.Message, MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error);
                    if (option == DialogResult.Retry) goto retry;
                    else if (option == DialogResult.Abort) return;
                }

                //Disable DX3DACC
                DialogResult res =
                MessageBox.Show("即将禁用DirectX 3D加速以确保正常游戏，DirectX 3D加速将在游戏结束后重新启用。\n是否继续？",
                    "禁用DirectX 3D加速", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                if(res == DialogResult.OK) 
                {
                    DefaultSettings.DirectX_3DAcceleration(DX3dAccOptions.Off);

                    //Run Programs
                    Process.Start(hostDir + "\\ra2.exe"); ra2Running = true;
                    while (true)
                    {
                        Process[] ps = Process.GetProcesses();
                        if (!Exists(ps, "ra2"))
                        {
                            //Enable DX3DACC
                            DefaultSettings.DirectX_3DAcceleration(DX3dAccOptions.On);
                            MessageBox.Show("游戏结束，DirectX 3D加速已重新启用。","启用DirectX 3D加速",MessageBoxButtons.OK,MessageBoxIcon.Information);
                            Environment.Exit(0);
                        }
                    }
                }
                else { Environment.Exit(0); }
                
            }catch(Exception ex)
            {
                MessageBox.Show("请将所有文件放进游戏文件夹中",ex.Message,MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }
        static bool Exists(Process[] ps, string name)
        {
            foreach(Process p in ps)
            {
                if(p.ProcessName == name) return true;
            }
            return false;
        }
    }
}
