"""
Hanayome-Agent 测试脚本

用于验证各个模块的功能
"""
import asyncio
from hanayome_agent import HanayomeAgent
from utils.config_loader import load_config


async def test_basic_chat():
    """测试基本对话功能"""
    print("=" * 60)
    print("测试1: 基本对话功能")
    print("=" * 60)
    
    # 加载配置
    config = load_config()
    
    # 创建Agent
    agent = HanayomeAgent(config=config)
    
    # 测试对话
    test_inputs = [
        "你好，很高兴认识你",
        "你今天过得怎么样？",
        "我觉得你很可爱",
        "我们一起去看电影吧",
        "谢谢你一直陪着我"
    ]
    
    for i, user_input in enumerate(test_inputs, 1):
        print(f"\n--- 第{i}轮对话 ---")
        print(f"玩家: {user_input}")
        
        result = await agent.process_turn(
            user_input=user_input,
            game_date=i * 5,
            time_of_day="afternoon"
        )
        
        print(f"AI: {result['response']}")
        print(f"情感: {result['emotion']}")
        print(f"好感度: {result['affection']['state']}")
        print(f"延迟: {result['latency']*1000:.1f}ms")
        
        if result['events']:
            print(f"触发事件: {len(result['events'])}个")
            for event in result['events']:
                print(f"  - {event['message']}")
    
    print("\n✓ 基本对话测试完成")


async def test_affection_system():
    """测试好感度系统"""
    print("\n" + "=" * 60)
    print("测试2: 好感度系统")
    print("=" * 60)
    
    from modules.affection import AffectionEngine
    
    engine = AffectionEngine()
    
    # 模拟ABSA分析结果
    test_aspects = [
        ("外貌_整体", 1, 0.8),      # 正面评价外貌
        ("性格_温柔", 1, 0.9),      # 正面评价性格
        ("行为_日常", 0, 0.5),      # 中性评价行为
        ("情感_喜悦", 1, 0.7),      # 正面情感
    ]
    
    print("\n初始状态:")
    print(engine.get_state())
    
    print("\n更新好感度...")
    engine.update(test_aspects)
    
    print("\n更新后状态:")
    state = engine.get_state()
    print(f"好感度: {state['state']}")
    print(f"等级: {state['levels']}")
    print(f"对话参数: {state['dialogue_params']}")
    
    print("\n✓ 好感度系统测试完成")


async def test_memory_system():
    """测试记忆系统"""
    print("\n" + "=" * 60)
    print("测试3: 记忆系统")
    print("=" * 60)
    
    from modules.memory import MemoryManager
    from datetime import datetime
    
    manager = MemoryManager()
    
    # 添加几轮记忆
    turns = [
        {
            'user_input': '你好',
            'response': '你好呀！',
            'affection_state': {'fond': 10},
            'emotion_intensity': 0.6,
            'timestamp': datetime.now()
        },
        {
            'user_input': '我喜欢你',
            'response': '真的吗？我也喜欢你！',
            'affection_state': {'fond': 50},
            'emotion_intensity': 0.9,
            'timestamp': datetime.now()
        }
    ]
    
    print("\n添加记忆...")
    for turn in turns:
        manager.add_memory(turn)
        print(f"  ✓ 添加了记忆: {turn['user_input'][:20]}...")
    
    print(f"\n短期记忆数量: {len(manager.get_short_term_history())}")
    print(f"长期记忆统计: {manager.get_stats()}")
    
    # 测试检索
    print("\n检索相关记忆...")
    memories = await manager.retrieve("喜欢", {'fond': 50})
    print(f"找到 {len(memories)} 条相关记忆:")
    for mem in memories:
        print(f"  - 得分: {mem['score']:.3f}, 内容: {mem['metadata']['user_input'][:30]}")
    
    print("\n✓ 记忆系统测试完成")


async def test_story_machine():
    """测试剧情状态机"""
    print("\n" + "=" * 60)
    print("测试4: 剧情状态机")
    print("=" * 60)
    
    from modules.story import StoryStateMachine
    
    machine = StoryStateMachine()
    
    # 模拟好感度状态
    affection = {
        'state': {
            'fond': 45,
            'trust': 40,
            'intim': 35,
            'respect': 30
        }
    }
    
    print("\n检查触发条件...")
    triggered = machine.check_triggers(
        affection=affection,
        date=15,
        time_of_day="afternoon"
    )
    
    print(f"触发了 {len(triggered)} 个事件:")
    for event in triggered:
        print(f"  - {event['type']}: {event['message']}")
    
    # 模拟状态转换
    if triggered:
        print("\n执行状态转换...")
        for event in triggered:
            if event['type'] == 'side_event':
                machine.transition(f"side_event_{event['event_id']}")
            elif event['type'] == 'main_chapter':
                machine.transition(f"main_chapter_{event['chapter']}")
    
    print(f"\n当前剧情状态: {machine.get_state()}")
    
    print("\n✓ 剧情状态机测试完成")


async def main():
    """运行所有测试"""
    print("\n" + "=" * 60)
    print("Hanayome-Agent 模块测试")
    print("=" * 60)
    
    try:
        # 运行各个测试
        await test_affection_system()
        await test_memory_system()
        await test_story_machine()
        await test_basic_chat()
        
        print("\n" + "=" * 60)
        print("✓ 所有测试完成！")
        print("=" * 60)
    
    except Exception as e:
        print(f"\n✗ 测试失败: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())
