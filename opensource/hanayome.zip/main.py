from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, Dict, List
import uvicorn
import asyncio

from hanayome_agent import HanayomeAgent
from utils.config_loader import load_config


# 初始化FastAPI应用
app = FastAPI(
    title="Hanayome-Agent API",
    description="Galgame对话智能体API接口",
    version="1.0.0"
)

# 配置CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 全局Agent实例
agent: Optional[HanayomeAgent] = None


# ========== 数据模型 ==========

class ChatRequest(BaseModel):
    """对话请求"""
    user_input: str
    role_name: Optional[str] = None
    game_date: Optional[int] = None
    time_of_day: Optional[str] = None


class ChatResponse(BaseModel):
    """对话响应"""
    response: str
    emotion: str
    affection: Dict
    events: List[Dict]
    latency: float
    story_state: Optional[Dict] = None
    memory_stats: Optional[Dict] = None


class StatusResponse(BaseModel):
    """状态响应"""
    affection: Dict
    story: Dict
    memory: Dict
    performance: Dict


# ========== 生命周期管理 ==========

@app.on_event("startup")
async def startup_event():
    """启动时初始化Agent"""
    global agent
    
    print("Loading configuration...")
    config = load_config()
    
    print("Initializing Hanayome-Agent...")
    agent = HanayomeAgent(config=config)
    
    print("Hanayome-Agent API is ready!")


@app.on_event("shutdown")
async def shutdown_event():
    """关闭时清理资源"""
    global agent
    if agent:
        print("Shutting down Hanayome-Agent...")


# ========== API端点 ==========

@app.post("/api/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """
    处理对话请求
    
    - **user_input**: 玩家输入文本
    - **role_name**: 角色名称 (可选)
    - **game_date**: 游戏内日期 (可选)
    - **time_of_day**: 时间段 (可选)
    """
    global agent
    
    if not agent:
        raise HTTPException(status_code=503, detail="Agent not initialized")
    
    try:
        # 调用Agent处理
        result = await agent.process_turn(
            user_input=request.user_input,
            game_date=request.game_date,
            time_of_day=request.time_of_day
        )
        
        # 检查是否有错误
        if 'error' in result:
            raise HTTPException(status_code=500, detail=result['error'])
        
        return ChatResponse(
            response=result['response'],
            emotion=result['emotion'],
            affection=result['affection'],
            events=result['events'],
            latency=result['latency'],
            story_state=result.get('story_state'),
            memory_stats=result.get('memory_stats')
        )
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/status", response_model=StatusResponse)
async def get_status():
    """获取Agent当前状态"""
    global agent
    
    if not agent:
        raise HTTPException(status_code=503, detail="Agent not initialized")
    
    status = agent.get_agent_status()
    
    return StatusResponse(
        affection=status['affection'],
        story=status['story'],
        memory=status['memory'],
        performance=status['performance']
    )


@app.post("/api/reset")
async def reset_agent():
    """重置Agent状态"""
    global agent
    
    if not agent:
        raise HTTPException(status_code=503, detail="Agent not initialized")
    
    agent.reset()
    
    return {"message": "Agent state has been reset"}


@app.get("/api/health")
async def health_check():
    """健康检查"""
    return {"status": "healthy", "service": "Hanayome-Agent API"}


# ========== 主入口 ==========

if __name__ == "__main__":
    # 加载配置
    config = load_config()
    
    # 服务器配置
    host = "0.0.0.0"
    port = 8000
    
    print(f"Starting Hanayome-Agent API server on {host}:{port}")
    
    # 启动服务器
    uvicorn.run(
        "main:app",
        host=host,
        port=port,
        reload=True,
        log_level="info"
    )
