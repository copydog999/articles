import re
from typing import List, Tuple, Dict


class DialogueGenerator:
    """
    对话生成器
    
    基座模型: Qwen-7B (或本地可运行的任何7B模型)
    量化: INT4 (GPTQ/AWQ)
    推理框架: vLLM 或 llama.cpp
    """
    
    def __init__(self, model_path: str = None, config: dict = None):
        self.config = config or {}
        
        # 生成参数
        self.temperature = self.config.get('temperature', 0.8)
        self.top_p = self.config.get('top_p', 0.9)
        self.top_k = self.config.get('top_k', 50)
        self.max_tokens = self.config.get('max_tokens', 100)
        self.frequency_penalty = self.config.get('frequency_penalty', 0.5)
        self.presence_penalty = self.config.get('presence_penalty', 0.3)
        
        # 敏感词过滤器 (Aho-Corasick算法，简化版使用正则)
        self.sensitive_words = [
            '暴力', '色情', '政治敏感词'  # 实际应从配置文件加载
        ]
        
        # 兜底回复
        self.fallback_responses = [
            "嗯...我还在思考呢。",
            "这个话题很有趣呢。",
            "能再说详细一点吗？",
            "我明白了，请继续。"
        ]
        
        # 初始化模型 (占位符，实际需要加载Qwen-7B)
        self.model = None
        self.tokenizer = None
        
        if model_path:
            self._load_model(model_path)
    
    def _load_model(self, model_path: str):
        """加载INT4量化的Qwen-7B模型"""
        try:
            from transformers import AutoModelForCausalLM, AutoTokenizer
            from peft import PeftModel
            
            # 加载基础模型 (INT4量化)
            self.tokenizer = AutoTokenizer.from_pretrained(
                model_path,
                trust_remote_code=True
            )
            
            # 这里需要根据实际量化方式调整
            # 如果使用GPTQ/AWQ量化，需要相应的加载代码
            self.model = AutoModelForCausalLM.from_pretrained(
                model_path,
                trust_remote_code=True,
                device_map="auto"
            )
            
            print(f"Model loaded from {model_path}")
        
        except Exception as e:
            print(f"Warning: Failed to load model: {e}")
            print("Using mock generation mode")
    
    def build_prompt(self,
                     role_config: dict,
                     affection: dict,
                     memories: List[dict],
                     history: List[dict],
                     user_input: str) -> str:
        """
        六部分提示词拼接 (算法13)
        
        Args:
            role_config: 角色配置 {name, age, personality, speaking_style, backstory}
            affection: 好感度状态
            memories: 检索到的相关记忆
            history: 最近5轮对话历史
            user_input: 玩家当前输入
        
        Returns:
            完整的提示词字符串
        """
        prompt_parts = []
        
        # 1. 系统提示词
        system_prompt = self._build_system_prompt(role_config)
        prompt_parts.append(system_prompt)
        
        # 2. 好感度编码
        affection_prompt = self._build_affection_prompt(affection)
        prompt_parts.append(affection_prompt)
        
        # 3. 情感记忆
        if memories:
            memory_prompt = self._build_memory_prompt(memories)
            prompt_parts.append(memory_prompt)
        
        # 4. 对话历史
        if history:
            history_prompt = self._build_history_prompt(history)
            prompt_parts.append(history_prompt)
        
        # 5. 玩家输入
        prompt_parts.append(f"玩家: {user_input}")
        
        # 6. 输出格式约束
        prompt_parts.append("\n请按照以下格式回复:")
        prompt_parts.append("[情感标签]: [正面/负面/中性]")
        prompt_parts.append("[回复内容]: ...")
        
        return "\n\n".join(prompt_parts)
    
    def _build_system_prompt(self, role_config: dict) -> str:
        """构建系统提示词"""
        name = role_config.get('name', '角色')
        age = role_config.get('age', '未知')
        personality = role_config.get('personality', '温和')
        speaking_style = role_config.get('speaking_style', '自然')
        backstory = role_config.get('backstory', '')
        
        prompt = f"""# 角色设定
姓名: {name}
年龄: {age}岁
性格: {personality}
说话风格: {speaking_style}

## 背景故事
{backstory}

你是{name}，请始终保持角色一致性，根据当前好感度和记忆来回应玩家。"""
        
        return prompt
    
    def _build_affection_prompt(self, affection: dict) -> str:
        """构建好感度提示词"""
        levels = affection.get('levels', {})
        
        fond_level = levels.get('fond', {}).get('level_name', '陌生人')
        trust_level = levels.get('trust', {}).get('level_name', '陌生人')
        intim_level = levels.get('intim', {}).get('level_name', '陌生人')
        respect_level = levels.get('respect', {}).get('level_name', '陌生人')
        
        prompt = f"""# 当前好感度状态
- 好感度等级: {fond_level} ({affection['state'].get('fond', 0):.1f}/100)
- 信任度等级: {trust_level} ({affection['state'].get('trust', 0):.1f}/100)
- 亲密度等级: {intim_level} ({affection['state'].get('intim', 0):.1f}/100)
- 尊敬度等级: {respect_level} ({affection['state'].get('respect', 0):.1f}/100)

请根据当前好感度调整你的称呼和语气。"""
        
        return prompt
    
    def _build_memory_prompt(self, memories: List[dict]) -> str:
        """构建情感记忆提示词"""
        prompt = "# 你们之间发生过的重要事件:\n"
        
        for mem in memories:
            metadata = mem.get('metadata', {})
            timestamp = metadata.get('timestamp', '过去')
            emotion = metadata.get('emotion_intensity', 0.5)
            user_input = metadata.get('user_input', '')
            
            # 简化时间显示
            prompt += f"- [{timestamp[:10]}]: {user_input[:50]} (情感强度: {emotion:.2f})\n"
        
        return prompt
    
    def _build_history_prompt(self, history: List[dict]) -> str:
        """构建对话历史提示词"""
        prompt = "# 最近的对话历史:\n"
        
        for i, turn in enumerate(history[-5:], 1):  # 最近5轮
            user_text = turn.get('user_input', '')[:100]
            response_text = turn.get('response', '')[:100]
            prompt += f"第{i}轮:\n"
            prompt += f"  玩家: {user_text}\n"
            prompt += f"  你: {response_text}\n"
        
        return prompt
    
    async def generate(self, prompt: str) -> Tuple[str, str]:
        """
        生成对话回复
        
        Args:
            prompt: 完整的提示词
        
        Returns:
            (response_text, emotion_tag)
        """
        try:
            if self.model is None:
                # Mock模式：返回模拟回复
                return self._mock_generate(prompt)
            
            # 实际模型推理
            inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)
            
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=self.max_tokens,
                temperature=self.temperature,
                top_p=self.top_p,
                top_k=self.top_k,
                do_sample=True,
                pad_token_id=self.tokenizer.eos_token_id
            )
            
            # 解码输出
            full_response = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
            
            # 提取回复内容 (去除prompt部分)
            response_text = full_response[len(prompt):].strip()
            
            # 后处理
            response_text, emotion_tag = self._post_process(response_text)
            
            return response_text, emotion_tag
        
        except Exception as e:
            print(f"Generation error: {e}")
            return self._get_fallback_response()
    
    def _mock_generate(self, prompt: str) -> Tuple[str, str]:
        """模拟生成 (用于测试)"""
        import random
        
        responses = [
            "嗯，我明白你的意思了。",
            "真的吗？那太好了！",
            "让我想想...",
            "我也这么觉得呢。",
            "谢谢你告诉我这些。",
            "哈哈，你真有趣。",
            "我会记住的。",
            "我们一起加油吧！"
        ]
        
        emotions = ["正面", "正面", "中性", "正面", "正面", "正面", "中性", "正面"]
        
        idx = random.randint(0, len(responses) - 1)
        return responses[idx], emotions[idx]
    
    def _post_process(self, text: str) -> Tuple[str, str]:
        """
        后处理: 
        - 解析情感标签
        - 去除特殊标记
        - 截断到100字符
        - 敏感词过滤
        """
        emotion_tag = "中性"
        
        # 尝试解析情感标签
        emotion_match = re.search(r'\[情感标签\]:\s*(正面|负面|中性)', text)
        if emotion_match:
            emotion_tag = emotion_match.group(1)
        
        # 提取回复内容
        content_match = re.search(r'\[回复内容\]:\s*(.+)', text, re.DOTALL)
        if content_match:
            text = content_match.group(1).strip()
        else:
            # 如果没有找到格式，直接使用原文
            text = text.strip()
        
        # 截断到100字符
        if len(text) > 100:
            text = text[:100] + "..."
        
        # 敏感词过滤
        text = self._filter_sensitive_words(text)
        
        # 如果过滤后为空，使用兜底回复
        if not text or len(text.strip()) == 0:
            text, emotion_tag = self._get_fallback_response()
        
        return text, emotion_tag
    
    def _filter_sensitive_words(self, text: str) -> str:
        """敏感词过滤"""
        filtered_text = text
        for word in self.sensitive_words:
            filtered_text = filtered_text.replace(word, "***")
        return filtered_text
    
    def _get_fallback_response(self) -> Tuple[str, str]:
        """获取兜底回复"""
        import random
        idx = random.randint(0, len(self.fallback_responses) - 1)
        return self.fallback_responses[idx], "中性"
