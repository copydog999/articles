from typing import Dict, Set, List, Optional
from datetime import datetime


class StoryStateMachine:
    """
    剧情状态机
    
    分层状态机: 主线章节 / 支线触发 / 角色路线
    """
    
    def __init__(self, story_config: dict = None):
        self.config = story_config or {}
        
        # 当前状态
        self.main_chapter = 0      # M0~MK (主线章节)
        self.side_events = set()   # 已激活/完成的支线事件
        self.route = 0             # 0未解锁/1普通/2友情/3恋爱/4专属
        
        # 已完成的事件
        self.completed_events = set()
        
        # 玩家选择历史
        self.choices_history = []
        
        # 剧情触发配置 (示例)
        self.triggers = self._load_triggers()
        
        # 结局配置
        self.endings = self._load_endings()
    
    def _load_triggers(self) -> dict:
        """加载剧情触发条件配置"""
        return {
            # 主线章节触发
            'main_chapters': [
                {
                    'chapter': 1,
                    'conditions': {
                        'affection_fond': 30,
                        'required_events': [],
                        'date_range': (1, 30)
                    }
                },
                {
                    'chapter': 2,
                    'conditions': {
                        'affection_fond': 50,
                        'required_events': ['E1'],
                        'date_range': (31, 60)
                    }
                },
                {
                    'chapter': 3,
                    'conditions': {
                        'affection_fond': 70,
                        'required_events': ['E1', 'E2'],
                        'date_range': (61, 90)
                    }
                }
            ],
            
            # 支线事件触发
            'side_events': [
                {
                    'event_id': 'E1',
                    'name': '初次约会',
                    'conditions': {
                        'affection_fond': 40,
                        'affection_intim': 30,
                        'date_range': (10, 50),
                        'time_of_day': 'afternoon'
                    }
                },
                {
                    'event_id': 'E2',
                    'name': '深夜谈心',
                    'conditions': {
                        'affection_trust': 60,
                        'affection_intim': 50,
                        'date_range': (30, 80),
                        'time_of_day': 'night'
                    }
                },
                {
                    'event_id': 'E3',
                    'name': '共同战斗',
                    'conditions': {
                        'affection_respect': 50,
                        'required_events': ['E1'],
                        'date_range': (20, 70)
                    }
                }
            ],
            
            # 路线解锁条件
            'route_unlocks': [
                {
                    'route': 1,  # 普通
                    'conditions': {
                        'affection_fond': 20
                    }
                },
                {
                    'route': 2,  # 友情
                    'conditions': {
                        'affection_fond': 50,
                        'affection_trust': 40
                    }
                },
                {
                    'route': 3,  # 恋爱
                    'conditions': {
                        'affection_fond': 70,
                        'affection_intim': 60,
                        'completed_events': ['E1', 'E2']
                    }
                },
                {
                    'route': 4,  # 专属
                    'conditions': {
                        'affection_fond': 85,
                        'affection_intim': 80,
                        'affection_trust': 75,
                        'completed_events': ['E1', 'E2', 'E3']
                    }
                }
            ]
        }
    
    def _load_endings(self) -> dict:
        """加载结局配置"""
        return {
            'true': {
                'name': '真结局',
                'condition': {
                    'min_affection': 85,
                    'required_events': 'all',
                    'final_choice': 'correct'
                }
            },
            'normal': {
                'name': '普通结局',
                'condition': {
                    'min_affection': 70
                }
            },
            'bad': {
                'name': '坏结局',
                'condition': {
                    'min_affection': 0
                }
            },
            'hidden': {
                'name': '隐藏结局',
                'condition': {
                    'special_requirements': 'specific'
                }
            }
        }
    
    def check_triggers(self, affection: dict, events_completed: set = None,
                      date: int = None, time_of_day: str = None) -> List[dict]:
        """
        检查三类触发条件 (公式139)
        
        - 好感度阈值: A_fond>=80, A_intim>=70
        - 事件完成: 必须完成E1, 不能完成E2
        - 时间条件: date范围 + 时间段 + 节日
        
        Args:
            affection: 当前好感度状态
            events_completed: 已完成的事件集合
            date: 游戏内日期
            time_of_day: 时间段 (morning/afternoon/evening/night)
        
        Returns:
            触发的事件列表
        """
        triggered = []
        events_completed = events_completed or self.completed_events
        
        # 1. 检查主线章节触发
        for chapter_config in self.triggers['main_chapters']:
            if self._check_conditions(chapter_config['conditions'], 
                                     affection, events_completed, date):
                if chapter_config['chapter'] > self.main_chapter:
                    triggered.append({
                        'type': 'main_chapter',
                        'chapter': chapter_config['chapter'],
                        'message': f"主线第{chapter_config['chapter']}章开启"
                    })
        
        # 2. 检查支线事件触发
        for event_config in self.triggers['side_events']:
            event_id = event_config['event_id']
            
            # 跳过已触发的事件
            if event_id in self.side_events:
                continue
            
            if self._check_conditions(event_config['conditions'],
                                     affection, events_completed, date, time_of_day):
                triggered.append({
                    'type': 'side_event',
                    'event_id': event_id,
                    'name': event_config['name'],
                    'message': f"触发支线事件: {event_config['name']}"
                })
        
        # 3. 检查路线解锁
        for route_config in self.triggers['route_unlocks']:
            if route_config['route'] <= self.route:
                continue
            
            if self._check_route_conditions(route_config['conditions'],
                                           affection, events_completed):
                triggered.append({
                    'type': 'route_unlock',
                    'route': route_config['route'],
                    'message': f"解锁新路线: {self._get_route_name(route_config['route'])}"
                })
        
        return triggered
    
    def _check_conditions(self, conditions: dict, affection: dict,
                         events_completed: set, date: int = None,
                         time_of_day: str = None) -> bool:
        """检查触发条件是否满足"""
        
        # 好感度条件
        for key, threshold in conditions.items():
            if key.startswith('affection_'):
                dim = key.replace('affection_', '')
                current_value = affection.get('state', {}).get(dim, 0)
                if current_value < threshold:
                    return False
            
            # 必需事件
            elif key == 'required_events':
                for event_id in threshold:
                    if event_id not in events_completed:
                        return False
            
            # 日期范围
            elif key == 'date_range' and date is not None:
                start, end = threshold
                if not (start <= date <= end):
                    return False
            
            # 时间段
            elif key == 'time_of_day' and time_of_day is not None:
                if time_of_day != threshold:
                    return False
            
            # 已完成事件列表
            elif key == 'completed_events':
                for event_id in threshold:
                    if event_id not in events_completed:
                        return False
        
        return True
    
    def _check_route_conditions(self, conditions: dict, affection: dict,
                               events_completed: set) -> bool:
        """检查路线解锁条件"""
        return self._check_conditions(conditions, affection, events_completed)
    
    def transition(self, event: str, choice: str = None):
        """
        状态转换
        
        优先级: 玩家选择 > 阈值触发 > 事件触发
        
        Args:
            event: 触发的事件类型
            choice: 玩家的选择 (如果有)
        """
        # 记录选择
        if choice:
            self.choices_history.append({
                'event': event,
                'choice': choice,
                'timestamp': datetime.now().isoformat()
            })
        
        # 根据事件类型更新状态
        if event.startswith('main_chapter_'):
            chapter = int(event.split('_')[-1])
            self.main_chapter = max(self.main_chapter, chapter)
        
        elif event.startswith('side_event_'):
            event_id = event.replace('side_event_', '')
            self.side_events.add(event_id)
            self.completed_events.add(event_id)
        
        elif event.startswith('route_'):
            route_id = int(event.split('_')[-1])
            self.route = max(self.route, route_id)
    
    def get_ending(self, affection: dict, choices: dict = None) -> str:
        """
        判定结局类型
        
        Args:
            affection: 最终好感度状态
            choices: 关键选择记录
        
        Returns:
            结局类型 (true/normal/bad/hidden)
        """
        avg_affection = sum(affection.get('state', {}).values()) / 4
        
        # 检查真结局条件
        if self._check_true_ending(affection, choices):
            return 'true'
        
        # 检查隐藏结局条件
        if self._check_hidden_ending(affection, choices):
            return 'hidden'
        
        # 检查普通结局条件
        if avg_affection >= 70:
            return 'normal'
        
        # 默认坏结局
        return 'bad'
    
    def _check_true_ending(self, affection: dict, choices: dict) -> bool:
        """检查真结局条件"""
        state = affection.get('state', {})
        
        # 多角色好感85+
        high_affection_count = sum(1 for v in state.values() if v >= 85)
        
        # 关键事件全完成
        all_events_completed = len(self.completed_events) >= 3
        
        # 最终选择正确 (简化判断)
        final_choice_correct = True
        if choices:
            final_choice_correct = choices.get('final_choice') == 'correct'
        
        return high_affection_count >= 2 and all_events_completed and final_choice_correct
    
    def _check_hidden_ending(self, affection: dict, choices: dict) -> bool:
        """检查隐藏结局条件"""
        # 特殊要求：例如特定选择序列、特殊事件等
        # 这里简化为需要完成所有事件且有特殊选择
        return len(self.completed_events) >= 3 and choices and choices.get('secret_found')
    
    def _get_route_name(self, route_id: int) -> str:
        """获取路线名称"""
        route_names = {
            0: "未解锁",
            1: "普通",
            2: "友情",
            3: "恋爱",
            4: "专属"
        }
        return route_names.get(route_id, "未知")
    
    def get_state(self) -> dict:
        """获取当前剧情状态"""
        return {
            'main_chapter': self.main_chapter,
            'route': self.route,
            'route_name': self._get_route_name(self.route),
            'side_events': list(self.side_events),
            'completed_events': list(self.completed_events),
            'choices_count': len(self.choices_history)
        }
