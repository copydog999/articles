import torch
import torch.nn as nn
from transformers import BertModel, BertTokenizer
from typing import List, Tuple


class LCFBERT(nn.Module):
    """
    基于LCF-BERT的方面级情感分析模型
    
    输入: text (str), max_length=128
    输出: List[Tuple[aspect, sentiment, intensity]]
        - aspect: str, 方面术语
        - sentiment: -1/0/1 (负面/中性/正面)
        - intensity: float in [0,1]
    """
    
    def __init__(self, num_aspects: int = 18, num_sentiments: int = 3, 
                 local_window_size: int = 3):
        super(LCFBERT, self).__init__()
        
        # BERT backbone
        self.bert = BertModel.from_pretrained('bert-base-chinese')
        self.hidden_size = 768
        self.local_window_size = local_window_size
        
        # 方面抽取头: Linear + CRF层
        self.aspect_classifier = nn.Sequential(
            nn.Linear(self.hidden_size, self.hidden_size // 2),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(self.hidden_size // 2, num_aspects)
        )
        
        # 情感分类头: Linear + Softmax
        self.sentiment_classifier = nn.Sequential(
            nn.Linear(self.hidden_size * 3, self.hidden_size),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(self.hidden_size, num_sentiments)
        )
        
        # 强度回归头: Linear + Tanh
        self.intensity_regressor = nn.Sequential(
            nn.Linear(self.hidden_size * 3, self.hidden_size),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(self.hidden_size, 1),
            nn.Tanh()
        )
        
        # 方面类别映射 (6大类18子类)
        self.aspect_categories = {
            'appearance': ['外貌_整体', '外貌_眼睛', '外貌_发型', '外貌_服装'],
            'personality': ['性格_温柔', '性格_活泼', '性格_冷静', '性格_傲娇'],
            'behavior': ['行为_日常', '行为_战斗', '行为_学习', '行为_社交'],
            'experience': ['经历_过去', '经历_现在', '经历_未来', '经历_梦想'],
            'emotion': ['情感_喜悦', '情感_悲伤', '情感_愤怒', '情感_恐惧'],
            'conflict': ['冲突_人际', '冲突_内心', '冲突_环境']
        }
        
        # 程度副词调节系数
        self.degree_modifiers = {
            '极': 2.0, '非常': 1.5, '很': 1.3, '比较': 1.1,
            '稍微': 0.8, '有点': 0.7, '略微': 0.6, '几乎不': 0.3
        }
        
        # 否定词列表
        self.negation_words = ['不', '没', '没有', '非', '无', '未', '别', '莫']
    
    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor,
                aspect_positions: torch.Tensor = None):
        """
        前向传播
        
        Args:
            input_ids: [batch_size, seq_len]
            attention_mask: [batch_size, seq_len]
            aspect_positions: [batch_size, num_aspects] 方面词位置索引
        
        Returns:
            aspect_logits: [batch_size, seq_len, num_aspects]
            sentiment_logits: [batch_size, num_aspects, 3]
            intensity: [batch_size, num_aspects, 1]
        """
        # BERT编码
        outputs = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        cls_embedding = outputs.last_hidden_state[:, 0, :]  # [batch, 768]
        token_embeddings = outputs.last_hidden_state  # [batch, seq_len, 768]
        
        batch_size, seq_len, _ = token_embeddings.shape
        
        # 方面感知注意力机制 (公式70)
        if aspect_positions is not None:
            # 局部窗口注意力
            h_local = self._local_context_attention(token_embeddings, aspect_positions)
            
            # 方面嵌入
            h_aspect = self._extract_aspect_embeddings(token_embeddings, aspect_positions)
            
            # 拼接: [h_cls; h_local; h_aspect]
            combined = torch.cat([cls_embedding.unsqueeze(1).expand(-1, seq_len, -1),
                                  h_local, h_aspect], dim=-1)  # [batch, seq_len, 768*3]
        else:
            # 如果没有方面位置，使用全局上下文
            h_local = token_embeddings
            h_aspect = token_embeddings
            combined = torch.cat([cls_embedding.unsqueeze(1).expand(-1, seq_len, -1),
                                  h_local, h_aspect], dim=-1)
        
        # 方面抽取
        aspect_logits = self.aspect_classifier(token_embeddings)  # [batch, seq_len, num_aspects]
        
        # 情感分类和强度回归 (对每个检测到的方面)
        sentiment_logits = self.sentiment_classifier(combined)  # [batch, seq_len, 3]
        intensity = self.intensity_regressor(combined)  # [batch, seq_len, 1]
        
        return aspect_logits, sentiment_logits, intensity
    
    def _local_context_attention(self, token_embeddings: torch.Tensor,
                                  aspect_positions: torch.Tensor) -> torch.Tensor:
        """
        局部上下文注意力机制 (公式70)
        h_local = Σ α_k · h_k, where α_k = softmax(h_a^T · h_k)
        """
        batch_size, seq_len, hidden_size = token_embeddings.shape
        
        # 获取方面词的嵌入
        h_aspect = self._extract_aspect_embeddings(token_embeddings, aspect_positions)
        
        # 计算注意力分数
        # 对于每个位置，考虑其局部窗口内的token
        h_local_list = []
        for i in range(seq_len):
            # 定义局部窗口
            start = max(0, i - self.local_window_size)
            end = min(seq_len, i + self.local_window_size + 1)
            
            # 提取局部上下文
            local_context = token_embeddings[:, start:end, :]  # [batch, window_size, hidden]
            
            # 计算注意力权重
            aspect_expanded = h_aspect[:, i:i+1, :]  # [batch, 1, hidden]
            attention_scores = torch.bmm(local_context, aspect_expanded.transpose(1, 2))
            # [batch, window_size, 1]
            attention_weights = torch.softmax(attention_scores, dim=1)
            
            # 加权求和
            weighted_sum = torch.bmm(attention_weights.transpose(1, 2), local_context)
            # [batch, 1, hidden]
            h_local_list.append(weighted_sum)
        
        h_local = torch.cat(h_local_list, dim=1)  # [batch, seq_len, hidden]
        return h_local
    
    def _extract_aspect_embeddings(self, token_embeddings: torch.Tensor,
                                    aspect_positions: torch.Tensor) -> torch.Tensor:
        """提取方面词的嵌入表示"""
        batch_size, seq_len, hidden_size = token_embeddings.shape
        
        # 根据方面位置索引提取对应的嵌入
        # aspect_positions: [batch, num_aspects]
        indices = aspect_positions.clamp(0, seq_len - 1).unsqueeze(-1).expand(-1, -1, hidden_size)
        h_aspect = torch.gather(token_embeddings, 1, indices)  # [batch, num_aspects, hidden]
        
        return h_aspect
    
    def analyze(self, text: str, tokenizer: BertTokenizer, 
                device: str = 'cpu') -> List[Tuple[str, int, float]]:
        """
        分析文本中的方面和情感
        
        Args:
            text: 输入文本
            tokenizer: BERT分词器
            device: 计算设备
        
        Returns:
            List of (aspect_name, sentiment_polarity, intensity)
        """
        self.eval()
        
        # 编码输入
        inputs = tokenizer(text, return_tensors='pt', max_length=128,
                          truncation=True, padding='max_length')
        input_ids = inputs['input_ids'].to(device)
        attention_mask = inputs['attention_mask'].to(device)
        
        with torch.no_grad():
            aspect_logits, sentiment_logits, intensity = self.forward(
                input_ids, attention_mask
            )
        
        # 解码方面标签
        aspect_probs = torch.softmax(aspect_logits, dim=-1)
        sentiment_probs = torch.softmax(sentiment_logits, dim=-1)
        
        # 提取方面-情感三元组
        results = []
        seq_len = aspect_logits.shape[1]
        
        for i in range(seq_len):
            # 找到最可能的方面类别
            aspect_idx = torch.argmax(aspect_probs[0, i]).item()
            aspect_conf = aspect_probs[0, i, aspect_idx].item()
            
            # 置信度阈值过滤
            if aspect_conf < 0.5:
                continue
            
            # 获取情感极性
            sent_idx = torch.argmax(sentiment_probs[0, i]).item()
            sentiment = sent_idx - 1  # -1, 0, 1
            
            # 获取强度
            intensity_val = intensity[0, i, 0].item()
            intensity_val = (intensity_val + 1) / 2  # 映射到[0, 1]
            
            # 应用修饰词调节
            intensity_val = self._apply_modifiers(text, intensity_val)
            
            # 映射方面索引到名称
            aspect_name = self._map_aspect_index(aspect_idx)
            
            results.append((aspect_name, sentiment, round(intensity_val, 3)))
        
        return results
    
    def _apply_modifiers(self, text: str, base_intensity: float) -> float:
        """应用程度副词和否定词调节"""
        intensity = base_intensity
        
        # 检查程度副词
        for modifier, factor in self.degree_modifiers.items():
            if modifier in text:
                intensity *= factor
                break
        
        # 检查否定词
        for neg_word in self.negation_words:
            if neg_word in text:
                # 极性反转，强度调整为0.7
                intensity *= 0.7
                break
        
        # 限制在[0, 1]范围内
        return max(0.0, min(1.0, intensity))
    
    def _map_aspect_index(self, idx: int) -> str:
        """将方面索引映射为可读名称"""
        all_aspects = []
        for category, aspects in self.aspect_categories.items():
            all_aspects.extend(aspects)
        
        if idx < len(all_aspects):
            return all_aspects[idx]
        return f"未知方面_{idx}"
