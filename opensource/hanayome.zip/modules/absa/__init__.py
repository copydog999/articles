from .model import LCFBERT
from typing import List, Tuple
import torch
from transformers import BertTokenizer


class ABSAService:
    """ABSA情感分析服务封装"""
    
    def __init__(self, model_path: str = None, device: str = 'cpu'):
        self.device = device
        self.model = LCFBERT(num_aspects=18, num_sentiments=3)
        
        if model_path:
            self.model.load_state_dict(torch.load(model_path, map_location=device))
        
        self.model.to(device)
        self.tokenizer = BertTokenizer.from_pretrained('bert-base-chinese')
    
    async def analyze(self, text: str) -> List[Tuple[str, int, float]]:
        """
        异步分析文本
        
        Args:
            text: 用户输入文本
        
        Returns:
            [(aspect, sentiment, intensity), ...]
        """
        return self.model.analyze(text, self.tokenizer, self.device)
