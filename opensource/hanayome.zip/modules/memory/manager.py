import chromadb
from chromadb.config import Settings
from typing import List, Dict, Optional
from datetime import datetime
import math


class MemoryManager:
    """
    记忆管理系统
    
    短期记忆: 滑动窗口，保留最近k=5轮对话
    长期记忆: Chroma向量数据库，768维嵌入(text2vec-large-chinese)
    """
    
    def __init__(self, collection_name: str = "hanayome_memories",
                 persist_directory: str = "./data/chroma_db"):
        # 短期记忆 (滑动窗口)
        self.short_term_window = 5
        self.short_term = []  # 最多5轮，FIFO
        
        # 长期记忆 (Chroma向量数据库)
        self.client = chromadb.PersistentClient(path=persist_directory)
        
        # 创建或获取集合
        self.collection = self.client.get_or_create_collection(
            name=collection_name,
            metadata={"description": "Hanayome long-term memory"}
        )
        
        # 检索配置
        self.long_term_top_k = 3
        self.w_emo_base = 0.5
        self.w_time_decay = 0.1
        
        # 压缩配置
        self.compression_threshold = 1000
        self.compression_ratio = 0.2
        
        # 记忆计数器
        self.memory_count = 0
    
    def add_memory(self, turn: dict):
        """
        添加一轮对话到记忆系统
        
        Args:
            turn: {
                'user_input': str,
                'response': str,
                'affection_state': dict,
                'emotion_intensity': float,
                'timestamp': datetime
            }
        """
        timestamp = turn.get('timestamp', datetime.now())
        
        # 添加到短期记忆
        short_term_entry = {
            'user_input': turn['user_input'],
            'response': turn['response'],
            'affection_state': turn.get('affection_state', {}),
            'timestamp': timestamp
        }
        
        self.short_term.append(short_term_entry)
        
        # 保持滑动窗口大小
        if len(self.short_term) > self.short_term_window:
            self.short_term.pop(0)
        
        # 异步存储到长期记忆 (向量数据库)
        memory_text = f"{turn['user_input']} {turn['response']}"
        emotion_intensity = turn.get('emotion_intensity', 0.5)
        
        # 生成唯一ID
        memory_id = f"mem_{self.memory_count}_{int(timestamp.timestamp())}"
        
        # 存储元数据
        metadata = {
            'timestamp': timestamp.isoformat(),
            'emotion_intensity': emotion_intensity,
            'affection_snapshot': str(turn.get('affection_state', {})),
            'user_input': turn['user_input'],
            'response': turn['response']
        }
        
        # 注意: 实际使用时需要text2vec模型生成embedding
        # 这里使用简化版本，实际部署时需要集成text2vec-large-chinese
        try:
            self.collection.add(
                ids=[memory_id],
                documents=[memory_text],
                metadatas=[metadata]
            )
            self.memory_count += 1
        except Exception as e:
            print(f"Warning: Failed to add memory to ChromaDB: {e}")
        
        # 检查是否需要压缩
        if self.memory_count > self.compression_threshold:
            self.compress()
    
    async def retrieve(self, query: str, affection_state: dict) -> List[dict]:
        """
        情感加权检索 (公式113)
        
        Score = w_emo · w_time · cos(e_q, e_m)
        w_emo = 0.5 + 0.5·p_m
        w_time = exp(-0.1·Δt_days)
        
        Args:
            query: 查询文本
            affection_state: 当前好感度状态
        
        Returns:
            Top-3相关记忆
        """
        try:
            # 从ChromaDB检索相似记忆
            results = self.collection.query(
                query_texts=[query],
                n_results=self.long_term_top_k * 2  # 获取更多候选进行重排序
            )
            
            if not results['ids'] or not results['ids'][0]:
                return []
            
            # 计算情感加权分数
            scored_memories = []
            now = datetime.now()
            
            for i, memory_id in enumerate(results['ids'][0]):
                metadata = results['metadatas'][0][i]
                document = results['documents'][0][i]
                distance = results['distances'][0][i] if 'distances' in results else 0
                
                # 余弦相似度 (Chroma返回的是距离，需要转换)
                cos_similarity = 1 - distance
                
                # 情感权重 (公式113)
                p_m = metadata.get('emotion_intensity', 0.5)
                w_emo = self.w_emo_base + 0.5 * p_m
                
                # 时间权重 (公式113)
                mem_timestamp = datetime.fromisoformat(metadata['timestamp'])
                delta_t_days = (now - mem_timestamp).days
                w_time = math.exp(-self.w_time_decay * delta_t_days)
                
                # 综合得分
                score = w_emo * w_time * cos_similarity
                
                scored_memories.append({
                    'id': memory_id,
                    'content': document,
                    'metadata': metadata,
                    'score': score
                })
            
            # 按得分排序，返回Top-K
            scored_memories.sort(key=lambda x: x['score'], reverse=True)
            return scored_memories[:self.long_term_top_k]
        
        except Exception as e:
            print(f"Warning: Failed to retrieve memories: {e}")
            return []
    
    def compress(self):
        """
        记忆压缩
        
        当记忆数量>1000时，删除重要性最低的20%
        重要性 = 0.5·p_m + 0.3·关键事件标记 + 0.2·参与度
        """
        try:
            # 获取所有记忆
            all_memories = self.collection.get()
            
            if not all_memories['ids']:
                return
            
            # 计算每个记忆的重要性分数
            importance_scores = []
            now = datetime.now()
            
            for i, memory_id in enumerate(all_memories['ids']):
                metadata = all_memories['metadatas'][i]
                
                # 情感强度
                p_m = metadata.get('emotion_intensity', 0.5)
                
                # 关键事件标记 (简化：检查是否包含特定关键词)
                key_event_keywords = ['告白', '约定', '秘密', '重要', '第一次']
                is_key_event = any(kw in metadata.get('user_input', '') 
                                   for kw in key_event_keywords)
                key_event_score = 1.0 if is_key_event else 0.0
                
                # 参与度 (基于好感度变化)
                affection_snapshot = metadata.get('affection_snapshot', '{}')
                participation_score = 0.5  # 默认值，实际应分析好感度变化
                
                # 综合重要性
                importance = (0.5 * p_m + 
                             0.3 * key_event_score + 
                             0.2 * participation_score)
                
                importance_scores.append((memory_id, importance))
            
            # 按重要性排序
            importance_scores.sort(key=lambda x: x[1])
            
            # 删除重要性最低的20%
            num_to_delete = int(len(importance_scores) * self.compression_ratio)
            ids_to_delete = [x[0] for x in importance_scores[:num_to_delete]]
            
            if ids_to_delete:
                self.collection.delete(ids=ids_to_delete)
                self.memory_count -= len(ids_to_delete)
                print(f"Compressed memory: deleted {len(ids_to_delete)} memories")
        
        except Exception as e:
            print(f"Warning: Failed to compress memories: {e}")
    
    def get_short_term_history(self) -> List[dict]:
        """获取短期记忆历史"""
        return self.short_term.copy()
    
    def clear_short_term(self):
        """清空短期记忆"""
        self.short_term = []
    
    def get_stats(self) -> dict:
        """获取记忆统计信息"""
        return {
            'short_term_count': len(self.short_term),
            'long_term_count': self.memory_count,
            'short_term_window': self.short_term_window
        }
