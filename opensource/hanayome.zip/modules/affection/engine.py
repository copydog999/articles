import math
from typing import List, Tuple, Dict
from datetime import datetime


class AffectionEngine:
    """
    好感度引擎
    
    维护四维好感度向量 A = [fond, trust, intim, respect], 范围[0,100]
    """
    
    def __init__(self, role_config: dict = None):
        # 初始状态
        self.state = {
            "fond": 0.0,      # 好感度
            "trust": 0.0,     # 信任度
            "intim": 0.0,     # 亲密度
            "respect": 0.0    # 尊敬度
        }
        
        # 方面权重表 (6大类 -> [w_fond, w_trust, w_intim, w_respect])
        self.aspect_weights = {
            'appearance': [0.3, 0.1, 0.4, 0.2],
            'personality': [0.4, 0.3, 0.1, 0.2],
            'behavior': [0.2, 0.2, 0.3, 0.3],
            'experience': [0.3, 0.3, 0.2, 0.2],
            'emotion': [0.5, 0.2, 0.2, 0.1],
            'conflict': [0.1, 0.4, 0.1, 0.4]
        }
        
        # 角色敏感度系数 [0.5, 1.5]
        self.role_sensitivity = {
            'appearance': 1.0,
            'personality': 1.2,
            'behavior': 1.0,
            'experience': 0.8,
            'emotion': 1.3,
            'conflict': 0.9
        }
        
        # 好感度等级划分
        self.levels = [0, 10, 30, 50, 70, 85, 100]
        self.level_names = ["陌生人", "认识", "朋友", "亲密", "喜欢", "爱恋"]
        
        # 历史记录 (用于衰减计算)
        self.interaction_history = []
        self.last_update_time = datetime.now()
        
        # 配置参数
        self.max_value = 100.0
        self.marginal_decay_rate = 0.3
        self.forgetting_half_life = 30  # 天
        self.update_gamma = 0.5
    
    def update(self, aspects: List[Tuple[str, int, float]]) -> Dict[str, float]:
        """
        根据ABSA分析结果更新好感度
        
        公式81: ΔA = Σ w(a)·s·p·r(a)·γ
        
        Args:
            aspects: [(aspect_name, sentiment_polarity, intensity), ...]
                - aspect_name: 方面类别 (appearance/personality/...)
                - sentiment_polarity: -1/0/1
                - intensity: [0, 1]
        
        Returns:
            更新后的state
        """
        now = datetime.now()
        
        for aspect_name, sentiment, intensity in aspects:
            # 确定方面所属大类
            category = self._get_aspect_category(aspect_name)
            
            if category not in self.aspect_weights:
                continue
            
            # 获取权重向量
            weights = self.aspect_weights[category]
            
            # 获取角色敏感度
            sensitivity = self.role_sensitivity.get(category, 1.0)
            
            # 计算每个维度的增量
            for i, dim in enumerate(['fond', 'trust', 'intim', 'respect']):
                w_a = weights[i]  # 方面权重
                s = sentiment      # 情感极性 (-1, 0, 1)
                p = intensity      # 强度 [0, 1]
                r_a = sensitivity  # 角色敏感度
                gamma = self.update_gamma  # 学习率
                
                # 基础增量 (公式81)
                delta = w_a * s * p * r_a * gamma
                
                # 应用边际效应递减 (公式84)
                interaction_count = self._get_interaction_count(dim)
                if interaction_count > 0:
                    decay_factor = math.exp(-self.marginal_decay_rate * (interaction_count - 1))
                    delta *= decay_factor
                
                # 更新状态
                self.state[dim] += delta
        
        # 边界裁剪 [0, 100]
        for dim in self.state:
            self.state[dim] = max(0.0, min(self.max_value, self.state[dim]))
        
        # 记录交互历史
        self.interaction_history.append({
            'timestamp': now,
            'aspects': aspects,
            'delta': {k: v for k, v in self.state.items()}
        })
        
        self.last_update_time = now
        
        return self.state.copy()
    
    def apply_forgetting_curve(self):
        """
        应用遗忘曲线衰减 (公式85)
        A(t) = A0 · exp(-t / 30)
        """
        now = datetime.now()
        days_since_last = (now - self.last_update_time).days
        
        if days_since_last > 0:
            decay_factor = math.exp(-days_since_last / self.forgetting_half_life)
            
            for dim in self.state:
                self.state[dim] *= decay_factor
                self.state[dim] = max(0.0, self.state[dim])
            
            self.last_update_time = now
    
    def get_level(self, dim: str) -> int:
        """
        获取好感度等级 (0-5)
        
        6级划分: 0-10%/10-30%/30-50%/50-70%/70-85%/85-100%
        对应: 陌生人/认识/朋友/亲密/喜欢/爱恋
        
        Args:
            dim: 维度名称 (fond/trust/intim/respect)
        
        Returns:
            等级索引 (0-5)
        """
        value = self.state.get(dim, 0)
        
        for i in range(len(self.levels) - 1):
            if self.levels[i] <= value < self.levels[i + 1]:
                return i
        
        return len(self.levels) - 2  # 最高等级
    
    def get_level_name(self, dim: str) -> str:
        """获取好感度等级名称"""
        level_idx = self.get_level(dim)
        return self.level_names[level_idx]
    
    def get_dialogue_params(self) -> dict:
        """
        根据好感度计算对话生成参数
        
        Returns:
            {
                'address_form': 称呼形式,
                'response_length': 回复长度,
                'active_prob': 主动对话概率,
                'self_disclosure': 自我披露等级
            }
        """
        fond_level = self.get_level('fond')
        trust_level = self.get_level('trust')
        avg_affection = sum(self.state.values()) / 4
        
        # 称呼形式
        address_forms = ['姓氏+尊称', '名字', '昵称', '昵称', '爱称', '爱称']
        address_form = address_forms[min(fond_level, len(address_forms) - 1)]
        
        # 回复长度调节 (公式104): L = 5 + 45(A/100)^0.8
        response_length = 5 + 45 * (avg_affection / 100) ** 0.8
        
        # 主动对话概率 (公式102): P = 0.2 + 0.15L
        active_prob = 0.2 + 0.15 * fond_level
        
        # 自我披露等级: 5 * (1 - exp(-A_trust/30))
        self_disclosure = 5 * (1 - math.exp(-self.state['trust'] / 30))
        
        return {
            'address_form': address_form,
            'response_length': int(response_length),
            'active_prob': min(1.0, active_prob),
            'self_disclosure': round(self_disclosure, 2)
        }
    
    def _get_aspect_category(self, aspect_name: str) -> str:
        """将具体方面映射到大类"""
        # 简单映射逻辑，实际可配置化
        category_map = {
            '外貌_整体': 'appearance', '外貌_眼睛': 'appearance',
            '外貌_发型': 'appearance', '外貌_服装': 'appearance',
            '性格_温柔': 'personality', '性格_活泼': 'personality',
            '性格_冷静': 'personality', '性格_傲娇': 'personality',
            '行为_日常': 'behavior', '行为_战斗': 'behavior',
            '行为_学习': 'behavior', '行为_社交': 'behavior',
            '经历_过去': 'experience', '经历_现在': 'experience',
            '经历_未来': 'experience', '经历_梦想': 'experience',
            '情感_喜悦': 'emotion', '情感_悲伤': 'emotion',
            '情感_愤怒': 'emotion', '情感_恐惧': 'emotion',
            '冲突_人际': 'conflict', '冲突_内心': 'conflict',
            '冲突_环境': 'conflict'
        }
        
        return category_map.get(aspect_name, 'personality')
    
    def _get_interaction_count(self, dim: str) -> int:
        """获取某维度的交互次数"""
        count = 0
        for record in self.interaction_history:
            for aspect_name, sentiment, intensity in record['aspects']:
                category = self._get_aspect_category(aspect_name)
                if category in self.aspect_weights:
                    weights = self.aspect_weights[category]
                    dim_idx = ['fond', 'trust', 'intim', 'respect'].index(dim)
                    if weights[dim_idx] > 0:
                        count += 1
        return count
    
    def get_state(self) -> dict:
        """获取当前好感度状态"""
        return {
            'state': self.state.copy(),
            'levels': {
                dim: {
                    'value': self.state[dim],
                    'level': self.get_level(dim),
                    'level_name': self.get_level_name(dim)
                }
                for dim in self.state
            },
            'dialogue_params': self.get_dialogue_params()
        }
