import asyncio
import time
from typing import Dict, List
from datetime import datetime

from modules.absa import ABSAService
from modules.affection import AffectionEngine
from modules.memory import MemoryManager
from modules.dialogue import DialogueGenerator
from modules.story import StoryStateMachine


class HanayomeAgent:
    """
    Hanayome-Agent 主控制器
    
    整合所有模块，实现完整的对话处理流程
    """
    
    def __init__(self, config: dict = None):
        self.config = config or {}
        
        # 初始化各模块
        print("Initializing Hanayome-Agent modules...")
        
        # 1. ABSA情感分析模块
        absa_config = self.config.get('MODEL', {}).get('absa', {})
        self.absa = ABSAService(
            device=self.config.get('device', 'cpu')
        )
        
        # 2. 好感度引擎
        affection_config = self.config.get('AFFECTION', {})
        role_config = self.config.get('role', {})
        self.affection = AffectionEngine(role_config=role_config)
        
        # 3. 记忆管理系统
        memory_config = self.config.get('MEMORY', {})
        self.memory = MemoryManager()
        
        # 4. 对话生成器
        dialogue_config = self.config.get('MODEL', {}).get('dialogue', {})
        model_path = self.config.get('model_path', None)
        self.dialogue = DialogueGenerator(
            model_path=model_path,
            config=dialogue_config
        )
        
        # 5. 剧情状态机
        story_config = self.config.get('STORY', {})
        self.story = StoryStateMachine(story_config=story_config)
        
        # 性能监控
        self.performance_stats = {
            'total_requests': 0,
            'avg_latency': 0,
            'latencies': []
        }
        
        print("Hanayome-Agent initialized successfully!")
    
    async def process_turn(self, user_input: str, 
                          role_config: dict = None,
                          game_date: int = None,
                          time_of_day: str = None) -> dict:
        """
        处理一轮对话 (主流程)
        
        并行处理 + 串行依赖 (公式34)
        
        Args:
            user_input: 玩家输入
            role_config: 角色配置
            game_date: 游戏内日期
            time_of_day: 时间段
        
        Returns:
            {
                'response': str,           # AI回复
                'emotion': str,            # 情感标签
                'affection': dict,         # 好感度状态
                'events': List[dict],      # 触发的事件
                'latency': float,          # 处理延迟
                'memory_stats': dict       # 记忆统计
            }
        """
        start_time = time.time()
        role_config = role_config or self._get_default_role_config()
        
        try:
            # ========== 阶段1: 并行处理 (目标 <200ms) ==========
            print(f"\n[Turn {self.performance_stats['total_requests'] + 1}] Processing user input: {user_input[:50]}...")
            
            # 分支A: ABSA分析
            absa_task = asyncio.create_task(self.absa.analyze(user_input))
            
            # 分支B: 记忆检索
            memory_task = asyncio.create_task(
                self.memory.retrieve(user_input, self.affection.get_state())
            )
            
            # 等待并行任务完成
            aspects, memories = await asyncio.gather(absa_task, memory_task)
            
            absa_time = time.time() - start_time
            print(f"  ✓ ABSA analysis completed in {absa_time*1000:.1f}ms")
            print(f"  ✓ Memory retrieval completed, found {len(memories)} relevant memories")
            
            # ========== 阶段2: 好感度更新 (<50ms) ==========
            update_start = time.time()
            delta = self.affection.update(aspects)
            
            # 应用遗忘曲线
            self.affection.apply_forgetting_curve()
            
            update_time = time.time() - update_start
            print(f"  ✓ Affection updated in {update_time*1000:.1f}ms")
            
            # ========== 阶段3: 剧情触发检查 ==========
            triggered_events = self.story.check_triggers(
                affection=self.affection.get_state(),
                events_completed=self.story.completed_events,
                date=game_date,
                time_of_day=time_of_day
            )
            
            if triggered_events:
                print(f"  ✓ Triggered {len(triggered_events)} events:")
                for event in triggered_events:
                    print(f"    - {event['message']}")
            
            # ========== 阶段4: 构建提示词 + LLM生成 (<2.5s) ==========
            llm_start = time.time()
            
            # 获取短期记忆历史
            short_term_history = self.memory.get_short_term_history()
            
            # 构建提示词
            prompt = self.dialogue.build_prompt(
                role_config=role_config,
                affection=self.affection.get_state(),
                memories=memories,
                history=short_term_history,
                user_input=user_input
            )
            
            # LLM生成
            response, emotion = await self.dialogue.generate(prompt)
            
            llm_time = time.time() - llm_start
            print(f"  ✓ LLM generation completed in {llm_time*1000:.1f}ms")
            
            # ========== 阶段5: 后处理 + 记忆存储 ==========
            post_start = time.time()
            
            # 计算情感强度 (用于记忆存储)
            emotion_intensity = self._calculate_emotion_intensity(aspects)
            
            # 存储到记忆系统
            turn_data = {
                'user_input': user_input,
                'response': response,
                'affection_state': self.affection.get_state(),
                'emotion_intensity': emotion_intensity,
                'timestamp': datetime.now()
            }
            self.memory.add_memory(turn_data)
            
            post_time = time.time() - post_start
            
            # ========== 性能统计 ==========
            total_time = time.time() - start_time
            self.performance_stats['total_requests'] += 1
            self.performance_stats['latencies'].append(total_time)
            
            # 计算平均延迟
            latencies = self.performance_stats['latencies']
            self.performance_stats['avg_latency'] = sum(latencies) / len(latencies)
            
            print(f"  ✓ Post-processing completed in {post_time*1000:.1f}ms")
            print(f"  ✓ Total latency: {total_time*1000:.1f}ms")
            
            # ========== 返回结果 ==========
            return {
                'response': response,
                'emotion': emotion,
                'affection': self.affection.get_state(),
                'events': triggered_events,
                'aspects': aspects,
                'latency': total_time,
                'memory_stats': self.memory.get_stats(),
                'story_state': self.story.get_state(),
                'performance': {
                    'absa_time': absa_time,
                    'update_time': update_time,
                    'llm_time': llm_time,
                    'total_time': total_time,
                    'avg_latency': self.performance_stats['avg_latency']
                }
            }
        
        except Exception as e:
            print(f"Error processing turn: {e}")
            import traceback
            traceback.print_exc()
            
            # 返回错误响应
            return {
                'response': "抱歉，我遇到了一些问题。请重试。",
                'emotion': '中性',
                'affection': self.affection.get_state(),
                'events': [],
                'error': str(e),
                'latency': time.time() - start_time
            }
    
    def _calculate_emotion_intensity(self, aspects: List) -> float:
        """计算整体情感强度"""
        if not aspects:
            return 0.5
        
        # 取平均强度
        intensities = [abs(intensity) for _, _, intensity in aspects]
        avg_intensity = sum(intensities) / len(intensities)
        
        return avg_intensity
    
    def _get_default_role_config(self) -> dict:
        """获取默认角色配置"""
        return {
            'name': '花嫁',
            'age': 18,
            'personality': '温柔、善良、有点害羞',
            'speaking_style': '轻柔、礼貌、偶尔带点俏皮',
            'backstory': '一位来自异世界的少女，与玩家有着特殊的羁绊。'
        }
    
    def get_agent_status(self) -> dict:
        """获取Agent当前状态"""
        return {
            'affection': self.affection.get_state(),
            'story': self.story.get_state(),
            'memory': self.memory.get_stats(),
            'performance': {
                'total_requests': self.performance_stats['total_requests'],
                'avg_latency': self.performance_stats['avg_latency']
            }
        }
    
    def reset(self):
        """重置Agent状态"""
        self.affection = AffectionEngine()
        self.memory = MemoryManager()
        self.story = StoryStateMachine()
        self.performance_stats = {
            'total_requests': 0,
            'avg_latency': 0,
            'latencies': []
        }
        print("Agent state reset.")
