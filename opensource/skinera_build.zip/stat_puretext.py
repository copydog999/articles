"""
CS2 饰品数据集 - 完整文本统计报告
输出所有统计数据，不生成图表
"""

import pandas as pd
import numpy as np
from pathlib import Path
from scipy.stats import skew, kurtosis, pearsonr
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# 路径配置
# ============================================================
SCRIPT_DIR = Path(__file__).parent.absolute()
DATA_PATH = SCRIPT_DIR / "merged_dataset" / "merged_price_data.parquet"
OUTPUT_FILE = SCRIPT_DIR / "merged_dataset" / "statistics_report.txt"

print("=" * 80)
print("CS2 饰品数据集 - 统计分析报告")
print(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print("=" * 80)

# ============================================================
# 加载数据
# ============================================================
print("\n加载数据中...")
df = pd.read_parquet(DATA_PATH)
print(f"数据加载完成\n")

# ============================================================
# 预处理（添加时间特征）
# ============================================================
print("预处理中...")
df['daily_value'] = df['price_dollar'] * df['sells']
df['log_price'] = np.log1p(df['price_dollar'])
df['date'] = pd.to_datetime(df['date'])
df['year'] = df['date'].dt.year
df['month'] = df['date'].dt.month
df['dayofweek'] = df['date'].dt.dayofweek  # 周一=0, 周日=6
df['quarter'] = df['date'].dt.quarter
print("预处理完成\n")

# 筛选
skins_df = df[df['item_type'] == 'skin'].copy()
skins_with_wear = skins_df[skins_df['wear'].notna()].copy()
stickers_df = df[df['item_type'] == 'sticker'].copy()
crates_df = df[df['item_type'] == 'crate'].copy()
agents_df = df[df['item_type'] == 'agent'].copy()

# 准备输出
lines = []
lines.append("=" * 80)
lines.append("CS2 饰品数据集统计分析报告")
lines.append("=" * 80)
lines.append(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
lines.append("")

# ============================================================
# 一、数据集基本信息
# ============================================================
lines.append("=" * 80)
lines.append("一、数据集基本信息")
lines.append("=" * 80)
lines.append(f"  总记录数（价格-日期对）: {len(df):,}")
lines.append(f"  物品总数: {df['item_file_name'].nunique():,}")
lines.append(f"  日期范围: {df['date'].min().date()} ~ {df['date'].max().date()}")
lines.append(f"  时间跨度（天）: {(df['date'].max() - df['date'].min()).days}")
lines.append(f"  匹配到静态属性的物品数: {df[df['has_static_attrs']]['item_file_name'].nunique():,}")
lines.append(f"  静态属性匹配率: {df[df['has_static_attrs']]['item_file_name'].nunique() / df['item_file_name'].nunique() * 100:.1f}%")
lines.append("")

# ============================================================
# 二、价格统计
# ============================================================
lines.append("=" * 80)
lines.append("二、价格统计")
lines.append("=" * 80)

# 基本统计
lines.append(f"  价格最小值: ${df['price_dollar'].min():.4f}")
lines.append(f"  价格最大值: ${df['price_dollar'].max():.2f}")
lines.append(f"  价格平均值: ${df['price_dollar'].mean():.4f}")
lines.append(f"  价格中位数: ${df['price_dollar'].median():.4f}")
lines.append(f"  价格标准差: ${df['price_dollar'].std():.4f}")
lines.append(f"  价格偏度: {skew(df['price_dollar']):.4f}")
lines.append(f"  价格峰度: {kurtosis(df['price_dollar']):.4f}")
lines.append(f"  价格变异系数: {df['price_dollar'].std() / df['price_dollar'].mean():.4f}")

# 分位数
lines.append(f"\n  价格分位数:")
for p in [1, 5, 10, 25, 50, 75, 90, 95, 99]:
    val = np.percentile(df['price_dollar'], p)
    lines.append(f"    {p}%: ${val:.4f}")

# 价格区间分布
lines.append(f"\n  价格区间分布:")
bins = [0, 1, 5, 10, 20, 50, 100, 500, 1000, 10000, 100000]
labels = ['$0-1', '$1-5', '$5-10', '$10-20', '$20-50', '$50-100', '$100-500', '$500-1000', '$1000-10000', '$10000+']
df['price_bin'] = pd.cut(df['price_dollar'], bins=bins, labels=labels)
price_bin_counts = df['price_bin'].value_counts()
for bin_label in labels:
    if bin_label in price_bin_counts.index:
        count = price_bin_counts[bin_label]
        lines.append(f"    {bin_label}: {count:,} 条记录 ({count/len(df)*100:.2f}%)")

# 最高价物品 TOP20
lines.append(f"\n  历史最高价 TOP20 物品:")
top_prices = df.groupby('item_base_name')['price_dollar'].max().sort_values(ascending=False).head(20)
for i, (name, price) in enumerate(top_prices.items(), 1):
    lines.append(f"    {i:2d}. {name[:50]}: ${price:.2f}")
lines.append("")

# ============================================================
# 三、成交量统计
# ============================================================
lines.append("=" * 80)
lines.append("三、成交量统计")
lines.append("=" * 80)

lines.append(f"  单日成交量最小值: {df['sells'].min():,}")
lines.append(f"  单日成交量最大值: {df['sells'].max():,}")
lines.append(f"  单日成交量平均值: {df['sells'].mean():.2f}")
lines.append(f"  单日成交量中位数: {df['sells'].median():.2f}")
lines.append(f"  单日成交量标准差: {df['sells'].std():.2f}")

# 成交量分位数
lines.append(f"\n  成交量分位数:")
for p in [1, 5, 10, 25, 50, 75, 90, 95, 99]:
    val = np.percentile(df['sells'], p)
    lines.append(f"    {p}%: {val:.0f}")

# 成交量区间分布
lines.append(f"\n  成交量区间分布:")
bins_vol = [0, 10, 50, 100, 500, 1000, 5000, 10000, 50000, 100000, 1000000]
labels_vol = ['0-10', '10-50', '50-100', '100-500', '500-1000', '1000-5000', '5000-10000', '10000-50000', '50000-100000', '100000+']
df['volume_bin'] = pd.cut(df['sells'], bins=bins_vol, labels=labels_vol)
vol_bin_counts = df['volume_bin'].value_counts()
for bin_label in labels_vol:
    if bin_label in vol_bin_counts.index:
        count = vol_bin_counts[bin_label]
        lines.append(f"    {bin_label}: {count:,} 条记录 ({count/len(df)*100:.2f}%)")
lines.append("")

# ============================================================
# 四、市场整体统计
# ============================================================
lines.append("=" * 80)
lines.append("四、市场整体统计")
lines.append("=" * 80)

daily_market = df.groupby('date').agg({
    'daily_value': 'sum',
    'sells': 'sum'
}).reset_index()

lines.append(f"  市场总成交额: ${df['daily_value'].sum():,.2f}")
lines.append(f"  市场总成交量: {df['sells'].sum():,}")
lines.append(f"  日均成交额: ${daily_market['daily_value'].mean():,.2f}")
lines.append(f"  日均成交额中位数: ${daily_market['daily_value'].median():,.2f}")
lines.append(f"  日均成交量: {daily_market['sells'].mean():,.0f}")
lines.append(f"  日均成交量中位数: {daily_market['sells'].median():,.0f}")

# 月度统计
daily_market['month'] = daily_market['date'].dt.to_period('M')
monthly_market = daily_market.groupby('month').agg({
    'daily_value': 'sum',
    'sells': 'sum'
}).reset_index()

lines.append(f"\n  月度统计:")
lines.append(f"    月均成交额: ${monthly_market['daily_value'].mean():,.2f}")
lines.append(f"    月均成交量: {monthly_market['sells'].mean():,.0f}")
lines.append(f"    成交额最高月份: {monthly_market.loc[monthly_market['daily_value'].idxmax(), 'month']} (${monthly_market['daily_value'].max():,.2f})")
lines.append(f"    成交量最高月份: {monthly_market.loc[monthly_market['sells'].idxmax(), 'month']} ({monthly_market['sells'].max():,.0f})")

# 年度统计
daily_market['year'] = daily_market['date'].dt.year
yearly_market = daily_market.groupby('year').agg({
    'daily_value': 'sum',
    'sells': 'sum'
}).reset_index()

lines.append(f"\n  年度统计:")
for _, row in yearly_market.iterrows():
    if pd.notna(row['year']):
        lines.append(f"    {int(row['year'])}年: 成交额 ${row['daily_value']:,.2f}, 成交量 {row['sells']:,}")
lines.append("")

# ============================================================
# 五、按物品类型统计
# ============================================================
lines.append("=" * 80)
lines.append("五、按物品类型统计")
lines.append("=" * 80)

type_stats = df.groupby('item_type').agg({
    'item_file_name': 'nunique',
    'price_dollar': ['mean', 'median', 'std', 'max'],
    'sells': 'sum'
}).round(2)
type_stats.columns = ['物品数', '均价($)', '中位数($)', '标准差($)', '最高价($)', '总销量']
type_stats = type_stats.sort_values('物品数', ascending=False)

lines.append(f"\n  {'类型':<15} {'物品数':>8} {'均价($)':>10} {'中位数($)':>10} {'最高价($)':>12} {'总销量':>15}")
lines.append(f"  {'-'*70}")
for item_type, row in type_stats.iterrows():
    lines.append(f"  {item_type:<15} {int(row['物品数']):>8} {row['均价($)']:>10.2f} {row['中位数($)']:>10.2f} {row['最高价($)']:>12.2f} {row['总销量']:>15,.0f}")
lines.append("")

# ============================================================
# 六、按稀有度统计（皮肤类）
# ============================================================
lines.append("=" * 80)
lines.append("六、按稀有度统计（皮肤类）")
lines.append("=" * 80)

rarity_order = ['Consumer Grade', 'Industrial Grade', 'Mil-Spec Grade',
                'Restricted', 'Classified', 'Covert', 'Extraordinary', 'Contraband']

rarity_stats = skins_df.groupby('rarity').agg({
    'item_file_name': 'nunique',
    'price_dollar': ['mean', 'median', 'min', 'max']
}).round(2)
rarity_stats.columns = ['物品数', '均价($)', '中位数($)', '最低价($)', '最高价($)']

lines.append(f"\n  {'稀有度':<20} {'物品数':>8} {'均价($)':>10} {'中位数($)':>10} {'最低价($)':>10} {'最高价($)':>12}")
lines.append(f"  {'-'*75}")
for r in rarity_order:
    if r in rarity_stats.index:
        row = rarity_stats.loc[r]
        lines.append(f"  {r:<20} {int(row['物品数']):>8} {row['均价($)']:>10.2f} {row['中位数($)']:>10.2f} {row['最低价($)']:>10.2f} {row['最高价($)']:>12.2f}")
lines.append("")

# ============================================================
# 七、按磨损档位统计（皮肤类）
# ============================================================
lines.append("=" * 80)
lines.append("七、按磨损档位统计（皮肤类）")
lines.append("=" * 80)

wear_order = ['Factory New', 'Minimal Wear', 'Field-Tested', 'Well-Worn', 'Battle-Scarred']

wear_stats = skins_with_wear.groupby('wear').agg({
    'item_file_name': 'nunique',
    'price_dollar': ['mean', 'median', 'min', 'max']
}).round(2)
wear_stats.columns = ['物品数', '均价($)', '中位数($)', '最低价($)', '最高价($)']

lines.append(f"\n  {'磨损档位':<15} {'物品数':>8} {'均价($)':>10} {'中位数($)':>10} {'最低价($)':>10} {'最高价($)':>12}")
lines.append(f"  {'-'*70}")
for w in wear_order:
    if w in wear_stats.index:
        row = wear_stats.loc[w]
        lines.append(f"  {w:<15} {int(row['物品数']):>8} {row['均价($)']:>10.2f} {row['中位数($)']:>10.2f} {row['最低价($)']:>10.2f} {row['最高价($)']:>12.2f}")
lines.append("")

# ============================================================
# 八、按武器类型统计（皮肤类，TOP15）
# ============================================================
lines.append("=" * 80)
lines.append("八、按武器类型统计（皮肤类，TOP15）")
lines.append("=" * 80)

weapon_stats = skins_df.groupby('weapon').agg({
    'item_file_name': 'nunique',
    'price_dollar': 'mean'
}).round(2)
weapon_stats.columns = ['皮肤数', '均价($)']
weapon_stats = weapon_stats.sort_values('皮肤数', ascending=False).head(15)

lines.append(f"\n  {'武器类型':<20} {'皮肤数':>8} {'均价($)':>10}")
lines.append(f"  {'-'*40}")
for weapon, row in weapon_stats.iterrows():
    lines.append(f"  {weapon:<20} {int(row['皮肤数']):>8} {row['均价($)']:>10.2f}")

# 均价最高的武器 TOP10
lines.append(f"\n  均价最高的武器 TOP10:")
weapon_price_high = skins_df.groupby('weapon')['price_dollar'].mean().sort_values(ascending=False).head(10)
for i, (weapon, price) in enumerate(weapon_price_high.items(), 1):
    lines.append(f"    {i:2d}. {weapon:<20} ${price:.2f}")
lines.append("")

# ============================================================
# 九、相关性分析
# ============================================================
lines.append("=" * 80)
lines.append("九、相关性分析")
lines.append("=" * 80)

# 日级别数据
daily_corr = df.groupby('date').agg({
    'price_dollar': 'mean',
    'daily_value': 'sum',
    'sells': 'sum'
}).reset_index()
daily_corr['price_change'] = daily_corr['price_dollar'].pct_change()
daily_corr['volume_change'] = daily_corr['sells'].pct_change()
daily_corr = daily_corr.dropna()

# 计算相关系数
corr_price_volume, p1 = pearsonr(daily_corr['price_dollar'], daily_corr['sells'])
corr_price_value, p2 = pearsonr(daily_corr['price_dollar'], daily_corr['daily_value'])
corr_price_change_volume_change, p3 = pearsonr(daily_corr['price_change'], daily_corr['volume_change'])

lines.append(f"\n  价格 vs 成交量:")
lines.append(f"    皮尔逊相关系数: {corr_price_volume:.4f}")
lines.append(f"    p值: {p1:.4e}")
lines.append(f"    解释: {'正相关' if corr_price_volume > 0 else '负相关'}{'，显著' if p1 < 0.05 else '，不显著'}")

lines.append(f"\n  价格 vs 成交额:")
lines.append(f"    皮尔逊相关系数: {corr_price_value:.4f}")
lines.append(f"    p值: {p2:.4e}")
lines.append(f"    解释: {'正相关' if corr_price_value > 0 else '负相关'}{'，显著' if p2 < 0.05 else '，不显著'}")

lines.append(f"\n  价格变化率 vs 成交量变化率:")
lines.append(f"    皮尔逊相关系数: {corr_price_change_volume_change:.4f}")
lines.append(f"    p值: {p3:.4e}")
lines.append(f"    解释: {'正相关' if corr_price_change_volume_change > 0 else '负相关'}{'，显著' if p3 < 0.05 else '，不显著'}")
lines.append("")

# ============================================================
# 十、四象限分析
# ============================================================
lines.append("=" * 80)
lines.append("十、四象限分析（价格-成交量矩阵）")
lines.append("=" * 80)

median_price = df['price_dollar'].median()
median_volume = df['sells'].median()

quadrant_def = {
    'Q1_高价高量': (df['price_dollar'] > median_price) & (df['sells'] > median_volume),
    'Q2_低价高量': (df['price_dollar'] <= median_price) & (df['sells'] > median_volume),
    'Q3_低价低量': (df['price_dollar'] <= median_price) & (df['sells'] <= median_volume),
    'Q4_高价低量': (df['price_dollar'] > median_price) & (df['sells'] <= median_volume)
}

lines.append(f"\n  分界线: 价格中位数 = ${median_price:.4f}, 成交量中位数 = {median_volume:.0f}")
lines.append(f"\n  {'象限':<12} {'记录数':>12} {'占比':>10} {'价格均值($)':>12} {'成交量均值':>12}")
lines.append(f"  {'-'*60}")

for q_name, mask in quadrant_def.items():
    count = mask.sum()
    pct = count / len(df) * 100
    price_mean = df[mask]['price_dollar'].mean()
    volume_mean = df[mask]['sells'].mean()
    lines.append(f"  {q_name:<12} {count:>12,} {pct:>9.2f}% {price_mean:>12.4f} {volume_mean:>12.0f}")

# 各象限典型物品
lines.append(f"\n  各象限典型物品（高价高量）:")
top_q1 = df[quadrant_def['Q1_高价高量']].groupby('item_base_name').size().sort_values(ascending=False).head(10)
for i, (name, cnt) in enumerate(top_q1.items(), 1):
    lines.append(f"    {i:2d}. {name[:50]}")

lines.append(f"\n  各象限典型物品（低价高量）:")
top_q2 = df[quadrant_def['Q2_低价高量']].groupby('item_base_name').size().sort_values(ascending=False).head(10)
for i, (name, cnt) in enumerate(top_q2.items(), 1):
    lines.append(f"    {i:2d}. {name[:50]}")
lines.append("")

# ============================================================
# 十一、时间序列统计
# ============================================================
lines.append("=" * 80)
lines.append("十一、时间序列统计")
lines.append("=" * 80)

# 按年份统计
yearly_stats = df.groupby('year').agg({
    'price_dollar': ['mean', 'median'],
    'daily_value': 'sum'
}).round(2)
yearly_stats.columns = ['均价($)', '中位数($)', '年成交额($)']

lines.append(f"\n  {'年份':<6} {'均价($)':>10} {'中位数($)':>10} {'年成交额($)':>20}")
lines.append(f"  {'-'*50}")
for year, row in yearly_stats.iterrows():
    if pd.notna(year) and year > 0:
        lines.append(f"  {int(year):<6} {row['均价($)']:>10.2f} {row['中位数($)']:>10.2f} {row['年成交额($)']:>20,.2f}")

# 月度季节性
monthly_avg = df.groupby('month')['price_dollar'].mean()
lines.append(f"\n  月度季节性（月均价）:")
month_names = ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
for m in range(1, 13):
    if m in monthly_avg.index:
        lines.append(f"    {month_names[m-1]}: ${monthly_avg[m]:.4f}")

# 周度季节性
weekly_avg = df.groupby('dayofweek')['price_dollar'].mean()
week_names = ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
lines.append(f"\n  周度季节性（日均价）:")
for d in range(7):
    if d in weekly_avg.index:
        lines.append(f"    {week_names[d]}: ${weekly_avg[d]:.4f}")
lines.append("")

# ============================================================
# 十二、数据质量报告
# ============================================================
lines.append("=" * 80)
lines.append("十二、数据质量报告")
lines.append("=" * 80)

# 缺失值统计
lines.append(f"\n  缺失值统计:")
lines.append(f"    date: {df['date'].isna().sum():,} ({df['date'].isna().sum()/len(df)*100:.4f}%)")
lines.append(f"    price_dollar: {df['price_dollar'].isna().sum():,} ({df['price_dollar'].isna().sum()/len(df)*100:.4f}%)")
lines.append(f"    sells: {df['sells'].isna().sum():,} ({df['sells'].isna().sum()/len(df)*100:.4f}%)")
lines.append(f"    item_type: {df['item_type'].isna().sum():,} ({df['item_type'].isna().sum()/len(df)*100:.4f}%)")
lines.append(f"    rarity: {df['rarity'].isna().sum():,} ({df['rarity'].isna().sum()/len(df)*100:.4f}%)")

# 异常值检测（3倍标准差）
price_mean = df['price_dollar'].mean()
price_std = df['price_dollar'].std()
price_outliers = df[(df['price_dollar'] > price_mean + 3*price_std) | (df['price_dollar'] < price_mean - 3*price_std)]
lines.append(f"\n  异常值检测（3倍标准差）:")
lines.append(f"    价格异常值数量: {len(price_outliers):,} ({len(price_outliers)/len(df)*100:.4f}%)")

volume_mean = df['sells'].mean()
volume_std = df['sells'].std()
volume_outliers = df[(df['sells'] > volume_mean + 3*volume_std) | (df['sells'] < volume_mean - 3*volume_std)]
lines.append(f"    成交量异常值数量: {len(volume_outliers):,} ({len(volume_outliers)/len(df)*100:.4f}%)")

lines.append("")

# ============================================================
# 十三、总结
# ============================================================
lines.append("=" * 80)
lines.append("十三、总结与关键发现")
lines.append("=" * 80)

# 计算一些关键发现
top_1_percent_price = np.percentile(df['price_dollar'], 99)
top_1_percent_volume = np.percentile(df['sells'], 99)
high_value_items = df[df['price_dollar'] > 1000]['item_file_name'].nunique()

lines.append(f"\n  核心发现:")
lines.append(f"    1. 数据集规模: {len(df):,} 条记录，覆盖 {df['item_file_name'].nunique():,} 个物品")
lines.append(f"    2. 时间跨度: {(df['date'].max() - df['date'].min()).days} 天（约 {(df['date'].max() - df['date'].min()).days/365:.1f} 年）")
lines.append(f"    3. 市场价格分布呈高度右偏（偏度: {skew(df['price_dollar']):.2f}），多数物品价格较低")
lines.append(f"    4. 前1%的高价物品价格 > ${top_1_percent_price:.2f}，前1%的高成交量物品成交量 > {top_1_percent_volume:.0f}")
lines.append(f"    5. 高价物品（> $1000）共有 {high_value_items} 个，占总物品数的 {high_value_items/df['item_file_name'].nunique()*100:.2f}%")
lines.append(f"    6. 价格与成交量相关性: {corr_price_volume:.4f}（{'正相关' if corr_price_volume > 0 else '负相关'}）")
lines.append(f"    7. 市场总成交额: ${df['daily_value'].sum():,.2f}，总成交量: {df['sells'].sum():,}")
lines.append(f"    8. 稀有度越高，平均价格越高（从 Consumer Grade 到 Covert 递增）")
lines.append(f"    9. 磨损档位越低（Factory New），平均价格越高")
lines.append(f"    10. 成交量主要集中在低价位区间（$0-20 占总记录的 {df[df['price_dollar']<=20].shape[0]/len(df)*100:.1f}%）")

lines.append("")
lines.append("=" * 80)
lines.append("报告生成完毕")
lines.append("=" * 80)

# ============================================================
# 输出到文件和控制台
# ============================================================
report_text = "\n".join(lines)
print(report_text)

with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
    f.write(report_text)

print(f"\n报告已保存至: {OUTPUT_FILE}")