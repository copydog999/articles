"""
CS2 数据集合并脚本（完整版）
从 GitHub 加载所有物品类型，与 Kaggle 价格数据关联
"""

import os
import json
import base64
import re
import pandas as pd
from pathlib import Path
from tqdm import tqdm

SCRIPT_DIR = Path(__file__).parent.absolute()
GITHUB_DIR = SCRIPT_DIR / "CSGO-API" / "public" / "api" / "en"
KAGGLE_INDEX = SCRIPT_DIR / "dataset_publish" / "item_index.csv"
KAGGLE_ITEMS_DIR = SCRIPT_DIR / "dataset_publish" / "items"
OUTPUT_DIR = SCRIPT_DIR / "merged_dataset"

OUTPUT_DIR.mkdir(exist_ok=True)


def decode_base64_name(encoded):
    try:
        decoded = base64.b64decode(encoded).decode('utf-8')
        return decoded
    except:
        return encoded


def extract_base_name(full_name):
    """从完整名称中提取基础名称"""
    # 去掉磨损档位 (Battle-Scarred), (Factory New) 等
    name = re.sub(r'\s*\([^)]+\)$', '', full_name)
    # 去掉 ★ 符号
    name = name.replace('★', '').strip()
    return name.strip()


def load_all_github_items():
    """加载 GitHub 所有物品类型，建立名称 -> 属性的映射"""

    name_to_attrs = {}

    # 定义要加载的文件及其类型标识
    files_to_load = [
        ('skins.json', 'skin'),
        ('stickers.json', 'sticker'),
        ('agents.json', 'agent'),
        ('crates.json', 'crate'),
        ('music_kits.json', 'music_kit'),
        ('graffiti.json', 'graffiti'),
        ('keys.json', 'key'),
        ('patches.json', 'patch'),
        ('keychains.json', 'keychain'),
        ('collectibles.json', 'collectible'),
        ('tools.json', 'tool'),
    ]

    for filename, item_type in files_to_load:
        filepath = GITHUB_DIR / filename
        if not filepath.exists():
            print(f"   ⚠️ 未找到: {filename}")
            continue

        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)

        print(f"   ✓ {filename}: {len(data)} 个物品")

        for item in data:
            item_name = item.get('name', '')
            if not item_name:
                continue

            # 提取属性
            attrs = {
                'item_id': item.get('id'),
                'item_type': item_type,
                'item_name': item_name,
                'rarity': item.get('rarity', {}).get('name', '') if isinstance(item.get('rarity'), dict) else str(
                    item.get('rarity', '')),
                'weapon': '',
                'collection': '',
            }

            # 皮肤特有字段
            if item_type == 'skin':
                weapon = item.get('weapon', {})
                if isinstance(weapon, dict):
                    attrs['weapon'] = weapon.get('name', '')
                else:
                    attrs['weapon'] = str(weapon)

                # 磨损范围
                attrs['min_float'] = item.get('min_float')
                attrs['max_float'] = item.get('max_float')
            else:
                attrs['min_float'] = None
                attrs['max_float'] = None

            name_to_attrs[item_name] = attrs

    print(f"\n📊 总计加载: {len(name_to_attrs)} 个物品")
    return name_to_attrs


def parse_kaggle_name(full_name):
    """解析 Kaggle 名称"""
    # 判断是否 StatTrak
    is_stattrak = 'StatTrak™' in full_name

    # 判断是否纪念品
    is_souvenir = 'Souvenir' in full_name

    # 判断是否刀具/手套
    is_knife_or_glove = '★' in full_name

    # 提取磨损档位
    wear_match = re.search(r'\(([^)]+)\)$', full_name)
    wear = wear_match.group(1) if wear_match else None

    # 提取基础名称
    base_name = extract_base_name(full_name)

    return {
        'full_name': full_name,
        'base_name': base_name,
        'wear': wear,
        'is_stattrak': is_stattrak,
        'is_souvenir': is_souvenir,
        'is_knife_or_glove': is_knife_or_glove
    }


def merge_single_item(row, name_to_attrs):
    """处理单个物品的价格数据"""
    file_name = row['file_name']
    encoded_name = row['item_hash_name_base64']
    full_name = decode_base64_name(encoded_name)

    parsed = parse_kaggle_name(full_name)
    base_name = parsed['base_name']

    # 查找匹配的静态属性
    attrs = name_to_attrs.get(base_name, {})

    # 读取价格文件
    price_path = KAGGLE_ITEMS_DIR / file_name
    if not price_path.exists():
        return None

    df_price = pd.read_csv(price_path)

    # 转换时间戳
    df_price['date'] = pd.to_datetime(df_price['timestamp'], unit='ms').dt.date

    # 添加字段
    df_price['item_file_name'] = file_name
    df_price['item_full_name'] = full_name
    df_price['item_base_name'] = base_name
    df_price['wear'] = parsed['wear']
    df_price['is_stattrak'] = parsed['is_stattrak']
    df_price['is_souvenir'] = parsed['is_souvenir']
    df_price['is_knife_or_glove'] = parsed['is_knife_or_glove']

    # 添加静态属性
    df_price['item_type'] = attrs.get('item_type')
    df_price['item_id'] = attrs.get('item_id')
    df_price['rarity'] = attrs.get('rarity')
    df_price['weapon'] = attrs.get('weapon')
    df_price['min_float'] = attrs.get('min_float')
    df_price['max_float'] = attrs.get('max_float')
    df_price['has_static_attrs'] = len(attrs) > 0

    return df_price


def main():
    print("=" * 70)
    print("CS2 数据集合并脚本（完整版）")
    print("=" * 70)

    # 1. 加载所有 GitHub 物品
    print("\n1. 加载 GitHub 所有物品类型...")
    name_to_attrs = load_all_github_items()

    # 2. 读取 Kaggle 索引
    print("\n2. 读取 Kaggle 索引...")
    df_index = pd.read_csv(KAGGLE_INDEX)
    print(f"   共 {len(df_index)} 个物品")

    # 3. 合并数据
    print("\n3. 开始合并数据...")

    all_data = []
    matched_count = 0
    unmatched_count = 0
    type_stats = {}

    for idx, row in tqdm(df_index.iterrows(), total=len(df_index), desc="处理进度"):
        df_item = merge_single_item(row, name_to_attrs)
        if df_item is not None and len(df_item) > 0:
            all_data.append(df_item)

            # 统计匹配情况
            if df_item['has_static_attrs'].iloc[0]:
                matched_count += 1
                item_type = df_item['item_type'].iloc[0]
                type_stats[item_type] = type_stats.get(item_type, 0) + 1
            else:
                unmatched_count += 1

    # 4. 合并所有数据
    if all_data:
        df_merged = pd.concat(all_data, ignore_index=True)

        # 保存为 Parquet
        output_path = OUTPUT_DIR / "merged_price_data.parquet"
        df_merged.to_parquet(output_path, index=False)

        # 同时保存一份 CSV 示例（前10000行）
        sample_path = OUTPUT_DIR / "merged_sample.csv"
        df_merged.head(10000).to_csv(sample_path, index=False)

        print(f"\n4. 合并完成!")
        print(f"   输出文件: {output_path}")
        print(f"   总记录数: {len(df_merged):,}")
        print(f"   物品总数: {df_merged['item_file_name'].nunique()}")
        print(f"   日期范围: {df_merged['date'].min()} ~ {df_merged['date'].max()}")

        print(f"\n📊 匹配统计:")
        print(f"   匹配上的物品: {matched_count}")
        print(f"   未匹配的物品: {unmatched_count}")
        print(f"   匹配率: {matched_count / (matched_count + unmatched_count) * 100:.1f}%")

        if type_stats:
            print(f"\n📊 匹配上的物品类型分布:")
            for t, count in sorted(type_stats.items(), key=lambda x: -x[1]):
                print(f"   - {t}: {count}")

        # 显示示例
        print(f"\n📋 合并后数据示例:")
        cols_to_show = ['date', 'price_dollar', 'sells', 'item_base_name', 'item_type', 'wear', 'is_stattrak', 'weapon',
                        'rarity']
        available_cols = [c for c in cols_to_show if c in df_merged.columns]
        print(df_merged[available_cols].head(15).to_string())

    print("\n" + "=" * 70)
    print("合并完成!")
    print("=" * 70)


if __name__ == "__main__":
    main()