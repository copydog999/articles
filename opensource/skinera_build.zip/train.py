"""
CS2 市场整体成交额预测 - 训练脚本
预测目标：次日市场总成交额（美元）
"""

import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import joblib
import warnings
warnings.filterwarnings('ignore')

# 设置随机种子
np.random.seed(42)

SCRIPT_DIR = Path(__file__).parent.absolute()
DATA_PATH = SCRIPT_DIR / "merged_dataset" / "merged_price_data.parquet"
MODEL_DIR = SCRIPT_DIR / "models"
MODEL_DIR.mkdir(exist_ok=True)

print("=" * 80)
print("CS2 市场整体成交额预测 - 训练")
print("=" * 80)

# ============================================================
# 1. 加载并聚合数据
# ============================================================
print("\n1. 加载并聚合数据...")

df = pd.read_parquet(DATA_PATH)
print(f"   原始数据: {len(df):,} 条记录")

# 计算每日市场总成交额（价格 * 销量）
df['daily_value'] = df['price_dollar'] * df['sells']

daily_df = df.groupby('date').agg({
    'daily_value': 'sum',  # 成交额 = 价格 * 销量
    'sells': 'sum',        # 总成交量
    'price_dollar': 'mean' # 平均价格
}).reset_index()

# 按日期排序
daily_df = daily_df.sort_values('date').reset_index(drop=True)
daily_df['date'] = pd.to_datetime(daily_df['date'])

print(f"   聚合后: {len(daily_df)} 天数据")
print(f"   日期范围: {daily_df['date'].min().date()} ~ {daily_df['date'].max().date()}")
print(f"   日均成交额: ${daily_df['daily_value'].mean():,.2f}")
print(f"   日均成交量: {daily_df['sells'].mean():,.0f}")

# ============================================================
# 2. 特征工程
# ============================================================
print("\n2. 特征工程...")

# 时间特征
daily_df['dayofweek'] = daily_df['date'].dt.dayofweek
daily_df['month'] = daily_df['date'].dt.month
daily_df['year'] = daily_df['date'].dt.year
daily_df['dayofyear'] = daily_df['date'].dt.dayofyear
daily_df['quarter'] = daily_df['date'].dt.quarter
daily_df['days_since_start'] = (daily_df['date'] - daily_df['date'].min()).dt.days

# 滞后特征（过去 N 天的成交额）
for lag in [1, 2, 3, 7, 14, 21, 30]:
    daily_df[f'value_lag_{lag}'] = daily_df['daily_value'].shift(lag)
    daily_df[f'volume_lag_{lag}'] = daily_df['sells'].shift(lag)
    daily_df[f'price_lag_{lag}'] = daily_df['price_dollar'].shift(lag)

# 滚动统计特征
for window in [3, 5, 7, 14, 30]:
    daily_df[f'value_ma_{window}'] = daily_df['daily_value'].rolling(window).mean()
    daily_df[f'value_std_{window}'] = daily_df['daily_value'].rolling(window).std()
    daily_df[f'volume_ma_{window}'] = daily_df['sells'].rolling(window).mean()
    daily_df[f'price_ma_{window}'] = daily_df['price_dollar'].rolling(window).mean()

# 删除缺失值
daily_df = daily_df.dropna().reset_index(drop=True)

print(f"   特征工程后: {len(daily_df)} 天数据")
print(f"   特征数量: {len([c for c in daily_df.columns if c not in ['date']])}")

# ============================================================
# 3. 定义特征和目标
# ============================================================
print("\n3. 准备训练数据...")

# 预测目标：次日成交额
target_col = 'daily_value'
feature_cols = [c for c in daily_df.columns if c not in ['date', target_col]]

X = daily_df[feature_cols].values
y = daily_df[target_col].values

# 数据划分（按时间顺序）
train_size = int(len(X) * 0.7)
val_size = int(len(X) * 0.15)

X_train_raw = X[:train_size]
y_train_raw = y[:train_size]
X_val_raw = X[train_size:train_size+val_size]
y_val_raw = y[train_size:train_size+val_size]
X_test_raw = X[train_size+val_size:]
y_test_raw = y[train_size+val_size:]

print(f"   训练集: {len(X_train_raw)} 天")
print(f"   验证集: {len(X_val_raw)} 天")
print(f"   测试集: {len(X_test_raw)} 天")

# 归一化（用于神经网络）
scaler_X = MinMaxScaler()
scaler_y = MinMaxScaler()

X_train_scaled = scaler_X.fit_transform(X_train_raw)
X_val_scaled = scaler_X.transform(X_val_raw)
X_test_scaled = scaler_X.transform(X_test_raw)

y_train_scaled = scaler_y.fit_transform(y_train_raw.reshape(-1, 1)).flatten()
y_val_scaled = scaler_y.transform(y_val_raw.reshape(-1, 1)).flatten()
y_test_scaled = scaler_y.transform(y_test_raw.reshape(-1, 1)).flatten()

# ============================================================
# 4. 训练模型
# ============================================================
print("\n4. 训练模型...")

models = {}

# XGBoost
print("\n   🚀 训练 XGBoost...")
try:
    import xgboost as xgb
    xgb_model = xgb.XGBRegressor(
        n_estimators=200,
        max_depth=6,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        random_state=42,
        verbosity=0
    )
    xgb_model.fit(X_train_raw, y_train_raw, eval_set=[(X_val_raw, y_val_raw)], verbose=False)
    models['XGBoost'] = xgb_model
    print("      ✓ 完成")
except Exception as e:
    print(f"      ✗ 失败: {e}")

# LightGBM
print("\n   🚀 训练 LightGBM...")
try:
    import lightgbm as lgb
    lgb_model = lgb.LGBMRegressor(
        n_estimators=200,
        max_depth=6,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        random_state=42,
        verbose=-1
    )
    lgb_model.fit(X_train_raw, y_train_raw, eval_set=[(X_val_raw, y_val_raw)], eval_metric='l2')
    models['LightGBM'] = lgb_model
    print("      ✓ 完成")
except Exception as e:
    print(f"      ✗ 失败: {e}")

# Random Forest
print("\n   🚀 训练 Random Forest...")
from sklearn.ensemble import RandomForestRegressor
rf_model = RandomForestRegressor(
    n_estimators=150,
    max_depth=12,
    min_samples_split=5,
    min_samples_leaf=2,
    random_state=42,
    n_jobs=-1
)
rf_model.fit(X_train_raw, y_train_raw)
models['RandomForest'] = rf_model
print("      ✓ 完成")

# MLP
print("\n   🚀 训练 MLP...")
from sklearn.neural_network import MLPRegressor
mlp_model = MLPRegressor(
    hidden_layer_sizes=(128, 64, 32),
    activation='relu',
    solver='adam',
    max_iter=500,
    early_stopping=True,
    validation_fraction=0.1,
    random_state=42,
    verbose=False
)
mlp_model.fit(X_train_scaled, y_train_scaled)
models['MLP'] = mlp_model
print("      ✓ 完成")

# LSTM
print("\n   🚀 训练 LSTM...")
try:
    from tensorflow.keras.models import Sequential
    from tensorflow.keras.layers import LSTM, Dense, Dropout
    from tensorflow.keras.callbacks import EarlyStopping

    SEQ_LEN = 30

    def create_sequences(data, target, seq_len):
        X_seq, y_seq = [], []
        for i in range(len(data) - seq_len):
            X_seq.append(data[i:i+seq_len])
            y_seq.append(target[i+seq_len])
        return np.array(X_seq), np.array(y_seq)

    X_lstm, y_lstm = create_sequences(X_train_scaled, y_train_scaled, SEQ_LEN)
    X_val_lstm, y_val_lstm = create_sequences(X_val_scaled, y_val_scaled, SEQ_LEN)

    lstm_model = Sequential([
        LSTM(64, return_sequences=True, input_shape=(SEQ_LEN, X_train_scaled.shape[1])),
        Dropout(0.2),
        LSTM(32, return_sequences=False),
        Dropout(0.2),
        Dense(16, activation='relu'),
        Dense(1)
    ])
    lstm_model.compile(optimizer='adam', loss='mse', metrics=['mae'])

    early_stop = EarlyStopping(monitor='val_loss', patience=20, restore_best_weights=True)

    lstm_model.fit(
        X_lstm, y_lstm,
        epochs=100,
        batch_size=32,
        validation_data=(X_val_lstm, y_val_lstm),
        callbacks=[early_stop],
        verbose=0
    )
    models['LSTM'] = lstm_model
    print("      ✓ 完成")
except Exception as e:
    print(f"      ✗ 失败: {e}")

# ============================================================
# 5. 评估与保存
# ============================================================
print("\n5. 评估与保存...")

# 保存预处理对象
joblib.dump(scaler_X, MODEL_DIR / 'market_scaler_X.pkl')
joblib.dump(scaler_y, MODEL_DIR / 'market_scaler_y.pkl')
joblib.dump(feature_cols, MODEL_DIR / 'market_feature_cols.pkl')

# 保存测试数据
SEQ_LEN = 30
test_data = {
    'X_test_raw': X_test_raw,
    'y_test_raw': y_test_raw,
    'X_test_scaled': X_test_scaled,
    'y_test_scaled': y_test_scaled,
    'dates': daily_df['date'].iloc[train_size+val_size:].values,
    'seq_len': SEQ_LEN
}
joblib.dump(test_data, MODEL_DIR / 'market_test_data.pkl')

# 保存模型
for name, model in models.items():
    if name == 'LSTM':
        model.save(MODEL_DIR / f'market_{name}_model.keras')
    else:
        joblib.dump(model, MODEL_DIR / f'market_{name}_model.pkl')
    print(f"   ✓ 已保存: market_{name}_model")

# 快速评估
print("\n📊 快速评估（验证集）:")
for name, model in models.items():
    if name == 'LSTM':
        X_val_lstm, y_val_lstm = create_sequences(X_val_scaled, y_val_scaled, SEQ_LEN)
        y_pred_scaled = model.predict(X_val_lstm, verbose=0).flatten()
        y_pred = scaler_y.inverse_transform(y_pred_scaled.reshape(-1, 1)).flatten()
        y_true = scaler_y.inverse_transform(y_val_lstm.reshape(-1, 1)).flatten()
    else:
        y_pred = model.predict(X_val_raw)
        y_true = y_val_raw
    mae = mean_absolute_error(y_true, y_pred)
    print(f"   {name:12s}: MAE = ${mae:,.2f}")

print("\n" + "=" * 80)
print("✅ 训练完成！")
print("=" * 80)