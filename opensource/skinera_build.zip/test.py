"""
CS2 市场整体成交额预测 - 测试与可视化
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from pathlib import Path
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import joblib
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# 字体配置
# ============================================================
FONT_PATH = 'C:/Windows/Fonts/msyh.ttc'
CHINESE_FONT = FontProperties(fname=FONT_PATH, size=12)
TITLE_FONT = FontProperties(fname=FONT_PATH, size=14, weight='bold')

plt.rcParams['figure.dpi'] = 120
plt.rcParams['axes.grid'] = True
plt.rcParams['grid.alpha'] = 0.3

# ============================================================
# 路径配置
# ============================================================
SCRIPT_DIR = Path(__file__).parent.absolute()
MODEL_DIR = SCRIPT_DIR / "models"
OUTPUT_DIR = SCRIPT_DIR / "merged_dataset" / "figures"
OUTPUT_DIR.mkdir(exist_ok=True)

print("=" * 80)
print("CS2 市场整体成交额预测 - 测试")
print("=" * 80)

# ============================================================
# 加载数据
# ============================================================
print("\n1. 加载模型和数据...")

scaler_X = joblib.load(MODEL_DIR / 'market_scaler_X.pkl')
scaler_y = joblib.load(MODEL_DIR / 'market_scaler_y.pkl')
feature_cols = joblib.load(MODEL_DIR / 'market_feature_cols.pkl')
test_data = joblib.load(MODEL_DIR / 'market_test_data.pkl')

X_test_raw = test_data['X_test_raw']
y_test = test_data['y_test_raw']
X_test_scaled = test_data['X_test_scaled']
dates = test_data['dates']

print(f"   测试集样本数: {len(y_test)}")
print(f"   日期范围: {dates[0]} ~ {dates[-1]}")

# ============================================================
# 加载模型
# ============================================================
print("\n2. 加载模型...")

models = {}
model_files = {
    'XGBoost': MODEL_DIR / 'market_XGBoost_model.pkl',
    'LightGBM': MODEL_DIR / 'market_LightGBM_model.pkl',
    'RandomForest': MODEL_DIR / 'market_RandomForest_model.pkl',
    'MLP': MODEL_DIR / 'market_MLP_model.pkl',
}

for name, path in model_files.items():
    if path.exists():
        models[name] = joblib.load(path)
        print(f"   ✓ {name}")

lstm_path = MODEL_DIR / 'market_LSTM_model.keras'
if lstm_path.exists():
    from tensorflow.keras.models import load_model
    models['LSTM'] = load_model(lstm_path)
    print(f"   ✓ LSTM")

print(f"\n   共加载 {len(models)} 个模型")

# ============================================================
# 预测
# ============================================================
print("\n3. 生成预测...")

predictions = {}
SEQ_LEN = 30

for name, model in models.items():
    if name == 'LSTM':
        X_lstm = []
        for i in range(len(X_test_scaled) - SEQ_LEN):
            X_lstm.append(X_test_scaled[i:i+SEQ_LEN])
        X_lstm = np.array(X_lstm)
        y_pred_scaled = model.predict(X_lstm, verbose=0).flatten()
        y_pred = scaler_y.inverse_transform(y_pred_scaled.reshape(-1, 1)).flatten()
        predictions[name] = y_pred
    else:
        y_pred = model.predict(X_test_raw)
        predictions[name] = y_pred

# ============================================================
# 计算指标
# ============================================================
print("\n4. 计算评估指标...")

results = []
for name, y_pred in predictions.items():
    if name == 'LSTM':
        y_true = y_test[SEQ_LEN:]
    else:
        y_true = y_test

    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    r2 = r2_score(y_true, y_pred)
    mape = np.mean(np.abs((y_true - y_pred) / y_true)) * 100

    results.append({
        'Model': name,
        'MAE': mae,
        'RMSE': rmse,
        'R2': r2,
        'MAPE': mape
    })
    print(f"   {name:12s} | MAE: ${mae:,.2f} | RMSE: ${rmse:,.2f} | R²: {r2:.4f} | MAPE: {mape:.2f}%")

# ============================================================
# 图表
# ============================================================
print("\n5. 生成图表...")

# 图1：指标对比
fig, ax = plt.subplots(figsize=(12, 6))
x = np.arange(len(results))
width = 0.25

mae_vals = [r['MAE'] / 1000 for r in results]
rmse_vals = [r['RMSE'] / 1000 for r in results]
r2_vals = [r['R2'] for r in results]

bars1 = ax.bar(x - width, mae_vals, width, label='MAE (千美元)', color='steelblue')
bars2 = ax.bar(x, rmse_vals, width, label='RMSE (千美元)', color='coral')
bars3 = ax.bar(x + width, r2_vals, width, label='R²', color='green')

ax.set_xlabel('模型', fontproperties=CHINESE_FONT)
ax.set_ylabel('指标值', fontproperties=CHINESE_FONT)
ax.set_title('市场成交额预测 - 各模型性能对比', fontproperties=TITLE_FONT)
ax.set_xticks(x)
ax.set_xticklabels([r['Model'] for r in results], fontproperties=CHINESE_FONT)
ax.legend(prop=CHINESE_FONT)

plt.tight_layout()
plt.savefig(OUTPUT_DIR / '21_market_metrics.png', dpi=150, bbox_inches='tight')
plt.close()
print("   ✓ 图1: 21_market_metrics.png")

# 图2：所有模型预测叠加
fig, ax = plt.subplots(figsize=(16, 6))
ax.plot(dates, y_test, label='真实成交额', linewidth=2, color='black')

colors = {'XGBoost': 'blue', 'LightGBM': 'green', 'RandomForest': 'orange', 'MLP': 'purple', 'LSTM': 'red'}
for name, y_pred in predictions.items():
    if name == 'LSTM':
        plot_dates = dates[SEQ_LEN:]
        plot_pred = y_pred
    else:
        plot_dates = dates
        plot_pred = y_pred
    ax.plot(plot_dates, plot_pred, label=f'{name} 预测', linewidth=1.5,
            color=colors.get(name, 'gray'), alpha=0.7, linestyle='--')

ax.set_xlabel('日期', fontproperties=CHINESE_FONT)
ax.set_ylabel('成交额 (美元)', fontproperties=CHINESE_FONT)
ax.set_title('市场成交额预测 - 各模型效果对比', fontproperties=TITLE_FONT)
ax.legend(prop=CHINESE_FONT, loc='upper left')

plt.tight_layout()
plt.savefig(OUTPUT_DIR / '22_market_overlay.png', dpi=150, bbox_inches='tight')
plt.close()
print("   ✓ 图2: 22_market_overlay.png")

# 图3：每个模型单独子图
n_models = len(predictions)
fig, axes = plt.subplots(n_models, 1, figsize=(14, 4 * n_models))
if n_models == 1:
    axes = [axes]

for idx, (name, y_pred) in enumerate(predictions.items()):
    ax = axes[idx]
    if name == 'LSTM':
        plot_dates = dates[SEQ_LEN:]
        plot_true = y_test[SEQ_LEN:]
        plot_pred = y_pred
    else:
        plot_dates = dates
        plot_true = y_test
        plot_pred = y_pred

    mae = mean_absolute_error(plot_true, plot_pred)
    r2 = r2_score(plot_true, plot_pred)

    ax.plot(plot_dates, plot_true, label='真实成交额', linewidth=1.5, color='steelblue')
    ax.plot(plot_dates, plot_pred, label='预测成交额', linewidth=1.5, color='coral', linestyle='--')
    ax.fill_between(plot_dates, plot_true, plot_pred, alpha=0.2, color='gray')
    ax.set_ylabel('成交额 (美元)', fontproperties=CHINESE_FONT)
    ax.set_title(f'{name} - MAE: ${mae:,.2f}, R²: {r2:.4f}', fontproperties=CHINESE_FONT)
    ax.legend(prop=CHINESE_FONT)
    ax.grid(True, alpha=0.3)

axes[-1].set_xlabel('日期', fontproperties=CHINESE_FONT)
plt.tight_layout()
plt.savefig(OUTPUT_DIR / '23_market_individual.png', dpi=150, bbox_inches='tight')
plt.close()
print("   ✓ 图3: 23_market_individual.png")

# 图4：散点图
n_models = len(predictions)
cols = min(3, n_models)
rows = (n_models + cols - 1) // cols
fig, axes = plt.subplots(rows, cols, figsize=(5 * cols, 5 * rows))
if n_models == 1:
    axes = [axes]
else:
    axes = axes.flatten()

for idx, (name, y_pred) in enumerate(predictions.items()):
    ax = axes[idx]
    if name == 'LSTM':
        y_true = y_test[SEQ_LEN:]
    else:
        y_true = y_test

    ax.scatter(y_true, y_pred, alpha=0.4, s=15, color='steelblue')
    min_val = min(y_true.min(), y_pred.min())
    max_val = max(y_true.max(), y_pred.max())
    ax.plot([min_val, max_val], [min_val, max_val], 'r--', linewidth=1.5, label='完美预测')

    mae = mean_absolute_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    ax.set_xlabel('真实成交额 (美元)', fontproperties=CHINESE_FONT)
    ax.set_ylabel('预测成交额 (美元)', fontproperties=CHINESE_FONT)
    ax.set_title(f'{name} - MAE: ${mae:,.2f}, R²: {r2:.4f}', fontproperties=CHINESE_FONT)
    ax.legend(prop=CHINESE_FONT)

for idx in range(len(predictions), len(axes)):
    axes[idx].set_visible(False)

plt.tight_layout()
plt.savefig(OUTPUT_DIR / '24_market_scatter.png', dpi=150, bbox_inches='tight')
plt.close()
print("   ✓ 图4: 24_market_scatter.png")

# 图5：误差分布
fig, axes = plt.subplots(rows, cols, figsize=(5 * cols, 5 * rows))
if n_models == 1:
    axes = [axes]
else:
    axes = axes.flatten()

for idx, (name, y_pred) in enumerate(predictions.items()):
    ax = axes[idx]
    if name == 'LSTM':
        y_true = y_test[SEQ_LEN:]
    else:
        y_true = y_test

    errors = y_pred - y_true
    ax.hist(errors, bins=30, color='steelblue', edgecolor='black', alpha=0.7)
    ax.axvline(x=0, color='red', linestyle='--', linewidth=1.5)
    ax.axvline(x=np.mean(errors), color='orange', linestyle='-', linewidth=1,
               label=f'均值: ${np.mean(errors):,.2f}')
    ax.set_xlabel('预测误差 (美元)', fontproperties=CHINESE_FONT)
    ax.set_ylabel('频次', fontproperties=CHINESE_FONT)
    ax.set_title(f'{name} - 误差分布', fontproperties=CHINESE_FONT)
    ax.legend(prop=CHINESE_FONT)

for idx in range(len(predictions), len(axes)):
    axes[idx].set_visible(False)

plt.tight_layout()
plt.savefig(OUTPUT_DIR / '25_market_error_dist.png', dpi=150, bbox_inches='tight')
plt.close()
print("   ✓ 图5: 25_market_error_dist.png")

# ============================================================
# 总结
# ============================================================
print("\n" + "=" * 80)
print("6. 最佳模型分析")
print("=" * 80)

best_mae = min(results, key=lambda x: x['MAE'])
best_r2 = max(results, key=lambda x: x['R2'])

print(f"\n🏆 最低 MAE: {best_mae['Model']} (${best_mae['MAE']:,.2f})")
print(f"🏆 最高 R²:  {best_r2['Model']} ({best_r2['R2']:.4f})")

print("\n" + "=" * 80)
print(f"✅ 完成！图表保存在: {OUTPUT_DIR}")
print("=" * 80)