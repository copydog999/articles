"""
CS2 饰品数据集全面统计分析可视化脚本（完整中文版）
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from pathlib import Path
from scipy import stats
from scipy.stats import skew, kurtosis, pearsonr
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# 字体配置
# ============================================================
FONT_PATH = 'C:/Windows/Fonts/msyh.ttc'
CHINESE_FONT = FontProperties(fname=FONT_PATH, size=12)
TITLE_FONT = FontProperties(fname=FONT_PATH, size=14, weight='bold')
LEGEND_FONT = FontProperties(fname=FONT_PATH, size=10)

# 设置 matplotlib 参数
plt.rcParams['figure.dpi'] = 120
plt.rcParams['axes.grid'] = True
plt.rcParams['grid.alpha'] = 0.3

# ============================================================
# 路径配置
# ============================================================
SCRIPT_DIR = Path(__file__).parent.absolute()
DATA_PATH = SCRIPT_DIR / "merged_dataset" / "merged_price_data.parquet"
OUTPUT_DIR = SCRIPT_DIR / "merged_dataset" / "figures"
OUTPUT_DIR.mkdir(exist_ok=True)

print("=" * 80)
print("CS2 饰品数据集全面统计分析")
print("=" * 80)

# ============================================================
# 加载数据
# ============================================================
print("\n1. 加载数据...")
df = pd.read_parquet(DATA_PATH)
print(f"   ✅ 总记录数: {len(df):,}")
print(f"   ✅ 物品总数: {df['item_file_name'].nunique():,}")
print(f"   ✅ 日期范围: {df['date'].min()} ~ {df['date'].max()}")

# 预处理
df['daily_value'] = df['price_dollar'] * df['sells']
df['log_price'] = np.log1p(df['price_dollar'])
df['year'] = pd.to_datetime(df['date']).dt.year
df['month'] = pd.to_datetime(df['date']).dt.month

# 筛选皮肤数据
skins_df = df[df['item_type'] == 'skin'].copy()
skins_with_wear = skins_df[skins_df['wear'].notna()].copy()

# ============================================================
# 全局统计指标
# ============================================================
print("\n2. 计算统计指标...")

daily_market = df.groupby('date').agg({
    'daily_value': 'sum',
    'sells': 'sum'
}).reset_index()

global_stats = {
    '总记录数': f"{len(df):,}",
    '物品总数': f"{df['item_file_name'].nunique():,}",
    '时间跨度(天)': f"{(df['date'].max() - df['date'].min()).days}",
    '价格最小值($)': f"${df['price_dollar'].min():.2f}",
    '价格最大值($)': f"${df['price_dollar'].max():.2f}",
    '价格平均值($)': f"${df['price_dollar'].mean():.2f}",
    '价格中位数($)': f"${df['price_dollar'].median():.2f}",
    '价格标准差($)': f"${df['price_dollar'].std():.2f}",
    '价格偏度': f"{skew(df['price_dollar']):.2f}",
    '价格峰度': f"{kurtosis(df['price_dollar']):.2f}",
    '日成交额平均值($)': f"${daily_market['daily_value'].mean():,.2f}",
    '日成交量平均值': f"{daily_market['sells'].mean():.0f}",
}

print("\n   全局统计指标:")
for k, v in global_stats.items():
    print(f"   {k}: {v}")

# ============================================================
# 图1：价格分布
# ============================================================
print("\n3. 生成图表...")
print("   📈 图1: 价格分布")

fig, axes = plt.subplots(2, 2, figsize=(14, 10))
fig.suptitle('CS2 饰品价格分布分析', fontproperties=TITLE_FONT)

# 1.1 价格直方图（线性）
ax = axes[0, 0]
ax.hist(df['price_dollar'], bins=100, color='steelblue', edgecolor='black', alpha=0.7)
ax.set_xlabel('价格 (美元)', fontproperties=CHINESE_FONT)
ax.set_ylabel('频次', fontproperties=CHINESE_FONT)
ax.set_title('价格直方图（线性坐标）', fontproperties=CHINESE_FONT)
ax.set_xlim(0, 200)

# 1.2 价格直方图（对数）
ax = axes[0, 1]
ax.hist(df['log_price'], bins=100, color='coral', edgecolor='black', alpha=0.7)
ax.set_xlabel('log(价格 + 1)', fontproperties=CHINESE_FONT)
ax.set_ylabel('频次', fontproperties=CHINESE_FONT)
ax.set_title('价格直方图（对数坐标）', fontproperties=CHINESE_FONT)

# 1.3 各类型物品价格箱线图
ax = axes[1, 0]
type_order = df.groupby('item_type')['price_dollar'].median().sort_values(ascending=False).head(8).index
df_type = df[df['item_type'].isin(type_order)]
positions = range(len(type_order))
boxes = ax.boxplot([df_type[df_type['item_type'] == t]['price_dollar'].clip(upper=200) for t in type_order],
                   positions=positions, labels=type_order, patch_artist=True)
for patch in boxes['boxes']:
    patch.set_facecolor('lightblue')
ax.set_xlabel('物品类型', fontproperties=CHINESE_FONT)
ax.set_ylabel('价格 (美元)', fontproperties=CHINESE_FONT)
ax.set_title('各类型物品价格分布', fontproperties=CHINESE_FONT)
ax.tick_params(axis='x', rotation=45)

# 1.4 价格密度曲线
ax = axes[1, 1]
for item_type in ['skin', 'sticker', 'crate', 'agent']:
    subset = df[df['item_type'] == item_type]['log_price']
    if len(subset) > 0:
        ax.hist(subset, bins=50, alpha=0.4, label=item_type)
ax.set_xlabel('log(价格 + 1)', fontproperties=CHINESE_FONT)
ax.set_ylabel('密度', fontproperties=CHINESE_FONT)
ax.set_title('各类型物品价格密度曲线', fontproperties=CHINESE_FONT)
ax.legend(prop=LEGEND_FONT)

plt.tight_layout()
plt.savefig(OUTPUT_DIR / '01_price_distribution.png', dpi=150, bbox_inches='tight')
plt.close()

# ============================================================
# 图2：稀有度与磨损分析
# ============================================================
print("   📈 图2: 稀有度与磨损分析")

fig, axes = plt.subplots(2, 2, figsize=(14, 10))
fig.suptitle('稀有度与磨损档位分析', fontproperties=TITLE_FONT)

rarity_order = ['Consumer Grade', 'Industrial Grade', 'Mil-Spec Grade',
                'Restricted', 'Classified', 'Covert', 'Extraordinary', 'Contraband']

# 2.1 稀有度价格箱线图
ax = axes[0, 0]
rarity_data = []
rarity_labels = []
for r in rarity_order:
    if r in skins_df['rarity'].values:
        rarity_data.append(skins_df[skins_df['rarity'] == r]['price_dollar'].clip(upper=500))
        rarity_labels.append(r)
boxes = ax.boxplot(rarity_data, labels=rarity_labels, patch_artist=True)
for patch in boxes['boxes']:
    patch.set_facecolor('lightblue')
ax.set_ylabel('价格 (美元)', fontproperties=CHINESE_FONT)
ax.set_title('不同稀有度的价格分布', fontproperties=CHINESE_FONT)
ax.tick_params(axis='x', rotation=45)

# 2.2 稀有度均价柱状图
ax = axes[0, 1]
rarity_means = skins_df.groupby('rarity')['price_dollar'].mean().reindex(rarity_order)
colors = plt.cm.viridis(np.linspace(0, 1, len(rarity_means)))
bars = ax.bar(range(len(rarity_means)), rarity_means.values, color=colors, edgecolor='black')
ax.set_xticks(range(len(rarity_means)))
ax.set_xticklabels(rarity_means.index, fontproperties=CHINESE_FONT, rotation=45)
ax.set_ylabel('均价 (美元)', fontproperties=CHINESE_FONT)
ax.set_title('各稀有度平均价格', fontproperties=CHINESE_FONT)
for bar, val in zip(bars, rarity_means.values):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5, f'${val:.1f}',
            ha='center', va='bottom', fontsize=9)

# 2.3 磨损档位价格箱线图
ax = axes[1, 0]
wear_order = ['Factory New', 'Minimal Wear', 'Field-Tested', 'Well-Worn', 'Battle-Scarred']
wear_data = []
wear_labels = []
for w in wear_order:
    if w in skins_with_wear['wear'].values:
        wear_data.append(skins_with_wear[skins_with_wear['wear'] == w]['price_dollar'].clip(upper=200))
        wear_labels.append(w)
boxes = ax.boxplot(wear_data, labels=wear_labels, patch_artist=True)
for patch in boxes['boxes']:
    patch.set_facecolor('lightgreen')
ax.set_ylabel('价格 (美元)', fontproperties=CHINESE_FONT)
ax.set_title('不同磨损档位的价格分布', fontproperties=CHINESE_FONT)
ax.tick_params(axis='x', rotation=45)

# 2.4 磨损档位均价柱状图
ax = axes[1, 1]
wear_means = skins_with_wear.groupby('wear')['price_dollar'].mean().reindex(wear_order)
bars = ax.bar(range(len(wear_means)), wear_means.values, color='steelblue', edgecolor='black')
ax.set_xticks(range(len(wear_means)))
ax.set_xticklabels(wear_means.index, fontproperties=CHINESE_FONT, rotation=45)
ax.set_ylabel('均价 (美元)', fontproperties=CHINESE_FONT)
ax.set_title('各磨损档位平均价格', fontproperties=CHINESE_FONT)
for bar, val in zip(bars, wear_means.values):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3, f'${val:.1f}',
            ha='center', va='bottom', fontsize=9)

plt.tight_layout()
plt.savefig(OUTPUT_DIR / '02_rarity_wear_analysis.png', dpi=150, bbox_inches='tight')
plt.close()

# ============================================================
# 图3：时间序列趋势
# ============================================================
print("   📈 图3: 时间序列趋势")

# 计算月度数据
daily_market = df.groupby('date').agg({
    'daily_value': 'sum',
    'sells': 'sum',
    'price_dollar': 'mean'
}).reset_index()
daily_market['month'] = pd.to_datetime(daily_market['date']).dt.to_period('M').astype(str)
monthly_market = daily_market.groupby('month').agg({
    'daily_value': 'mean',
    'sells': 'sum',
    'price_dollar': 'mean'
}).reset_index()
monthly_market['month_date'] = pd.to_datetime(monthly_market['month'] + '-01')

fig, axes = plt.subplots(2, 2, figsize=(14, 10))
fig.suptitle('市场时间序列趋势分析', fontproperties=TITLE_FONT)

# 3.1 月度成交额趋势
ax = axes[0, 0]
ax.plot(monthly_market['month_date'], monthly_market['daily_value'], linewidth=1.5, color='steelblue')
ax.fill_between(monthly_market['month_date'], monthly_market['daily_value'], alpha=0.3, color='steelblue')
ax.set_xlabel('日期', fontproperties=CHINESE_FONT)
ax.set_ylabel('月均成交额 (美元)', fontproperties=CHINESE_FONT)
ax.set_title('市场月度成交额趋势', fontproperties=CHINESE_FONT)
ax.tick_params(axis='x', rotation=45)

# 3.2 月度成交量趋势
ax = axes[0, 1]
ax.plot(monthly_market['month_date'], monthly_market['sells'], linewidth=1.5, color='coral')
ax.fill_between(monthly_market['month_date'], monthly_market['sells'], alpha=0.3, color='coral')
ax.set_xlabel('日期', fontproperties=CHINESE_FONT)
ax.set_ylabel('月成交量', fontproperties=CHINESE_FONT)
ax.set_title('市场月度成交量趋势', fontproperties=CHINESE_FONT)
ax.tick_params(axis='x', rotation=45)

# 3.3 月度均价趋势
ax = axes[1, 0]
ax.plot(monthly_market['month_date'], monthly_market['price_dollar'], linewidth=1.5, color='green')
ax.fill_between(monthly_market['month_date'], monthly_market['price_dollar'], alpha=0.3, color='green')
ax.set_xlabel('日期', fontproperties=CHINESE_FONT)
ax.set_ylabel('均价 (美元)', fontproperties=CHINESE_FONT)
ax.set_title('市场月度均价趋势', fontproperties=CHINESE_FONT)
ax.tick_params(axis='x', rotation=45)

# 3.4 月度均价热力图
ax = axes[1, 1]
df['year'] = pd.to_datetime(df['date']).dt.year
df['month_num'] = pd.to_datetime(df['date']).dt.month
monthly_price = df.groupby(['year', 'month_num'])['price_dollar'].mean().unstack()
monthly_price = monthly_price.dropna(axis=0, how='all')
im = ax.imshow(monthly_price.values, aspect='auto', cmap='YlOrRd')
ax.set_xticks(range(len(monthly_price.columns)))
ax.set_xticklabels(monthly_price.columns, fontproperties=CHINESE_FONT)
ax.set_yticks(range(len(monthly_price.index)))
ax.set_yticklabels(monthly_price.index.astype(int), fontproperties=CHINESE_FONT)
ax.set_xlabel('月份', fontproperties=CHINESE_FONT)
ax.set_ylabel('年份', fontproperties=CHINESE_FONT)
ax.set_title('月度均价热力图', fontproperties=CHINESE_FONT)
plt.colorbar(im, ax=ax, label='均价 (美元)')

plt.tight_layout()
plt.savefig(OUTPUT_DIR / '03_time_series_trends.png', dpi=150, bbox_inches='tight')
plt.close()

# ============================================================
# 图4：成交量与流动性分析
# ============================================================
print("   📈 图4: 成交量与流动性分析")

fig, axes = plt.subplots(2, 2, figsize=(14, 10))
fig.suptitle('成交量与流动性分析', fontproperties=TITLE_FONT)

# 4.1 成交量分布
ax = axes[0, 0]
sells_filtered = df[df['sells'] < 10000]['sells']
ax.hist(sells_filtered, bins=100, color='steelblue', edgecolor='black', alpha=0.7)
ax.set_xlabel('单日成交量', fontproperties=CHINESE_FONT)
ax.set_ylabel('频次', fontproperties=CHINESE_FONT)
ax.set_title('单日成交量分布', fontproperties=CHINESE_FONT)

# 4.2 价格-成交量散点图
ax = axes[0, 1]
sample = df.sample(min(5000, len(df)))
ax.scatter(sample['price_dollar'], sample['sells'], alpha=0.3, s=1, c='coral')
ax.set_xlabel('价格 (美元)', fontproperties=CHINESE_FONT)
ax.set_ylabel('成交量', fontproperties=CHINESE_FONT)
ax.set_title('价格与成交量关系', fontproperties=CHINESE_FONT)
ax.set_xlim(0, 500)

# 4.3 各类型物品平均成交量
ax = axes[1, 0]
type_volume = df.groupby('item_type')['sells'].mean().sort_values(ascending=False)
bars = ax.bar(range(len(type_volume)), type_volume.values, color='lightgreen', edgecolor='black')
ax.set_xticks(range(len(type_volume)))
ax.set_xticklabels(type_volume.index, fontproperties=CHINESE_FONT, rotation=45)
ax.set_ylabel('平均日成交量', fontproperties=CHINESE_FONT)
ax.set_title('各类型物品平均日成交量', fontproperties=CHINESE_FONT)

# 4.4 价格区间成交量
ax = axes[1, 1]
price_bins = [0, 1, 5, 10, 20, 50, 100, 500, 1000, 10000]
df['price_bin'] = pd.cut(df['price_dollar'], bins=price_bins)
price_bin_volume = df.groupby('price_bin')['sells'].mean()
bin_labels = ['$0-1', '$1-5', '$5-10', '$10-20', '$20-50', '$50-100', '$100-500', '$500-1000', '$1000+']
bars = ax.bar(range(len(price_bin_volume)), price_bin_volume.values, color='steelblue', edgecolor='black')
ax.set_xticks(range(len(price_bin_volume)))
ax.set_xticklabels(bin_labels, fontproperties=CHINESE_FONT, rotation=45)
ax.set_ylabel('平均日成交量', fontproperties=CHINESE_FONT)
ax.set_title('不同价格区间的平均成交量', fontproperties=CHINESE_FONT)

plt.tight_layout()
plt.savefig(OUTPUT_DIR / '04_volume_liquidity.png', dpi=150, bbox_inches='tight')
plt.close()

# ============================================================
# 图5：物品类型详细分析
# ============================================================
print("   📈 图5: 物品类型详细分析")

fig, axes = plt.subplots(2, 2, figsize=(14, 10))
fig.suptitle('物品类型详细分析', fontproperties=TITLE_FONT)

# 5.1 物品类型数量分布（饼图）
ax = axes[0, 0]
type_counts = df.groupby('item_type')['item_file_name'].nunique().sort_values(ascending=False)
colors = plt.cm.Set3(np.linspace(0, 1, len(type_counts)))
ax.pie(type_counts.values, labels=type_counts.index, autopct='%1.1f%%', colors=colors, startangle=90)
ax.set_title('物品类型数量分布', fontproperties=CHINESE_FONT)

# 5.2 各类型价格箱线图
ax = axes[0, 1]
top_types = type_counts.head(8).index.tolist()
df_top = df[df['item_type'].isin(top_types)]
positions = range(len(top_types))
boxes = ax.boxplot([df_top[df_top['item_type'] == t]['log_price'] for t in top_types],
                   positions=positions, labels=top_types, patch_artist=True)
for patch in boxes['boxes']:
    patch.set_facecolor('lightblue')
ax.set_xlabel('物品类型', fontproperties=CHINESE_FONT)
ax.set_ylabel('log(价格 + 1)', fontproperties=CHINESE_FONT)
ax.set_title('各类型物品价格分布（对数）', fontproperties=CHINESE_FONT)
ax.tick_params(axis='x', rotation=45)

# 5.3 皮肤武器类型分布（前15）
ax = axes[1, 0]
weapon_counts = skins_df.groupby('weapon')['item_file_name'].nunique().sort_values(ascending=False).head(15)
bars = ax.barh(range(len(weapon_counts)), weapon_counts.values, color='coral', edgecolor='black')
ax.set_yticks(range(len(weapon_counts)))
ax.set_yticklabels(weapon_counts.index, fontproperties=CHINESE_FONT)
ax.set_xlabel('皮肤数量', fontproperties=CHINESE_FONT)
ax.set_title('皮肤数量最多的15种武器', fontproperties=CHINESE_FONT)

# 5.4 皮肤武器均价（前15）
ax = axes[1, 1]
weapon_price = skins_df.groupby('weapon')['price_dollar'].mean().sort_values(ascending=False).head(15)
bars = ax.barh(range(len(weapon_price)), weapon_price.values, color='steelblue', edgecolor='black')
ax.set_yticks(range(len(weapon_price)))
ax.set_yticklabels(weapon_price.index, fontproperties=CHINESE_FONT)
ax.set_xlabel('均价 (美元)', fontproperties=CHINESE_FONT)
ax.set_title('均价最高的15种武器', fontproperties=CHINESE_FONT)

plt.tight_layout()
plt.savefig(OUTPUT_DIR / '05_item_type_analysis.png', dpi=150, bbox_inches='tight')
plt.close()

# ============================================================
# 图6：相关性分析与统计指标
# ============================================================
print("   📈 图6: 相关性分析与统计指标")

# 计算日级别相关性
daily_df = df.groupby('date').agg({
    'price_dollar': 'mean',
    'daily_value': 'sum',
    'sells': 'sum'
}).reset_index()
daily_df['price_change'] = daily_df['price_dollar'].pct_change()
daily_df['volume_change'] = daily_df['sells'].pct_change()
daily_df = daily_df.dropna()

corr_price_volume, p1 = pearsonr(daily_df['price_dollar'], daily_df['sells'])
corr_price_change_volume_change, p2 = pearsonr(daily_df['price_change'], daily_df['volume_change'])
corr_price_value, p3 = pearsonr(daily_df['price_dollar'], daily_df['daily_value'])

fig, axes = plt.subplots(2, 2, figsize=(14, 10))
fig.suptitle('相关性分析与统计指标', fontproperties=TITLE_FONT)

# 6.1 价格 vs 成交量
ax = axes[0, 0]
ax.scatter(daily_df['price_dollar'], daily_df['sells'], alpha=0.3, s=5, c='steelblue')
ax.set_xlabel('日均价格 (美元)', fontproperties=CHINESE_FONT)
ax.set_ylabel('日成交量', fontproperties=CHINESE_FONT)
ax.set_title(f'价格 vs 成交量 (相关系数 r = {corr_price_volume:.3f})', fontproperties=CHINESE_FONT)

# 6.2 价格变化率 vs 成交量变化率
ax = axes[0, 1]
ax.scatter(daily_df['price_change'], daily_df['volume_change'], alpha=0.3, s=5, c='coral')
ax.set_xlabel('价格变化率', fontproperties=CHINESE_FONT)
ax.set_ylabel('成交量变化率', fontproperties=CHINESE_FONT)
ax.set_title(f'价格变化率 vs 成交量变化率 (r = {corr_price_change_volume_change:.3f})', fontproperties=CHINESE_FONT)
ax.set_xlim(-0.5, 0.5)
ax.set_ylim(-0.5, 0.5)

# 6.3 价格 vs 成交额
ax = axes[1, 0]
ax.scatter(daily_df['price_dollar'], daily_df['daily_value'], alpha=0.3, s=5, color='green')
ax.set_xlabel('日均价格 (美元)', fontproperties=CHINESE_FONT)
ax.set_ylabel('日成交额 (美元)', fontproperties=CHINESE_FONT)
ax.set_title(f'价格 vs 成交额 (相关系数 r = {corr_price_value:.3f})', fontproperties=CHINESE_FONT)

# 6.4 统计指标卡片
ax = axes[1, 1]
ax.axis('off')
stats_text = f"""
【分布特征】
价格偏度: {skew(df['price_dollar']):.2f}
价格峰度: {kurtosis(df['price_dollar']):.2f}
价格变异系数: {df['price_dollar'].std() / df['price_dollar'].mean():.2f}

【集中趋势】
价格均值: ${df['price_dollar'].mean():.2f}
价格中位数: ${df['price_dollar'].median():.2f}

【离散程度】
价格标准差: ${df['price_dollar'].std():.2f}
四分位距: ${df['price_dollar'].quantile(0.75) - df['price_dollar'].quantile(0.25):.2f}

【相关性】
价格-成交量: r = {corr_price_volume:.3f}
价格变化-成交量变化: r = {corr_price_change_volume_change:.3f}
"""
ax.text(0.1, 0.95, stats_text, transform=ax.transAxes, fontsize=10,
        verticalalignment='top', family='monospace',
        bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
ax.set_title('统计指标汇总', fontproperties=CHINESE_FONT)

plt.tight_layout()
plt.savefig(OUTPUT_DIR / '06_correlation_statistics.png', dpi=150, bbox_inches='tight')
plt.close()

# ============================================================
# 图7：价格分位数与极端值
# ============================================================
print("   📈 图7: 价格分位数与极端值")

fig, axes = plt.subplots(1, 2, figsize=(14, 5))
fig.suptitle('价格分位数与极端值分析', fontproperties=TITLE_FONT)

# 7.1 价格分位数
ax = axes[0]
percentiles = [1, 5, 10, 25, 50, 75, 90, 95, 99]
percentile_values = [np.percentile(df['price_dollar'], p) for p in percentiles]
bars = ax.bar([f'{p}%' for p in percentiles], percentile_values, color='steelblue', edgecolor='black')
ax.set_xlabel('分位数', fontproperties=CHINESE_FONT)
ax.set_ylabel('价格 (美元)', fontproperties=CHINESE_FONT)
ax.set_title('价格分位数分布', fontproperties=CHINESE_FONT)
for bar, val in zip(bars, percentile_values):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.1, f'${val:.2f}',
            ha='center', va='bottom', fontsize=9)

# 7.2 历史最高价 TOP20
ax = axes[1]
top_items = df.groupby('item_base_name')['price_dollar'].max().sort_values(ascending=False).head(20)
bars = ax.barh(range(len(top_items)), top_items.values, color='coral', edgecolor='black')
ax.set_yticks(range(len(top_items)))
ax.set_yticklabels(top_items.index, fontproperties=CHINESE_FONT, fontsize=8)
ax.set_xlabel('最高价格 (美元)', fontproperties=CHINESE_FONT)
ax.set_title('历史最高价 TOP20 物品', fontproperties=CHINESE_FONT)

plt.tight_layout()
plt.savefig(OUTPUT_DIR / '07_percentiles_extremes.png', dpi=150, bbox_inches='tight')
plt.close()

# ============================================================
# 图8：最终汇总仪表板
# ============================================================
print("   📈 图8: 最终汇总仪表板")

fig, axes = plt.subplots(2, 2, figsize=(16, 12))
fig.suptitle('CS2 饰品市场数据汇总仪表板', fontproperties=TITLE_FONT, fontsize=18)

# 8.1 KPI 卡片
ax = axes[0, 0]
ax.axis('off')
kpi_text = f"""
╔══════════════════════════════════════════════════════════════╗
║                      关键性能指标 (KPI)                       ║
╠══════════════════════════════════════════════════════════════╣
║  总记录数              {len(df):>15,}                              ║
║  物品总数              {df['item_file_name'].nunique():>15,}                              ║
║  时间跨度              {(df['date'].max() - df['date'].min()).days:>15} 天                         ║
║  市场总成交额          ${df['daily_value'].sum():>14,.0f}                              ║
║  市场总成交量          {df['sells'].sum():>15,}                              ║
║  整体均价              ${df['price_dollar'].mean():>14.2f}                              ║
║  最高价物品            ${df['price_dollar'].max():>14.2f}                              ║
║  数据完整度            100%                                 ║
╚══════════════════════════════════════════════════════════════╝
"""
ax.text(0.1, 0.95, kpi_text, transform=ax.transAxes, fontsize=11,
        verticalalignment='top', family='monospace')

# 8.2 年度价格分布
ax = axes[0, 1]
yearly_data = [df[df['year'] == y]['price_dollar'].clip(upper=200) for y in sorted(df['year'].unique()) if y >= 2015]
boxes = ax.boxplot(yearly_data, labels=[y for y in sorted(df['year'].unique()) if y >= 2015], patch_artist=True)
for patch in boxes['boxes']:
    patch.set_facecolor('lightblue')
ax.set_xlabel('年份', fontproperties=CHINESE_FONT)
ax.set_ylabel('价格 (美元)', fontproperties=CHINESE_FONT)
ax.set_title('年度价格分布（2015-2023）', fontproperties=CHINESE_FONT)
ax.tick_params(axis='x', rotation=45)

# 8.3 市场累计物品数增长
ax = axes[1, 0]
first_appearance = df.groupby('item_file_name')['date'].min().reset_index()
first_appearance['year_month'] = pd.to_datetime(first_appearance['date']).dt.to_period('M')
monthly_new_items = first_appearance.groupby('year_month').size().cumsum().reset_index()
monthly_new_items['year_month'] = monthly_new_items['year_month'].astype(str)
sample_idx = range(0, len(monthly_new_items), 6)
ax.plot(monthly_new_items['year_month'].iloc[sample_idx], monthly_new_items[0].iloc[sample_idx],
        marker='o', linewidth=1.5, color='steelblue')
ax.set_xlabel('年月', fontproperties=CHINESE_FONT)
ax.set_ylabel('累计物品数', fontproperties=CHINESE_FONT)
ax.set_title('市场累计物品数增长趋势', fontproperties=CHINESE_FONT)
ax.tick_params(axis='x', rotation=45)

# 8.4 价格-成交量四象限
ax = axes[1, 1]
median_price = df['price_dollar'].median()
median_volume = df['sells'].median()
df['price_category'] = df['price_dollar'] > median_price
df['volume_category'] = df['sells'] > median_volume
quadrant_counts = df.groupby(['price_category', 'volume_category']).size()
quadrant_labels = ['低价低量', '低价高量', '高价低量', '高价高量']
quadrant_values = [
    quadrant_counts.get((False, False), 0),
    quadrant_counts.get((False, True), 0),
    quadrant_counts.get((True, False), 0),
    quadrant_counts.get((True, True), 0)
]
colors_q = ['lightgreen', 'steelblue', 'coral', 'gold']
bars = ax.bar(quadrant_labels, quadrant_values, color=colors_q, edgecolor='black')
ax.set_xlabel('价格-成交量组合', fontproperties=CHINESE_FONT)
ax.set_ylabel('记录数', fontproperties=CHINESE_FONT)
ax.set_title('价格-成交量四象限分布', fontproperties=CHINESE_FONT)
ax.tick_params(axis='x', rotation=45)

plt.tight_layout()
plt.savefig(OUTPUT_DIR / '08_dashboard_summary.png', dpi=150, bbox_inches='tight')
plt.close()

# ============================================================
# 输出完成信息
# ============================================================
print("\n" + "=" * 80)
print("✅ 所有图表生成完成！")
print(f"📁 保存位置: {OUTPUT_DIR}")
print("=" * 80)

print("\n📋 生成的文件列表:")
for f in sorted(OUTPUT_DIR.glob("*.png")):
    print(f"   - {f.name}")