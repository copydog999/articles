"""
Self-Play Training Loop for GeepSeek
Implements AlphaZero-style self-play with MCTS
"""
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.tensorboard import SummaryWriter
import numpy as np
from typing import List, Tuple, Dict
import time
import os
from tqdm import tqdm

from game.gomoku import GomokuEnv
from models.network import GomokuNetwork
from mcts.search import MCTS
from training.replay_buffer import PrioritizedReplayBuffer


class SelfPlayTrainer:
    """
    Self-play training system for Gomoku
    
    Combines:
    - MCTS-based self-play for data generation
    - Neural network training with policy and value losses
    - Priority experience replay
    """
    
    def __init__(self, config: dict):
        self.config = config
        
        # Setup device
        self.device = torch.device(config['hardware']['device'] 
                                   if torch.cuda.is_available() else 'cpu')
        print(f"Using device: {self.device}")
        
        # Create network
        self.network = GomokuNetwork(
            board_size=config['game']['board_size'],
            num_filters=config['network']['num_filters'],
            num_residual_blocks=config['network']['num_residual_blocks']
        ).to(self.device)
        
        # Create optimizer
        self.optimizer = optim.SGD(
            self.network.parameters(),
            lr=config['training']['learning_rate'],
            momentum=config['training']['momentum'],
            weight_decay=config['training']['weight_decay']
        )
        
        # Learning rate scheduler
        self.scheduler = optim.lr_scheduler.StepLR(
            self.optimizer,
            step_size=config['training']['lr_decay_step'],
            gamma=config['training']['lr_decay_gamma']
        )
        
        # Create MCTS
        self.mcts = MCTS(self.network, config['mcts'])
        
        # Create replay buffer
        self.replay_buffer = PrioritizedReplayBuffer(
            capacity=config['replay']['buffer_size'],
            alpha=config['replay']['priority_alpha'],
            beta=config['replay']['priority_beta']
        )
        
        # Loss functions
        self.policy_criterion = nn.CrossEntropyLoss(reduction='none')
        self.value_criterion = nn.MSELoss(reduction='none')
        
        # TensorBoard writer
        log_dir = config['logging']['log_dir']
        os.makedirs(log_dir, exist_ok=True)
        self.writer = SummaryWriter(log_dir)
        
        # Checkpoint directory
        self.checkpoint_dir = config['logging']['checkpoint_dir']
        os.makedirs(self.checkpoint_dir, exist_ok=True)
        
        # Statistics
        self.global_step = 0
        self.games_played = 0
        self.wins_as_black = 0
        self.wins_as_white = 0
        self.draws = 0
    
    def self_play_game(self) -> List[Dict]:
        """
        Play one self-play game using MCTS
        
        Returns:
            trajectory: List of (state, policy, player) tuples
        """
        env = GomokuEnv(
            board_size=self.config['game']['board_size'],
            win_length=self.config['game']['win_length']
        )
        
        trajectory = []
        move_number = 0
        
        while not env.done:
            # Get temperature for current move
            temperature = self.mcts.get_temperature(move_number)
            
            # Run MCTS search
            action, visit_counts = self.mcts.search(env, temperature=temperature)
            
            # Store state and policy
            state = env.get_state()
            policy = np.zeros(env.board_size * env.board_size)
            
            # Convert visit counts to policy
            legal_moves = env.get_legal_moves()
            for i, move in enumerate(legal_moves):
                idx = move[0] * env.board_size + move[1]
                policy[idx] = visit_counts[i] if i < len(visit_counts) else 0
            
            # Normalize policy
            if policy.sum() > 0:
                policy /= policy.sum()
            
            trajectory.append({
                'state': state,
                'policy': policy,
                'player': env.current_player
            })
            
            # Make move
            env.step(action)
            move_number += 1
        
        # Determine game outcome
        winner = env.winner
        
        return trajectory, winner
    
    def generate_training_data(self, num_games: int = 100):
        """
        Generate training data through self-play
        
        Args:
            num_games: Number of self-play games to play
        """
        print(f"\nGenerating data from {num_games} self-play games...")
        
        for game_idx in tqdm(range(num_games), desc="Self-play"):
            trajectory, winner = self.self_play_game()
            
            # Assign values based on outcome
            for step_data in trajectory:
                player = step_data['player']
                
                if winner is None:
                    value = 0.0  # Draw
                elif winner == player:
                    value = 1.0  # Win
                else:
                    value = -1.0  # Loss
                
                # Add to replay buffer
                self.replay_buffer.add(
                    step_data['state'],
                    step_data['policy'],
                    value,
                    augment=self.config['augmentation']['enabled']
                )
            
            # Update statistics
            self.games_played += 1
            if winner == GomokuEnv.BLACK:
                self.wins_as_black += 1
            elif winner == GomokuEnv.WHITE:
                self.wins_as_white += 1
            else:
                self.draws += 1
        
        print(f"Buffer size: {len(self.replay_buffer)}")
    
    def train_network(self, num_epochs: int = 1):
        """
        Train neural network on replay buffer data
        
        Args:
            num_epochs: Number of training epochs
        """
        if len(self.replay_buffer) < self.config['training']['batch_size']:
            print("Not enough data for training")
            return
        
        batch_size = self.config['training']['batch_size']
        total_loss = 0
        total_policy_loss = 0
        total_value_loss = 0
        num_batches = 0
        
        self.network.train()
        
        for epoch in range(num_epochs):
            # Sample batch
            indices, states, policies, values, weights = \
                self.replay_buffer.sample(batch_size)
            
            # Convert to tensors
            state_tensor = torch.FloatTensor(np.array(states)).to(self.device)
            policy_tensor = torch.FloatTensor(np.array(policies)).to(self.device)
            value_tensor = torch.FloatTensor(values).unsqueeze(1).to(self.device)
            weight_tensor = torch.FloatTensor(weights).to(self.device)
            
            # Forward pass
            policy_logits, value_pred = self.network(state_tensor)
            
            # Calculate losses
            policy_loss = self.policy_criterion(policy_logits, 
                                                policy_tensor.argmax(dim=1))
            value_loss = self.value_criterion(value_pred, value_tensor)
            
            # Weighted loss
            policy_loss = (policy_loss * weight_tensor).mean()
            value_loss = (value_loss * weight_tensor).mean()
            
            # Combined loss
            loss = policy_loss + value_loss
            
            # Backward pass
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()
            
            # Update priorities (use combined error as proxy for TD error)
            td_errors = (policy_loss.detach().cpu().numpy() + 
                        value_loss.detach().cpu().numpy())
            self.replay_buffer.update_priorities(indices, [td_errors] * len(indices))
            
            # Accumulate statistics
            total_loss += loss.item()
            total_policy_loss += policy_loss.item()
            total_value_loss += value_loss.item()
            num_batches += 1
        
        # Log metrics
        avg_loss = total_loss / num_batches
        avg_policy_loss = total_policy_loss / num_batches
        avg_value_loss = total_value_loss / num_batches
        
        self.writer.add_scalar('Loss/Total', avg_loss, self.global_step)
        self.writer.add_scalar('Loss/Policy', avg_policy_loss, self.global_step)
        self.writer.add_scalar('Loss/Value', avg_value_loss, self.global_step)
        self.writer.add_scalar('Learning Rate', 
                              self.optimizer.param_groups[0]['lr'], 
                              self.global_step)
        
        print(f"Training - Loss: {avg_loss:.4f}, "
              f"Policy: {avg_policy_loss:.4f}, "
              f"Value: {avg_value_loss:.4f}")
        
        self.global_step += 1
    
    def save_checkpoint(self, filename: str = None):
        """Save model checkpoint"""
        if filename is None:
            filename = f"checkpoint_{self.global_step}.pth"
        
        filepath = os.path.join(self.checkpoint_dir, filename)
        
        torch.save({
            'global_step': self.global_step,
            'games_played': self.games_played,
            'network_state_dict': self.network.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'scheduler_state_dict': self.scheduler.state_dict(),
        }, filepath)
        
        print(f"Checkpoint saved to {filepath}")
    
    def load_checkpoint(self, filepath: str):
        """Load model checkpoint"""
        checkpoint = torch.load(filepath, map_location=self.device)
        
        self.global_step = checkpoint['global_step']
        self.games_played = checkpoint['games_played']
        self.network.load_state_dict(checkpoint['network_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        self.scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
        
        print(f"Checkpoint loaded from {filepath}")
    
    def get_statistics(self) -> Dict:
        """Get training statistics"""
        return {
            'games_played': self.games_played,
            'wins_as_black': self.wins_as_black,
            'wins_as_white': self.wins_as_white,
            'draws': self.draws,
            'win_rate_black': self.wins_as_black / max(1, self.games_played),
            'win_rate_white': self.wins_as_white / max(1, self.games_played),
            'buffer_size': len(self.replay_buffer),
            'global_step': self.global_step
        }
