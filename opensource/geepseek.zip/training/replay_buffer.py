"""
Priority Experience Replay Buffer
Implements prioritized sampling based on TD error
"""
import numpy as np
from typing import List, Tuple, Optional
from utils.augmentation import DataAugmentation


class PrioritizedReplayBuffer:
    """
    Priority Experience Replay with SumTree
    
    Stores (state, policy, value) tuples and samples based on priority
    """
    
    def __init__(self, capacity: int = 500000, alpha: float = 0.6, beta: float = 0.4):
        """
        Args:
            capacity: Maximum buffer size
            alpha: Priority exponent (0 = uniform, 1 = full priority)
            beta: Importance sampling exponent (annealed to 1.0)
        """
        self.capacity = capacity
        self.alpha = alpha
        self.beta = beta
        
        # Storage
        self.states: List[np.ndarray] = []
        self.policies: List[np.ndarray] = []
        self.values: List[float] = []
        self.priorities: List[float] = []
        
        self.position = 0
        self.size = 0
        self.max_priority = 1.0
    
    def add(self, state: np.ndarray, policy: np.ndarray, value: float, 
            augment: bool = True):
        """
        Add experience to buffer
        
        Args:
            state: Board state (3, board_size, board_size)
            policy: MCTS policy vector
            value: Game outcome (-1, 0, or 1)
            augment: Whether to apply data augmentation
        """
        if augment:
            # Generate 8 augmented samples
            samples = DataAugmentation.augment_sample(state, policy, value)
            for aug_state, aug_policy, aug_value in samples:
                self._add_single(aug_state, aug_policy, aug_value)
        else:
            self._add_single(state, policy, value)
    
    def _add_single(self, state: np.ndarray, policy: np.ndarray, value: float):
        """Add single sample without augmentation"""
        priority = self.max_priority if self.size > 0 else 1.0
        
        if self.size < self.capacity:
            self.states.append(state)
            self.policies.append(policy)
            self.values.append(value)
            self.priorities.append(priority ** self.alpha)
            self.size += 1
        else:
            # Overwrite oldest
            self.states[self.position] = state
            self.policies[self.position] = policy
            self.values[self.position] = value
            self.priorities[self.position] = priority ** self.alpha
        
        self.position = (self.position + 1) % self.capacity
    
    def sample(self, batch_size: int) -> Tuple[List, List, List, List, List]:
        """
        Sample batch of experiences with priority
        
        Returns:
            indices: Sampled indices
            states: Batch of states
            policies: Batch of policies
            values: Batch of values
            weights: Importance sampling weights
        """
        if self.size == 0:
            raise ValueError("Cannot sample from empty buffer")
        
        # Calculate sampling probabilities
        priorities = np.array(self.priorities[:self.size])
        probs = priorities / priorities.sum()
        
        # Sample indices
        indices = np.random.choice(self.size, batch_size, p=probs, replace=False)
        
        # Calculate importance sampling weights
        weights = (self.size * probs[indices]) ** (-self.beta)
        weights /= weights.max()  # Normalize
        
        # Get samples
        states = [self.states[i] for i in indices]
        policies = [self.policies[i] for i in indices]
        values = [self.values[i] for i in indices]
        
        return indices.tolist(), states, policies, values, weights.tolist()
    
    def update_priorities(self, indices: List[int], td_errors: List[float]):
        """
        Update priorities based on TD errors
        
        Args:
            indices: Indices of sampled experiences
            td_errors: Temporal difference errors
        """
        for idx, td_error in zip(indices, td_errors):
            if idx < len(self.priorities):
                priority = (abs(td_error) + 1e-6) ** self.alpha
                self.priorities[idx] = priority
                self.max_priority = max(self.max_priority, priority)
    
    def anneal_beta(self, step: int, total_steps: int):
        """Anneal beta parameter towards 1.0"""
        progress = step / total_steps
        self.beta = min(1.0, self.beta + progress * (1.0 - self.beta))
    
    def __len__(self) -> int:
        return self.size
    
    def get_statistics(self) -> dict:
        """Get buffer statistics"""
        if self.size == 0:
            return {'size': 0, 'capacity': self.capacity}
        
        priorities = np.array(self.priorities[:self.size])
        return {
            'size': self.size,
            'capacity': self.capacity,
            'fill_ratio': self.size / self.capacity,
            'mean_priority': priorities.mean(),
            'std_priority': priorities.std(),
            'max_priority': priorities.max(),
            'min_priority': priorities.min()
        }
