"""
Gomoku Game Environment
Implements standard 15x15 Gomoku game logic with win detection
"""
import numpy as np
from typing import List, Tuple, Optional


class GomokuEnv:
    """Standard Gomoku (Five in a Row) environment on 15x15 board"""
    
    EMPTY = 0
    BLACK = 1
    WHITE = 2
    
    def __init__(self, board_size: int = 15, win_length: int = 5):
        self.board_size = board_size
        self.win_length = win_length
        self.reset()
    
    def reset(self):
        """Reset the game to initial state"""
        self.board = np.zeros((self.board_size, self.board_size), dtype=np.int8)
        self.current_player = self.BLACK
        self.move_history: List[Tuple[int, int]] = []
        self.done = False
        self.winner = None
        return self.get_state()
    
    def get_state(self) -> np.ndarray:
        """
        Get current board state as 3-channel tensor
        Channel 0: Black stones
        Channel 1: White stones
        Channel 2: Current player (all black or all white)
        """
        state = np.zeros((3, self.board_size, self.board_size), dtype=np.float32)
        state[0] = (self.board == self.BLACK).astype(np.float32)
        state[1] = (self.board == self.WHITE).astype(np.float32)
        state[2].fill(1.0 if self.current_player == self.BLACK else 0.0)
        return state
    
    def get_legal_moves(self) -> List[Tuple[int, int]]:
        """Get list of legal moves (empty positions)"""
        if self.done:
            return []
        
        legal_moves = []
        for i in range(self.board_size):
            for j in range(self.board_size):
                if self.board[i, j] == self.EMPTY:
                    # For first move, only center is allowed (optional rule)
                    if len(self.move_history) == 0:
                        center = self.board_size // 2
                        if i == center and j == center:
                            legal_moves.append((i, j))
                        # If no center restriction, allow all
                        if not legal_moves:
                            return [(i, j) for i in range(self.board_size) 
                                   for j in range(self.board_size)]
                    else:
                        legal_moves.append((i, j))
        return legal_moves
    
    def step(self, action: Tuple[int, int]) -> Tuple[np.ndarray, float, bool]:
        """
        Execute a move
        
        Args:
            action: (row, col) tuple
            
        Returns:
            next_state, reward, done
        """
        row, col = action
        
        # Validate move
        if self.done:
            raise ValueError("Game is already finished")
        if self.board[row, col] != self.EMPTY:
            raise ValueError(f"Invalid move at ({row}, {col}) - position occupied")
        
        # Place stone
        self.board[row, col] = self.current_player
        self.move_history.append((row, col))
        
        # Check win condition
        if self._check_win(row, col):
            self.done = True
            self.winner = self.current_player
            reward = 1.0
        elif len(self.move_history) >= self.board_size * self.board_size:
            # Draw
            self.done = True
            self.winner = None
            reward = 0.0
        else:
            # Switch player
            self.current_player = self.WHITE if self.current_player == self.BLACK else self.BLACK
            reward = 0.0
        
        return self.get_state(), reward, self.done
    
    def _check_win(self, row: int, col: int) -> bool:
        """Check if the last move resulted in a win"""
        player = self.board[row, col]
        
        # Four directions: horizontal, vertical, two diagonals
        directions = [
            (0, 1),   # Horizontal
            (1, 0),   # Vertical
            (1, 1),   # Diagonal \
            (1, -1)   # Diagonal /
        ]
        
        for dr, dc in directions:
            count = 1  # Count the current stone
            
            # Check forward direction
            r, c = row + dr, col + dc
            while 0 <= r < self.board_size and 0 <= c < self.board_size:
                if self.board[r, c] == player:
                    count += 1
                    r += dr
                    c += dc
                else:
                    break
            
            # Check backward direction
            r, c = row - dr, col - dc
            while 0 <= r < self.board_size and 0 <= c < self.board_size:
                if self.board[r, c] == player:
                    count += 1
                    r -= dr
                    c -= dc
                else:
                    break
            
            if count >= self.win_length:
                return True
        
        return False
    
    def render(self):
        """Print the board to console"""
        print("\n  ", end="")
        for j in range(self.board_size):
            print(f"{j:2d}", end=" ")
        print()
        
        for i in range(self.board_size):
            print(f"{i:2d} ", end="")
            for j in range(self.board_size):
                if self.board[i, j] == self.EMPTY:
                    print(" .", end=" ")
                elif self.board[i, j] == self.BLACK:
                    print(" X", end=" ")
                else:
                    print(" O", end=" ")
            print()
        print()
    
    def clone(self) -> 'GomokuEnv':
        """Create a deep copy of the current game state"""
        env = GomokuEnv(self.board_size, self.win_length)
        env.board = self.board.copy()
        env.current_player = self.current_player
        env.move_history = self.move_history.copy()
        env.done = self.done
        env.winner = self.winner
        return env
    
    def get_move_count(self) -> int:
        """Get number of moves made so far"""
        return len(self.move_history)
