"""
Monte Carlo Tree Search (MCTS) for Gomoku
Implements virtual loss, Dirichlet noise, and temperature scheduling
"""
import numpy as np
import torch
import math
from typing import List, Tuple, Optional, Dict
from game.gomoku import GomokuEnv


class MCTSNode:
    """Node in the MCTS search tree"""
    
    def __init__(self, state: np.ndarray, parent=None, action=None, player=1):
        self.state = state
        self.parent = parent
        self.action = action  # Action that led to this node
        self.player = player
        
        # Statistics
        self.visit_count = 0
        self.value_sum = 0.0
        self.mean_value = 0.0
        
        # Children
        self.children: Dict[Tuple[int, int], 'MCTSNode'] = {}
        
        # Policy prior (from neural network)
        self.prior_probs: Dict[Tuple[int, int], float] = {}
        
        # Virtual loss for parallel search
        self.virtual_loss = 0.0
    
    def is_leaf(self) -> bool:
        """Check if node is a leaf (has no expanded children)"""
        return len(self.children) == 0
    
    def is_root(self) -> bool:
        """Check if node is root"""
        return self.parent is None
    
    def get_q_value(self) -> float:
        """Get Q-value (average value)"""
        if self.visit_count == 0:
            return 0.0
        return self.value_sum / self.visit_count
    
    def update(self, value: float):
        """Update node statistics with backpropagated value"""
        self.visit_count += 1
        self.value_sum += value
        self.mean_value = self.value_sum / self.visit_count


class MCTS:
    """
    Monte Carlo Tree Search with PUCT formula
    
    Features:
    - Virtual loss for parallel simulation
    - Dirichlet noise for exploration
    - Temperature scheduling for move selection
    """
    
    def __init__(self, network, config: dict):
        self.network = network
        self.device = next(network.parameters()).device
        
        # MCTS hyperparameters
        self.num_simulations = config.get('num_simulations', 800)
        self.c_puct = config.get('c_puct', 1.5)
        self.dirichlet_alpha = config.get('dirichlet_alpha', 0.3)
        self.dirichlet_epsilon = config.get('dirichlet_epsilon', 0.25)
        self.temperature_init = config.get('temperature_init', 1.0)
        self.temperature_decay_steps = config.get('temperature_decay_steps', 10)
        self.virtual_loss_weight = config.get('virtual_loss_weight', 3)
        
        # Root node
        self.root = None
    
    def search(self, env: GomokuEnv, temperature: float = 1.0, 
               add_dirichlet: bool = True) -> Tuple[Tuple[int, int], List[float]]:
        """
        Run MCTS search from current game state
        
        Args:
            env: Current game environment
            temperature: Temperature for move selection (higher = more random)
            add_dirichlet: Whether to add Dirichlet noise at root
            
        Returns:
            selected_action: Best action (row, col)
            visit_counts: Visit counts for all legal moves
        """
        # Create root node
        state = env.get_state()
        self.root = MCTSNode(state, player=env.current_player)
        
        # Evaluate root with neural network
        self._expand_node(self.root)
        
        # Add Dirichlet noise to root priors for exploration
        if add_dirichlet:
            self._add_dirichlet_noise(self.root, env)
        
        # Run simulations
        for _ in range(self.num_simulations):
            # Select leaf node using PUCT
            leaf, path = self._select_leaf(env)
            
            # If leaf is terminal or not expanded, evaluate it
            if not env.done and leaf.is_leaf():
                self._expand_node(leaf)
            
            # Backpropagate value
            value = leaf.mean_value if not leaf.is_leaf() else 0.0
            self._backpropagate(path, value)
        
        # Select move based on visit counts and temperature
        action, visit_counts = self._select_move(env, temperature)
        
        return action, visit_counts
    
    def _select_leaf(self, env: GomokuEnv) -> Tuple[MCTSNode, List[MCTSNode]]:
        """
        Select leaf node using PUCT formula
        
        Returns:
            leaf: Selected leaf node
            path: Path from root to leaf
        """
        node = self.root
        path = [node]
        
        # Create temporary environment for simulation
        temp_env = env.clone()
        
        while not node.is_leaf():
            # Select child with highest UCB score
            best_score = -float('inf')
            best_child = None
            
            for action, child in node.children.items():
                score = self._puct_score(node, child)
                if score > best_score:
                    best_score = score
                    best_child = child
                    best_action = action
            
            if best_child is None:
                break
            
            # Make move in temporary environment
            row, col = best_action
            temp_env.step(best_action)
            
            node = best_child
            path.append(node)
        
        return node, path
    
    def _puct_score(self, parent: MCTSNode, child: MCTSNode) -> float:
        """Calculate PUCT score for a child node"""
        q_value = child.get_q_value()
        
        # Get prior probability
        prior = child.prior_probs.get(child.action, 0.01)
        
        # UCB exploration term
        ucb = self.c_puct * prior * math.sqrt(parent.visit_count) / (1 + child.visit_count)
        
        # Add virtual loss penalty
        virtual_loss_term = self.virtual_loss_weight * child.virtual_loss / (1 + child.visit_count)
        
        return q_value + ucb - virtual_loss_term
    
    def _expand_node(self, node: MCTSNode):
        """Expand node by evaluating with neural network"""
        # Convert state to tensor
        state_tensor = torch.FloatTensor(node.state).unsqueeze(0).to(self.device)
        
        # Get policy and value from network
        with torch.no_grad():
            policy_logits, value = self.network(state_tensor)
        
        # Convert to numpy
        policy_probs = torch.softmax(policy_logits, dim=1).cpu().numpy()[0]
        value_scalar = value.item()
        
        # Store value
        node.value_sum = value_scalar
        node.mean_value = value_scalar
        
        # Note: Actual expansion happens when children are added during selection
        # Here we just store the policy for later use
        node.policy_probs_flat = policy_probs
    
    def _add_dirichlet_noise(self, node: MCTSNode, env: GomokuEnv):
        """Add Dirichlet noise to root node priors for exploration"""
        legal_moves = env.get_legal_moves()
        if not legal_moves:
            return
        
        # Generate Dirichlet noise
        noise = np.random.dirichlet([self.dirichlet_alpha] * len(legal_moves))
        
        # Mix with original priors
        for i, action in enumerate(legal_moves):
            if hasattr(node, 'policy_probs_flat'):
                idx = action[0] * env.board_size + action[1]
                original_prior = node.policy_probs_flat[idx]
            else:
                original_prior = 1.0 / len(legal_moves)
            
            # Epsilon-greedy mixing
            node.prior_probs[action] = (1 - self.dirichlet_epsilon) * original_prior + \
                                       self.dirichlet_epsilon * noise[i]
    
    def _backpropagate(self, path: List[MCTSNode], value: float):
        """Backpropagate value through the search path"""
        for node in reversed(path):
            # Flip value for opponent
            node.update(-value)
            value = -value
    
    def _select_move(self, env: GomokuEnv, temperature: float = 1.0) -> Tuple[Tuple[int, int], List[float]]:
        """
        Select move based on visit counts with temperature
        
        Args:
            env: Current game environment
            temperature: Temperature parameter (higher = more exploration)
            
        Returns:
            selected_action: Chosen action
            visit_counts: Visit count distribution
        """
        legal_moves = env.get_legal_moves()
        if not legal_moves:
            raise ValueError("No legal moves available")
        
        # Get visit counts for legal moves
        visit_counts = np.zeros(len(legal_moves))
        for i, action in enumerate(legal_moves):
            if action in self.root.children:
                visit_counts[i] = self.root.children[action].visit_count
        
        # Apply temperature
        if temperature > 0:
            # Raise to power of 1/temperature
            visit_counts_temp = np.power(visit_counts, 1.0 / temperature)
            
            # Normalize to probabilities
            if visit_counts_temp.sum() > 0:
                probs = visit_counts_temp / visit_counts_temp.sum()
            else:
                # Uniform if no visits
                probs = np.ones(len(legal_moves)) / len(legal_moves)
            
            # Sample action
            idx = np.random.choice(len(legal_moves), p=probs)
        else:
            # Greedy selection (temperature = 0)
            idx = np.argmax(visit_counts)
        
        selected_action = legal_moves[idx]
        return selected_action, visit_counts.tolist()
    
    def update_root(self, action: Tuple[int, int]):
        """Update root to chosen child node (for reuse in next turn)"""
        if action in self.root.children:
            self.root = self.root.children[action]
            self.root.parent = None
        else:
            # Reset if action not in tree
            self.root = None
    
    def get_temperature(self, move_number: int) -> float:
        """Calculate temperature based on move number"""
        if move_number < self.temperature_decay_steps:
            return self.temperature_init
        else:
            return 0.1  # Low temperature for exploitation
