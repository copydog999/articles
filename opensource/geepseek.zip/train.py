"""
GeepSeek - Lightweight Self-Play Reinforcement Learning for Gomoku
Main training script

Based on AlphaZero architecture with:
- Dual-head CNN (policy + value)
- Monte Carlo Tree Search
- Priority Experience Replay
- Data Augmentation via symmetries
"""
import yaml
import argparse
import os
from datetime import datetime

from training.trainer import SelfPlayTrainer
from utils.evaluator import Evaluator


def load_config(config_path: str = 'config.yaml') -> dict:
    """Load configuration from YAML file"""
    with open(config_path, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)
    return config


def train(config: dict):
    """
    Main training loop
    
    Process:
    1. Generate self-play data
    2. Train network on collected data
    3. Evaluate performance
    4. Repeat until convergence
    """
    print("=" * 80)
    print("GeepSeek - Lightweight Self-Play RL for Gomoku")
    print("=" * 80)
    print(f"\nConfiguration:")
    print(f"  Board Size: {config['game']['board_size']}x{config['game']['board_size']}")
    print(f"  Network Filters: {config['network']['num_filters']}")
    print(f"  Residual Blocks: {config['network']['num_residual_blocks']}")
    print(f"  MCTS Simulations: {config['mcts']['num_simulations']}")
    print(f"  Batch Size: {config['training']['batch_size']}")
    print(f"  Total Self-Play Games: {config['training']['num_self_play_games']}")
    print()
    
    # Create trainer
    trainer = SelfPlayTrainer(config)
    
    # Optional: Load checkpoint
    if args.checkpoint:
        trainer.load_checkpoint(args.checkpoint)
    
    # Training parameters
    total_games = config['training']['num_self_play_games']
    games_per_iteration = config['training']['update_model_every']
    eval_every = config['evaluation']['eval_every']
    num_self_play_games_per_iter = 100  # Games per iteration
    num_training_epochs = 5  # Epochs per training phase
    
    iterations = total_games // games_per_iteration
    
    print(f"Training Plan:")
    print(f"  Total Iterations: {iterations}")
    print(f"  Games per Iteration: {games_per_iteration}")
    print(f"  Evaluation Frequency: Every {eval_every} games")
    print()
    
    start_time = datetime.now()
    
    for iteration in range(1, iterations + 1):
        print(f"\n{'='*80}")
        print(f"Iteration {iteration}/{iterations}")
        print(f"{'='*80}")
        
        # Phase 1: Self-Play Data Generation
        print("\n[Phase 1] Self-Play Data Generation")
        trainer.generate_training_data(num_games=num_self_play_games_per_iter)
        
        # Phase 2: Network Training
        print("\n[Phase 2] Network Training")
        trainer.train_network(num_epochs=num_training_epochs)
        
        # Log statistics
        stats = trainer.get_statistics()
        print(f"\nStatistics:")
        print(f"  Games Played: {stats['games_played']}")
        print(f"  Win Rate (Black): {stats['win_rate_black']:.2%}")
        print(f"  Win Rate (White): {stats['win_rate_white']:.2%}")
        print(f"  Buffer Size: {stats['buffer_size']}")
        
        # Save checkpoint
        if iteration % config['logging']['save_every'] == 0:
            trainer.save_checkpoint()
        
        # Phase 3: Evaluation
        if iteration % (eval_every // games_per_iteration) == 0:
            print("\n[Phase 3] Evaluation")
            evaluator = Evaluator(trainer.network, config)
            eval_results = evaluator.evaluate_vs_alphabeta(
                num_games=config['evaluation']['num_eval_games']
            )
            
            # Log evaluation results
            trainer.writer.add_scalar('Evaluation/WinRate', 
                                     eval_results['win_rate'], 
                                     trainer.global_step)
            trainer.writer.add_scalar('Evaluation/Elo', 
                                     eval_results['elo_rating'], 
                                     trainer.global_step)
        
        # Calculate elapsed time
        elapsed = datetime.now() - start_time
        print(f"\nElapsed Time: {elapsed}")
    
    # Final evaluation
    print("\n" + "=" * 80)
    print("Training Complete - Final Evaluation")
    print("=" * 80)
    
    evaluator = Evaluator(trainer.network, config)
    final_results = evaluator.evaluate_vs_alphabeta(num_games=200)
    
    # Save final model
    trainer.save_checkpoint("final_model.pth")
    
    print("\n" + "=" * 80)
    print("Final Results:")
    print(f"  Win Rate vs Alpha-Beta: {final_results['win_rate']:.2%}")
    print(f"  Estimated Elo: {final_results['elo_rating']:.0f}")
    print(f"  Total Training Time: {datetime.now() - start_time}")
    print("=" * 80)


def main():
    parser = argparse.ArgumentParser(description='GeepSeek Training')
    parser.add_argument('--config', type=str, default='config.yaml',
                       help='Path to configuration file')
    parser.add_argument('--checkpoint', type=str, default=None,
                       help='Path to checkpoint to resume training')
    parser.add_argument('--mode', type=str, default='train',
                       choices=['train', 'evaluate'],
                       help='Mode: train or evaluate')
    
    global args
    args = parser.parse_args()
    
    # Load configuration
    config = load_config(args.config)
    
    if args.mode == 'train':
        train(config)
    elif args.mode == 'evaluate':
        # Evaluation mode
        from models.network import GomokuNetwork
        import torch
        
        network = GomokuNetwork(
            board_size=config['game']['board_size'],
            num_filters=config['network']['num_filters'],
            num_residual_blocks=config['network']['num_residual_blocks']
        )
        
        # Load model
        checkpoint = torch.load(args.checkpoint, map_location='cpu')
        network.load_state_dict(checkpoint['network_state_dict'])
        
        # Evaluate
        evaluator = Evaluator(network, config)
        results = evaluator.evaluate_vs_alphabeta(num_games=100)
        
        print(f"\nEvaluation Results:")
        print(f"  Win Rate: {results['win_rate']:.2%}")
        print(f"  Elo Rating: {results['elo_rating']:.0f}")


if __name__ == '__main__':
    main()
