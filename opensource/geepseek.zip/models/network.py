"""
Dual-head CNN Network for Gomoku
Architecture: 4 residual blocks with policy and value heads
Total parameters: ~400K (8% of AlphaZero)
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple


class ResidualBlock(nn.Module):
    """Residual block with batch normalization and ReLU"""
    
    def __init__(self, num_filters: int = 64):
        super().__init__()
        self.conv1 = nn.Conv2d(num_filters, num_filters, kernel_size=3, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(num_filters)
        self.conv2 = nn.Conv2d(num_filters, num_filters, kernel_size=3, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(num_filters)
    
    def forward(self, x):
        identity = x
        
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out += identity
        out = F.relu(out)
        
        return out


class GomokuNetwork(nn.Module):
    """
    Dual-head CNN for Gomoku
    
    Architecture:
    - Input: 3 channels (black, white, current player)
    - Backbone: Conv + 4 Residual Blocks
    - Policy Head: outputs move probabilities (15x15 = 225 actions)
    - Value Head: outputs position evaluation (-1 to 1)
    """
    
    def __init__(self, board_size: int = 15, num_filters: int = 64, 
                 num_residual_blocks: int = 4):
        super().__init__()
        
        self.board_size = board_size
        
        # Initial convolution layer
        self.conv_input = nn.Conv2d(3, num_filters, kernel_size=3, padding=1, bias=False)
        self.bn_input = nn.BatchNorm2d(num_filters)
        
        # Residual tower
        self.residual_blocks = nn.Sequential(*[
            ResidualBlock(num_filters) for _ in range(num_residual_blocks)
        ])
        
        # Policy head
        self.policy_conv = nn.Conv2d(num_filters, 2, kernel_size=1, bias=False)
        self.policy_bn = nn.BatchNorm2d(2)
        self.policy_fc = nn.Linear(2 * board_size * board_size, board_size * board_size)
        
        # Value head
        self.value_conv = nn.Conv2d(num_filters, 1, kernel_size=1, bias=False)
        self.value_bn = nn.BatchNorm2d(1)
        self.value_fc1 = nn.Linear(board_size * board_size, 64)
        self.value_fc2 = nn.Linear(64, 1)
        
        # Initialize weights
        self._initialize_weights()
    
    def _initialize_weights(self):
        """Initialize network weights"""
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
    
    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass
        
        Args:
            x: Input tensor of shape (batch_size, 3, board_size, board_size)
            
        Returns:
            policy_logits: Raw logits for all moves (batch_size, board_size^2)
            value: Position evaluation (batch_size, 1)
        """
        # Backbone
        x = F.relu(self.bn_input(self.conv_input(x)))
        x = self.residual_blocks(x)
        
        # Policy head
        policy = F.relu(self.policy_bn(self.policy_conv(x)))
        policy = policy.view(policy.size(0), -1)
        policy_logits = self.policy_fc(policy)
        
        # Value head
        value = F.relu(self.value_bn(self.value_conv(x)))
        value = value.view(value.size(0), -1)
        value = F.relu(self.value_fc1(value))
        value = torch.tanh(self.value_fc2(value))
        
        return policy_logits, value
    
    def get_num_parameters(self) -> int:
        """Get total number of trainable parameters"""
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


def create_network(board_size: int = 15, num_filters: int = 64, 
                   num_residual_blocks: int = 4) -> GomokuNetwork:
    """Factory function to create Gomoku network"""
    net = GomokuNetwork(board_size, num_filters, num_residual_blocks)
    print(f"Network created with {net.get_num_parameters():,} parameters")
    return net


if __name__ == "__main__":
    # Test the network
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    net = create_network().to(device)
    
    # Test forward pass
    batch_size = 4
    dummy_input = torch.randn(batch_size, 3, 15, 15).to(device)
    policy_logits, value = net(dummy_input)
    
    print(f"Policy logits shape: {policy_logits.shape}")  # Should be (4, 225)
    print(f"Value shape: {value.shape}")  # Should be (4, 1)
    print(f"Value range: [{value.min():.3f}, {value.max():.3f}]")
