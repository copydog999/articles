"""
Quick test script to verify GeepSeek components
"""
import sys
import torch
import numpy as np


def test_game_environment():
    """Test Gomoku game environment"""
    print("Testing Game Environment...")
    from game.gomoku import GomokuEnv
    
    env = GomokuEnv()
    state = env.reset()
    
    assert state.shape == (3, 15, 15), f"State shape incorrect: {state.shape}"
    assert env.current_player == GomokuEnv.BLACK
    
    # Test moves
    legal_moves = env.get_legal_moves()
    assert len(legal_moves) > 0, "No legal moves available"
    
    # Make a move
    action = legal_moves[0]
    next_state, reward, done = env.step(action)
    
    assert next_state.shape == (3, 15, 15)
    assert not done
    assert env.board[action[0], action[1]] == GomokuEnv.BLACK
    
    print("✓ Game environment works correctly\n")


def test_network():
    """Test neural network architecture"""
    print("Testing Neural Network...")
    from models.network import GomokuNetwork
    
    net = GomokuNetwork(board_size=15, num_filters=64, num_residual_blocks=4)
    
    # Check parameter count (~400K target)
    num_params = net.get_num_parameters()
    print(f"  Network parameters: {num_params:,}")
    assert 300000 <= num_params <= 500000, f"Parameter count out of range: {num_params}"
    
    # Test forward pass
    batch_size = 4
    dummy_input = torch.randn(batch_size, 3, 15, 15)
    policy_logits, value = net(dummy_input)
    
    assert policy_logits.shape == (batch_size, 225), f"Policy shape incorrect: {policy_logits.shape}"
    assert value.shape == (batch_size, 1), f"Value shape incorrect: {value.shape}"
    assert -1 <= value.min() and value.max() <= 1, "Value out of range [-1, 1]"
    
    print("✓ Neural network works correctly\n")


def test_mcts():
    """Test MCTS search"""
    print("Testing MCTS...")
    from game.gomoku import GomokuEnv
    from models.network import GomokuNetwork
    from mcts.search import MCTS
    
    # Create network and MCTS
    net = GomokuNetwork()
    config = {
        'num_simulations': 100,  # Reduced for testing
        'c_puct': 1.5,
        'dirichlet_alpha': 0.3,
        'dirichlet_epsilon': 0.25,
        'temperature_init': 1.0,
        'temperature_decay_steps': 10,
        'virtual_loss_weight': 3
    }
    mcts = MCTS(net, config)
    
    # Test search
    env = GomokuEnv()
    env.reset()
    
    action, visit_counts = mcts.search(env, temperature=1.0)
    
    assert isinstance(action, tuple) and len(action) == 2, "Invalid action format"
    assert len(visit_counts) > 0, "No visit counts returned"
    
    print(f"  Selected action: {action}")
    print(f"  Visit counts: {len(visit_counts)} moves")
    print("✓ MCTS works correctly\n")


def test_data_augmentation():
    """Test data augmentation"""
    print("Testing Data Augmentation...")
    from utils.augmentation import DataAugmentation
    
    # Create sample state
    state = np.random.rand(3, 15, 15).astype(np.float32)
    policy = np.random.rand(225).astype(np.float32)
    policy /= policy.sum()
    value = 0.5
    
    # Test augmentation
    augmented = DataAugmentation.augment_sample(state, policy, value)
    
    assert len(augmented) == 8, f"Expected 8 augmentations, got {len(augmented)}"
    
    for aug_state, aug_policy, aug_value in augmented:
        assert aug_state.shape == state.shape
        assert aug_policy.shape == policy.shape
        assert abs(aug_value - value) < 1e-6
    
    print("✓ Data augmentation works correctly\n")


def test_replay_buffer():
    """Test priority experience replay"""
    print("Testing Replay Buffer...")
    from training.replay_buffer import PrioritizedReplayBuffer
    
    buffer = PrioritizedReplayBuffer(capacity=1000, alpha=0.6, beta=0.4)
    
    # Add samples
    for i in range(10):
        state = np.random.rand(3, 15, 15).astype(np.float32)
        policy = np.random.rand(225).astype(np.float32)
        policy /= policy.sum()
        value = np.random.rand()
        
        buffer.add(state, policy, value, augment=False)
    
    assert len(buffer) == 10, f"Buffer size incorrect: {len(buffer)}"
    
    # Sample batch
    indices, states, policies, values, weights = buffer.sample(batch_size=5)
    
    assert len(indices) == 5
    assert len(states) == 5
    assert len(weights) == 5
    
    print("✓ Replay buffer works correctly\n")


def test_alphabeta_bot():
    """Test Alpha-Beta bot"""
    print("Testing Alpha-Beta Bot...")
    from game.gomoku import GomokuEnv
    from utils.alphabeta_bot import AlphaBetaBot
    
    bot = AlphaBetaBot(depth=2)  # Shallow depth for fast testing
    env = GomokuEnv()
    env.reset()
    
    action = bot.get_move(env)
    
    assert isinstance(action, tuple) and len(action) == 2
    assert 0 <= action[0] < 15 and 0 <= action[1] < 15
    
    print(f"  Bot selected action: {action}")
    print("✓ Alpha-Beta bot works correctly\n")


def test_full_integration():
    """Test full integration with short self-play game"""
    print("Testing Full Integration (short game)...")
    from game.gomoku import GomokuEnv
    from models.network import GomokuNetwork
    from mcts.search import MCTS
    
    # Create components
    net = GomokuNetwork()
    config = {
        'num_simulations': 50,  # Very reduced for speed
        'c_puct': 1.5,
        'dirichlet_alpha': 0.3,
        'dirichlet_epsilon': 0.25,
        'temperature_init': 1.0,
        'temperature_decay_steps': 10,
        'virtual_loss_weight': 3
    }
    mcts = MCTS(net, config)
    
    # Play short game
    env = GomokuEnv()
    env.reset()
    
    move_count = 0
    max_moves = 10  # Limit for testing
    
    while not env.done and move_count < max_moves:
        action, _ = mcts.search(env, temperature=1.0)
        env.step(action)
        move_count += 1
        
        if move_count % 3 == 0:
            print(f"  Move {move_count}: ({action[0]}, {action[1]})")
    
    print(f"  Game finished after {move_count} moves")
    print("✓ Full integration works correctly\n")


def main():
    print("=" * 80)
    print("GeepSeek Component Tests")
    print("=" * 80)
    print()
    
    try:
        test_game_environment()
        test_network()
        test_mcts()
        test_data_augmentation()
        test_replay_buffer()
        test_alphabeta_bot()
        test_full_integration()
        
        print("=" * 80)
        print("All tests passed! ✓")
        print("=" * 80)
        return 0
        
    except Exception as e:
        print(f"\n{'='*80}")
        print(f"Test failed with error: {e}")
        print("=" * 80)
        import traceback
        traceback.print_exc()
        return 1


if __name__ == '__main__':
    sys.exit(main())
