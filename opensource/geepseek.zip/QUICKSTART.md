# GeepSeek 快速启动指南

## 1. 环境准备

### Windows PowerShell

```powershell
# 创建虚拟环境
python -m venv geepseek_env
.\geepseek_env\Scripts\Activate.ps1

# 安装依赖
pip install -r requirements.txt
```

## 2. 验证安装

运行测试确保所有组件正常：

```powershell
python test_components.py
```

应看到：
```
All tests passed! ✓
```

## 3. 开始训练

### 基础训练（推荐新手）

使用默认配置开始完整训练（约48小时）：

```powershell
python train.py
```

### 快速测试训练

修改 `config.yaml` 进行快速测试：

```yaml
training:
  num_self_play_games: 1000  # 减少到1000局
  update_model_every: 50
  
mcts:
  num_simulations: 200  # 减少模拟次数
```

然后运行：

```powershell
python train.py
```

### 从检查点恢复

如果训练中断，从最新检查点恢复：

```powershell
python train.py --checkpoint checkpoints/checkpoint_1000.pth
```

## 4. 监控训练

在新终端中运行TensorBoard：

```powershell
tensorboard --logdir logs
```

浏览器访问：http://localhost:6006

关键指标：
- **Loss/Total**: 应在1.5-2.5之间波动下降
- **Evaluation/WinRate**: 应逐渐上升至70%+
- **Evaluation/Elo**: 目标1800+

## 5. 评估模型

训练完成后评估性能：

```powershell
python train.py --mode evaluate --checkpoint checkpoints/final_model.pth
```

预期结果：
- 胜率: ~78%
- Elo: ~1825

## 6. 人机对战

与训练好的AI对弈：

```powershell
# 使用最终模型
python play.py checkpoints/final_model.pth

# 或使用未训练模型（随机落子）
python play.py
```

操作说明：
- 输入格式：`行 列`（如 `7 7` 表示中心）
- 输入 `quit` 退出游戏

## 7. AI表演赛

观看两个AI互相对战：

```powershell
python play.py watch
```

## 常见问题排查

### 问题1: CUDA内存不足

**症状**: `RuntimeError: CUDA out of memory`

**解决**: 减小batch_size和network规模

```yaml
# config.yaml
training:
  batch_size: 128  # 从256降到128
  
network:
  num_filters: 32  # 从64降到32
```

### 问题2: 训练太慢

**症状**: 每小时少于10局

**解决**: 减少MCTS模拟次数

```yaml
# config.yaml
mcts:
  num_simulations: 400  # 从800降到400
```

### 问题3: 胜率不提升

**症状**: 训练1000局后胜率仍低于40%

**检查清单**:
1. 学习率是否过高？尝试降低到0.001
2. MCTS探索是否充分？增加c_puct到2.0
3. 数据增强是否启用？确认augmentation.enabled=true

```yaml
# config.yaml
training:
  learning_rate: 0.001  # 降低学习率
  
mcts:
  c_puct: 2.0           # 增加探索
  
augmentation:
  enabled: true         # 确保启用
```

### 问题4: 导入错误

**症状**: `ModuleNotFoundError`

**解决**: 确保在项目根目录运行

```powershell
cd D:\experiments\geepseek
python train.py
```

## 训练时间估算

| 配置 | GPU | 预计时间 |
|------|-----|---------|
| 默认 (800模拟) | RTX 3080 | 48小时 |
| 默认 (800模拟) | RTX 4090 | 30小时 |
| 快速 (400模拟) | RTX 3080 | 24小时 |
| 快速 (400模拟) | RTX 4090 | 15小时 |

## 下一步

训练完成后，可以：

1. **分析模型**: 使用Grad-CAM可视化决策
2. **改进算法**: 实现Idea大纲中的改进方向
3. **扩展应用**: 适配其他棋类游戏
4. **部署服务**: 构建Web对战平台

祝训练顺利！
