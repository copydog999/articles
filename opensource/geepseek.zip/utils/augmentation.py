"""
Data Augmentation for Gomoku
Implements 8 symmetry transformations (rotations and reflections)
"""
import numpy as np
from typing import List, Tuple


class DataAugmentation:
    """
    Apply symmetry transformations to board states and action indices
    
    The 8 symmetries of a square:
    - Identity
    - Rotate 90, 180, 270 degrees
    - Reflect horizontally, vertically, and two diagonals
    """
    
    @staticmethod
    def get_symmetries() -> List[str]:
        """Get list of all symmetry transformation names"""
        return [
            'identity',
            'rotate_90',
            'rotate_180',
            'rotate_270',
            'reflect_horizontal',
            'reflect_vertical',
            'reflect_diagonal_main',
            'reflect_diagonal_anti'
        ]
    
    @staticmethod
    def transform_state(state: np.ndarray, symmetry: str) -> np.ndarray:
        """
        Apply symmetry transformation to board state
        
        Args:
            state: Board state tensor (3, board_size, board_size)
            symmetry: Transformation name
            
        Returns:
            Transformed state
        """
        if symmetry == 'identity':
            return state.copy()
        elif symmetry == 'rotate_90':
            return np.rot90(state, k=1, axes=(1, 2))
        elif symmetry == 'rotate_180':
            return np.rot90(state, k=2, axes=(1, 2))
        elif symmetry == 'rotate_270':
            return np.rot90(state, k=3, axes=(1, 2))
        elif symmetry == 'reflect_horizontal':
            return state[:, ::-1, :].copy()
        elif symmetry == 'reflect_vertical':
            return state[:, :, ::-1].copy()
        elif symmetry == 'reflect_diagonal_main':
            return np.transpose(state, (0, 2, 1)).copy()
        elif symmetry == 'reflect_diagonal_anti':
            return np.rot90(np.transpose(state, (0, 2, 1)), k=2, axes=(1, 2))
        else:
            raise ValueError(f"Unknown symmetry: {symmetry}")
    
    @staticmethod
    def transform_action(action: Tuple[int, int], symmetry: str, 
                        board_size: int = 15) -> Tuple[int, int]:
        """
        Apply symmetry transformation to action index
        
        Args:
            action: (row, col) tuple
            symmetry: Transformation name
            board_size: Size of the board
            
        Returns:
            Transformed action
        """
        row, col = action
        
        if symmetry == 'identity':
            return (row, col)
        elif symmetry == 'rotate_90':
            return (col, board_size - 1 - row)
        elif symmetry == 'rotate_180':
            return (board_size - 1 - row, board_size - 1 - col)
        elif symmetry == 'rotate_270':
            return (board_size - 1 - col, row)
        elif symmetry == 'reflect_horizontal':
            return (board_size - 1 - row, col)
        elif symmetry == 'reflect_vertical':
            return (row, board_size - 1 - col)
        elif symmetry == 'reflect_diagonal_main':
            return (col, row)
        elif symmetry == 'reflect_diagonal_anti':
            return (board_size - 1 - col, board_size - 1 - row)
        else:
            raise ValueError(f"Unknown symmetry: {symmetry}")
    
    @staticmethod
    def action_to_index(action: Tuple[int, int], board_size: int = 15) -> int:
        """Convert (row, col) action to flat index"""
        return action[0] * board_size + action[1]
    
    @staticmethod
    def index_to_action(index: int, board_size: int = 15) -> Tuple[int, int]:
        """Convert flat index to (row, col) action"""
        return (index // board_size, index % board_size)
    
    @staticmethod
    def augment_sample(state: np.ndarray, policy: np.ndarray, value: float,
                      board_size: int = 15) -> List[Tuple[np.ndarray, np.ndarray, float]]:
        """
        Generate all 8 augmented versions of a training sample
        
        Args:
            state: Board state (3, board_size, board_size)
            policy: Policy vector (board_size^2,)
            value: Value scalar
            
        Returns:
            List of (transformed_state, transformed_policy, value) tuples
        """
        augmented_samples = []
        symmetries = DataAugmentation.get_symmetries()
        
        for symmetry in symmetries:
            # Transform state
            transformed_state = DataAugmentation.transform_state(state, symmetry)
            
            # Transform policy
            transformed_policy = np.zeros_like(policy)
            for idx in range(len(policy)):
                action = DataAugmentation.index_to_action(idx, board_size)
                transformed_action = DataAugmentation.transform_action(
                    action, symmetry, board_size
                )
                transformed_idx = DataAugmentation.action_to_index(
                    transformed_action, board_size
                )
                transformed_policy[transformed_idx] = policy[idx]
            
            # Value remains unchanged (symmetric)
            augmented_samples.append((transformed_state, transformed_policy, value))
        
        return augmented_samples
