"""
Alpha-Beta Pruning Bot for Gomoku
Traditional search-based opponent for evaluation
"""
import numpy as np
from typing import Tuple, Optional, List
from game.gomoku import GomokuEnv


class AlphaBetaBot:
    """
    Gomoku bot using Alpha-Beta pruning with heuristic evaluation
    
    Features:
    - Depth-limited minimax search
    - Alpha-beta pruning for efficiency
    - Pattern-based evaluation function
    """
    
    def __init__(self, depth: int = 4):
        """
        Args:
            depth: Search depth (higher = stronger but slower)
        """
        self.depth = depth
        self.nodes_evaluated = 0
    
    def get_move(self, env: GomokuEnv) -> Tuple[int, int]:
        """
        Get best move using alpha-beta search
        
        Args:
            env: Current game environment
            
        Returns:
            Best move (row, col)
        """
        self.nodes_evaluated = 0
        legal_moves = env.get_legal_moves()
        
        if not legal_moves:
            raise ValueError("No legal moves available")
        
        # For first move, play center
        if len(legal_moves) == 1:
            return legal_moves[0]
        
        best_score = -float('inf')
        best_move = legal_moves[0]
        alpha = -float('inf')
        beta = float('inf')
        
        # Sort moves by heuristic to improve pruning
        sorted_moves = self._order_moves(env, legal_moves)
        
        for move in sorted_moves[:20]:  # Limit branching factor
            # Make move
            env_copy = env.clone()
            env_copy.step(move)
            
            # Evaluate
            score = -self._alphabeta(env_copy, self.depth - 1, -beta, -alpha)
            
            if score > best_score:
                best_score = score
                best_move = move
            
            alpha = max(alpha, score)
        
        return best_move
    
    def _alphabeta(self, env: GomokuEnv, depth: int, 
                   alpha: float, beta: float) -> float:
        """
        Alpha-beta search
        
        Returns:
            Position evaluation score
        """
        self.nodes_evaluated += 1
        
        # Terminal state or depth limit
        if env.done or depth == 0:
            return self._evaluate(env)
        
        legal_moves = env.get_legal_moves()
        if not legal_moves:
            return 0.0
        
        # Order moves for better pruning
        sorted_moves = self._order_moves(env, legal_moves)
        
        max_score = -float('inf')
        
        for move in sorted_moves[:15]:  # Limit branching
            env_copy = env.clone()
            env_copy.step(move)
            
            score = -self._alphabeta(env_copy, depth - 1, -beta, -alpha)
            max_score = max(max_score, score)
            
            alpha = max(alpha, score)
            if alpha >= beta:
                break  # Beta cutoff
        
        return max_score
    
    def _order_moves(self, env: GomokuEnv, moves: List[Tuple[int, int]]) -> List[Tuple[int, int]]:
        """Order moves by proximity to existing stones for better pruning"""
        if len(env.move_history) == 0:
            return moves
        
        # Calculate average position of all stones
        positions = np.array(env.move_history)
        center = positions.mean(axis=0)
        
        # Sort by distance to center of action
        def distance_to_center(move):
            return np.sqrt((move[0] - center[0])**2 + (move[1] - center[1])**2)
        
        return sorted(moves, key=distance_to_center)
    
    def _evaluate(self, env: GomokuEnv) -> float:
        """
        Heuristic evaluation function
        
        Evaluates board position based on patterns:
        - Five in a row (win)
        - Open four
        - Closed four
        - Open three
        - etc.
        
        Returns:
            Score from perspective of current player
        """
        if env.done:
            if env.winner == env.current_player:
                return 100000  # Win
            elif env.winner is None:
                return 0  # Draw
            else:
                return -100000  # Loss
        
        score = 0
        
        # Evaluate for both players
        for player in [GomokuEnv.BLACK, GomokuEnv.WHITE]:
            player_score = self._evaluate_patterns(env, player)
            
            if player == env.current_player:
                score += player_score
            else:
                score -= player_score
        
        return score
    
    def _evaluate_patterns(self, env: GomokuEnv, player: int) -> float:
        """Evaluate board based on pattern matching"""
        score = 0
        board = env.board
        
        directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
        
        for i in range(env.board_size):
            for j in range(env.board_size):
                if board[i, j] != player:
                    continue
                
                for dr, dc in directions:
                    # Count consecutive stones
                    count = 0
                    open_ends = 0
                    
                    r, c = i, j
                    while 0 <= r < env.board_size and 0 <= c < env.board_size:
                        if board[r, c] == player:
                            count += 1
                            r += dr
                            c += dc
                        else:
                            if board[r, c] == GomokuEnv.EMPTY:
                                open_ends += 1
                            break
                    
                    # Check backward
                    r, c = i - dr, j - dc
                    while 0 <= r < env.board_size and 0 <= c < env.board_size:
                        if board[r, c] == player:
                            count += 1
                            r -= dr
                            c -= dc
                        else:
                            if board[r, c] == GomokuEnv.EMPTY:
                                open_ends += 1
                            break
                    
                    # Score patterns
                    if count >= 5:
                        score += 100000
                    elif count == 4:
                        if open_ends == 2:
                            score += 10000  # Open four
                        elif open_ends == 1:
                            score += 1000   # Closed four
                    elif count == 3:
                        if open_ends == 2:
                            score += 1000   # Open three
                        elif open_ends == 1:
                            score += 100    # Closed three
                    elif count == 2:
                        if open_ends == 2:
                            score += 100    # Open two
                        elif open_ends == 1:
                            score += 10     # Closed two
        
        return score
