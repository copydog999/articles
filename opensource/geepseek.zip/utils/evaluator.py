"""
Evaluation Module for GeepSeek
Implements Elo rating calculation and bot comparison
"""
import numpy as np
from typing import List, Tuple, Dict
from game.gomoku import GomokuEnv
from mcts.search import MCTS
from utils.alphabeta_bot import AlphaBetaBot


class Evaluator:
    """
    Evaluate trained model against baseline opponents
    
    Metrics:
    - Win rate vs Alpha-Beta bot
    - Elo rating estimation
    - Performance across different game phases
    """
    
    def __init__(self, network, config: dict):
        self.network = network
        self.config = config
        
        # Create MCTS agent using trained network
        self.mcts_agent = MCTS(network, config['mcts'])
        
        # Create baseline opponent
        self.alphabeta_bot = AlphaBetaBot(depth=4)
    
    def evaluate_vs_alphabeta(self, num_games: int = 100) -> Dict:
        """
        Evaluate model against Alpha-Beta bot
        
        Args:
            num_games: Number of evaluation games
            
        Returns:
            Dictionary with evaluation results
        """
        print(f"\nEvaluating vs Alpha-Beta bot ({num_games} games)...")
        
        wins = 0
        losses = 0
        draws = 0
        
        for game_idx in range(num_games):
            env = GomokuEnv(
                board_size=self.config['game']['board_size'],
                win_length=self.config['game']['win_length']
            )
            
            # Alternate who plays first
            if game_idx % 2 == 0:
                # Model plays as Black (first)
                result = self._play_game(env, model_is_black=True)
            else:
                # Model plays as White (second)
                result = self._play_game(env, model_is_black=False)
            
            if result == 1:
                wins += 1
            elif result == -1:
                losses += 1
            else:
                draws += 1
            
            if (game_idx + 1) % 10 == 0:
                print(f"  Games: {game_idx + 1}/{num_games}, "
                      f"Wins: {wins}, Losses: {losses}, Draws: {draws}")
        
        win_rate = wins / num_games
        elo = self._calculate_elo(win_rate, num_games)
        
        results = {
            'wins': wins,
            'losses': losses,
            'draws': draws,
            'win_rate': win_rate,
            'elo_rating': elo,
            'total_games': num_games
        }
        
        print(f"\nResults:")
        print(f"  Win Rate: {win_rate:.2%}")
        print(f"  Estimated Elo: {elo:.0f}")
        
        return results
    
    def _play_game(self, env: GomokuEnv, model_is_black: bool = True) -> int:
        """
        Play one complete game
        
        Args:
            env: Game environment
            model_is_black: Whether model plays as black (first)
            
        Returns:
            Result from model's perspective: 1 (win), -1 (loss), 0 (draw)
        """
        move_number = 0
        
        while not env.done:
            is_model_turn = (env.current_player == GomokuEnv.BLACK) == model_is_black
            
            if is_model_turn:
                # Model's turn - use MCTS
                temperature = self.mcts_agent.get_temperature(move_number)
                action, _ = self.mcts_agent.search(env, temperature=temperature, 
                                                   add_dirichlet=False)
            else:
                # Opponent's turn - use Alpha-Beta
                action = self.alphabeta_bot.get_move(env)
            
            env.step(action)
            move_number += 1
        
        # Determine result from model's perspective
        if env.winner is None:
            return 0  # Draw
        
        model_color = GomokuEnv.BLACK if model_is_black else GomokuEnv.WHITE
        if env.winner == model_color:
            return 1  # Win
        else:
            return -1  # Loss
    
    def _calculate_elo(self, win_rate: float, num_games: int, 
                       base_elo: int = 1500) -> float:
        """
        Calculate Elo rating based on win rate against known opponent
        
        Assumes opponent has Elo of ~1500 (decent amateur level)
        
        Args:
            win_rate: Win rate (0 to 1)
            num_games: Number of games played
            base_elo: Assumed Elo of opponent
            
        Returns:
            Estimated Elo rating
        """
        if win_rate <= 0:
            return base_elo - 400
        elif win_rate >= 1:
            return base_elo + 400
        
        # Elo formula: expected_score = 1 / (1 + 10^((opponent_elo - player_elo) / 400))
        # Solving for player_elo:
        # player_elo = opponent_elo - 400 * log10(1/win_rate - 1)
        
        import math
        elo_diff = -400 * math.log10(1.0 / win_rate - 1)
        estimated_elo = base_elo + elo_diff
        
        return estimated_elo
    
    def analyze_depth_performance(self) -> Dict:
        """
        Analyze model performance on positions requiring different search depths
        
        Returns:
            Dictionary with performance metrics by depth category
        """
        # This would require a dataset of labeled positions
        # For now, return placeholder
        return {
            'shallow (<6 moves)': {'accuracy': 0.0, 'samples': 0},
            'medium (6-12 moves)': {'accuracy': 0.0, 'samples': 0},
            'deep (>12 moves)': {'accuracy': 0.0, 'samples': 0}
        }
