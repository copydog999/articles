"""
Example: Play against trained GeepSeek model
Human vs AI game with console interface
"""
import torch
from game.gomoku import GomokuEnv
from models.network import GomokuNetwork
from mcts.search import MCTS


def play_against_ai(model_path: str = None):
    """
    Play a game against the trained AI
    
    Args:
        model_path: Path to trained model checkpoint (optional)
    """
    print("=" * 80)
    print("GeepSeek - Human vs AI")
    print("=" * 80)
    print("\nYou are BLACK (X), AI is WHITE (O)")
    print("Enter moves as 'row col' (e.g., '7 7' for center)")
    print("Type 'quit' to exit\n")
    
    # Load model
    network = GomokuNetwork()
    if model_path:
        checkpoint = torch.load(model_path, map_location='cpu')
        network.load_state_dict(checkpoint['network_state_dict'])
        print(f"Loaded model from {model_path}\n")
    else:
        print("Using untrained model (random play)\n")
    
    # Create MCTS agent
    mcts_config = {
        'num_simulations': 400,
        'c_puct': 1.5,
        'dirichlet_alpha': 0.3,
        'dirichlet_epsilon': 0.0,  # No noise for evaluation
        'temperature_init': 0.1,   # Low temperature for best play
        'temperature_decay_steps': 0,
        'virtual_loss_weight': 3
    }
    mcts = MCTS(network, mcts_config)
    
    # Start game
    env = GomokuEnv()
    env.reset()
    env.render()
    
    while not env.done:
        if env.current_player == GomokuEnv.BLACK:
            # Human's turn
            try:
                move_input = input("\nYour move (row col): ").strip()
                
                if move_input.lower() == 'quit':
                    print("Game aborted.")
                    return
                
                parts = move_input.split()
                if len(parts) != 2:
                    print("Invalid input. Use format: row col")
                    continue
                
                row, col = int(parts[0]), int(parts[1])
                
                if (row, col) not in env.get_legal_moves():
                    print("Invalid move. Try again.")
                    continue
                
                env.step((row, col))
                env.render()
                
            except ValueError:
                print("Invalid input. Enter numbers only.")
        else:
            # AI's turn
            print("\nAI is thinking...")
            action, _ = mcts.search(env, temperature=0.1, add_dirichlet=False)
            print(f"AI plays: ({action[0]}, {action[1]})")
            
            env.step(action)
            env.render()
    
    # Game over
    print("\n" + "=" * 80)
    if env.winner == GomokuEnv.BLACK:
        print("Congratulations! You win!")
    elif env.winner == GomokuEnv.WHITE:
        print("AI wins! Better luck next time.")
    else:
        print("It's a draw!")
    print("=" * 80)


def watch_ai_vs_ai():
    """Watch two AI agents play each other"""
    print("=" * 80)
    print("GeepSeek - AI vs AI Exhibition")
    print("=" * 80)
    
    # Load model
    network = GomokuNetwork()
    
    # Create MCTS agent
    mcts_config = {
        'num_simulations': 200,
        'c_puct': 1.5,
        'dirichlet_alpha': 0.3,
        'dirichlet_epsilon': 0.25,
        'temperature_init': 1.0,
        'temperature_decay_steps': 10,
        'virtual_loss_weight': 3
    }
    mcts = MCTS(network, mcts_config)
    
    # Play game
    env = GomokuEnv()
    env.reset()
    
    move_count = 0
    while not env.done:
        action, _ = mcts.search(env, temperature=1.0)
        env.step(action)
        move_count += 1
        
        if move_count % 5 == 0 or env.done:
            print(f"\nMove {move_count}: ({action[0]}, {action[1]})")
            env.render()
    
    print("\n" + "=" * 80)
    if env.winner == GomokuEnv.BLACK:
        print("Black wins!")
    elif env.winner == GomokuEnv.WHITE:
        print("White wins!")
    else:
        print("Draw!")
    print(f"Total moves: {move_count}")
    print("=" * 80)


if __name__ == '__main__':
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == 'watch':
        watch_ai_vs_ai()
    else:
        model_path = sys.argv[1] if len(sys.argv) > 1 else None
        play_against_ai(model_path)
